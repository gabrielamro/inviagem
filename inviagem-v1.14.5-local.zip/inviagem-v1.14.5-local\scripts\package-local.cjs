/**
 * Gera na Área de trabalho (nome inclui a versão do package.json, ex.: inviagem-v1.12.0-local.zip).
 *
 * Uso: node scripts/package-local.cjs [--skip-build]
 */
const fs = require('fs');
const path = require('path');
const { execSync, spawnSync } = require('child_process');

const projectRoot = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(projectRoot, 'package.json'), 'utf8'));
const appVersion = typeof pkg.version === 'string' ? pkg.version : '0.0.0';
const args = process.argv.slice(2);
const skipBuild = args.includes('--skip-build');

function getDesktop() {
  const home = require('os').homedir();
  const d1 = path.join(home, 'Desktop');
  if (fs.existsSync(d1)) return d1;
  const d2 = path.join(home, 'Área de Trabalho');
  if (fs.existsSync(d2)) return d2;
  return home;
}

function shouldCopy(absPath) {
  const rel = path.relative(projectRoot, absPath);
  if (!rel || rel === '.') return true;
  const norm = rel.split(path.sep);
  if (norm[0] === 'node_modules') return false;
  if (norm[0] === '.git') return false;
  if (norm[0] === '.next' && norm[1] === 'cache') return false;
  // Não incluir segredos no zip/pasta de entrega (copie .env.local manualmente se precisar).
  if (norm[0] === '.env.local' || rel === '.env.local') return false;
  return true;
}

function copyProject(destDir) {
  fs.mkdirSync(destDir, { recursive: true });
  fs.cpSync(projectRoot, destDir, {
    recursive: true,
    filter: (src) => shouldCopy(src),
  });
}

function runPowerShellZip(folderToZip, zipOut) {
  const os = require('os');
  const ps1 = path.join(os.tmpdir(), `inviagem-zip-${Date.now()}.ps1`);
  const body = [
    '$ErrorActionPreference = "Stop"',
    `$zip = @'
${zipOut.replace(/'/g, "''")}
'@`,
    `$folder = @'
${folderToZip.replace(/'/g, "''")}
'@`,
    'if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }',
    'Compress-Archive -LiteralPath $folder -DestinationPath $zip -CompressionLevel Optimal -Force',
  ].join('\n');
  fs.writeFileSync(ps1, body, 'utf8');
  try {
    const r = spawnSync(
      'powershell.exe',
      ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ps1],
      { stdio: 'inherit', windowsHide: true }
    );
    if (r.status !== 0) {
      throw new Error(`Compress-Archive falhou com código ${r.status}`);
    }
  } finally {
    try {
      fs.unlinkSync(ps1);
    } catch (_) {}
  }
}

const desktop = getDesktop();
const packageName = `inviagem-v${appVersion}-local`;
const stagingParent = path.join(desktop, `.${packageName}-staging-${Date.now()}`);
const stagingInner = path.join(stagingParent, packageName);
const zipPath = path.join(desktop, `${packageName}.zip`);

console.log('[inviagem] Desktop:', desktop);
console.log('[inviagem] Projeto:', projectRoot);

if (!skipBuild) {
  console.log('[inviagem] QA: guards Realtime Supabase ...');
  execSync('npm run qa:realtime-guards', { cwd: projectRoot, stdio: 'inherit', shell: true });
  console.log('[inviagem] Executando npm run build:fresh ...');
  execSync('npm run build:fresh', { cwd: projectRoot, stdio: 'inherit', shell: true });
} else {
  console.log('[inviagem] Pulando build (--skip-build).');
}

try {
  console.log('[inviagem] Copiando arquivos (sem node_modules/.git) ...');
  fs.mkdirSync(stagingParent, { recursive: true });
  copyProject(stagingInner);

  const marker = path.join(stagingInner, 'LEIA-ME-EXTRAIA-ESTE-ZIP.txt');
  fs.writeFileSync(
    marker,
    [
      `INVIAGEM v${appVersion} — como usar este pacote`,
      '========================',
      '',
      `1) Clique com o botão direito em ${packageName}.zip → Extrair tudo.`,
      `2) Abra a pasta extraída "${packageName}" (uma pasta só — não abra o .zip como pasta no VS Code).`,
      '3) No terminal, dentro dessa pasta: npm ci  (ou npm install)',
      '4) npm run start  →  http://localhost:3020',
      '',
      'Confirme a versão no canto inferior direito da tela (v' + appVersion + ') ou em http://localhost:3020/api/version',
      '',
      'Se o Windows disser "pasta inválida" ao abrir o zip: extraia com "Extrair tudo" ou use 7-Zip;',
      'não use "Abrir com" o zip como se fosse uma pasta.',
      '',
    ].join('\r\n'),
    'utf8'
  );

  const outFolder = path.join(desktop, packageName);
  try {
    fs.rmSync(outFolder, { recursive: true, force: true });
  } catch (_) {
    /* ignore */
  }
  fs.cpSync(stagingInner, outFolder, { recursive: true });
  console.log('[inviagem] Pasta pronta (abra esta pasta no terminal/VS Code):', outFolder);

  console.log('[inviagem] Gerando zip:', zipPath);
  runPowerShellZip(stagingInner, zipPath);
  console.log('[inviagem] OK:', zipPath);
} finally {
  try {
    fs.rmSync(stagingParent, { recursive: true, force: true });
  } catch (_) {
    console.warn('[inviagem] Não foi possível remover staging:', stagingParent);
  }
}
