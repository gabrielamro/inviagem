-- =============================================================================
-- INVIAGEM — Tabela public.vehicles (cadastro de documentos do motorista)
-- =============================================================================
-- Erro típico sem esta tabela:
--   "Could not find the table 'public.vehicles' in the schema cache"
--
-- ONDE RODAR: Supabase → SQL → New query → colar → Run
--
-- Opcional (se drivers.id for uuid e quiser integridade): após criar a tabela,
--   ALTER TABLE public.vehicles
--   ADD CONSTRAINT vehicles_driver_id_fkey
--   FOREIGN KEY (driver_id) REFERENCES public.drivers (id) ON DELETE CASCADE;
-- =============================================================================

CREATE TABLE IF NOT EXISTS public.vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id uuid NOT NULL,
  plate text NOT NULL,
  model text,
  brand text,
  color text,
  manufacturing_year integer,
  maximum_capacity integer,
  status text NOT NULL DEFAULT 'PENDING',
  crlv_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT vehicles_plate_unique UNIQUE (plate)
);

CREATE INDEX IF NOT EXISTS vehicles_driver_id_idx ON public.vehicles (driver_id);

COMMENT ON TABLE public.vehicles IS 'Veículo do motorista; o app faz upsert por placa (onConflict: plate).';

ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "vehicles_anon_all" ON public.vehicles;
CREATE POLICY "vehicles_anon_all"
  ON public.vehicles FOR ALL TO anon
  USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "vehicles_authenticated_all" ON public.vehicles;
CREATE POLICY "vehicles_authenticated_all"
  ON public.vehicles FOR ALL TO authenticated
  USING (true) WITH CHECK (true);

-- Em produção, substitua as políticas acima por regras mais restritas (ex.: por driver_id).
