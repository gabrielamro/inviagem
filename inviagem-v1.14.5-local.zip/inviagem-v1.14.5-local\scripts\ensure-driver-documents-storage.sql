-- =============================================================================
-- INVIAGEM — Storage: bucket de documentos do motorista
-- =============================================================================
-- ONDE EXECUTAR (não é pasta no seu PC):
--   1) Acesse https://supabase.com → seu projeto
--   2) Menu esquerdo: SQL → New query
--   3) Cole este arquivo inteiro → Run
--
-- Isso cria o bucket "driver-documents" (público para leitura via URL pública)
-- e políticas para o app (chave anon do .env.local) conseguir enviar arquivos.
--
-- Se preferir outro nome de bucket, altere 'driver-documents' em todo o script
-- e no .env.local: NEXT_PUBLIC_SUPABASE_DRIVER_DOCS_BUCKET=seu-nome
-- =============================================================================

-- Bucket (id e name costumam ser iguais)
INSERT INTO storage.buckets (id, name, public)
VALUES ('driver-documents', 'driver-documents', true)
ON CONFLICT (id) DO UPDATE SET public = EXCLUDED.public;

-- Leitura pública dos objetos (necessário para getPublicUrl no fluxo atual)
DROP POLICY IF EXISTS "driver_documents_public_select" ON storage.objects;
CREATE POLICY "driver_documents_public_select"
ON storage.objects FOR SELECT
USING (bucket_id = 'driver-documents');

-- Upload com a chave anônima do frontend (projeto usa cliente sem Supabase Auth em vários fluxos)
DROP POLICY IF EXISTS "driver_documents_anon_insert" ON storage.objects;
CREATE POLICY "driver_documents_anon_insert"
ON storage.objects FOR INSERT TO anon
WITH CHECK (bucket_id = 'driver-documents');

-- Upload se no futuro você ligar Supabase Auth no app
DROP POLICY IF EXISTS "driver_documents_auth_insert" ON storage.objects;
CREATE POLICY "driver_documents_auth_insert"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'driver-documents');

-- Atualizar/remover apenas dono da linha (quando usar JWT com auth.uid() = owner)
-- Descomente e adapte se passar a usar Supabase Auth com claim igual ao id do motorista:
-- DROP POLICY IF EXISTS "driver_documents_owner_update" ON storage.objects;
-- CREATE POLICY "driver_documents_owner_update"
-- ON storage.objects FOR UPDATE TO authenticated
-- USING (bucket_id = 'driver-documents' AND (storage.foldername(name))[1] = auth.uid()::text);
