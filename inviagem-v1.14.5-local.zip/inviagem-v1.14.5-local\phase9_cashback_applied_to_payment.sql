-- Opcional: persistir valor de cashback abatido no pagamento da corrida (Supabase).
-- Se a coluna não existir, o app grava só payment_method e status; o fluxo continua funcionando.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'rides' AND column_name = 'cashback_applied_to_payment'
    ) THEN
        ALTER TABLE rides ADD COLUMN cashback_applied_to_payment NUMERIC DEFAULT 0;
    END IF;
END $$;
