-- Rode no Supabase → SQL Editor (uma vez), se o motorista não persistir ONLINE/OFFLINE.
-- O app usa por padrão a coluna online_status (ou NEXT_PUBLIC_DRIVER_AVAILABILITY_COLUMN).

ALTER TABLE drivers
  ADD COLUMN IF NOT EXISTS online_status text NOT NULL DEFAULT 'OFFLINE';

COMMENT ON COLUMN drivers.online_status IS 'OFFLINE | ONLINE | IN_RIDE — disponibilidade do motorista';

-- Recarregue o schema no PostgREST (Supabase costuma atualizar sozinho em segundos).
