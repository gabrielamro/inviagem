'use client';

import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useStore, Ride, Hotspot, Driver, AnyUser, DriverFleetVehicle } from '@/lib/store';
import { supabase, canUseSupabase } from '@/lib/supabaseClient';
import { MapPin, Navigation, CreditCard, MessageSquare, ShieldAlert, Star, Search, Car, CheckCircle2, User as UserIcon, ArrowRight, Menu, X, Volume2, VolumeX, Play, Flame, Power, Map, DollarSign, Settings, Check, AlertCircle, ShieldCheck, Mic, Video, Target, Home, TrendingUp, AlertTriangle, Coffee, Gift, AlertOctagon, Wrench, Droplets, ChevronUp, ChevronDown, Eye, FileText, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useRouter } from 'next/navigation';
import { GoogleMap, useLoadScript, Marker, DirectionsRenderer, TrafficLayerF, OverlayViewF, Polyline, Circle } from '@react-google-maps/api';

const mapContainerStyle = {
  width: '100%',
  height: '100%',
};

const defaultCenter = {
  lat: -3.119027, // Manaus
  lng: -60.021731,
};

// Haversine formula for distance fallback (Returns KM)
function getDistanceKM(lat1: number, lon1: number, lat2: number, lon2: number) {
  const p = 0.017453292519943295; // Math.PI / 180
  const c = Math.cos;
  const a = 0.5 - c((lat2 - lat1) * p)/2 + 
          c(lat1 * p) * c(lat2 * p) * 
          (1 - c((lon2 - lon1) * p))/2;
  return 12742 * Math.asin(Math.sqrt(a)); // 2 * R; R = 6371 km
}

const libraries: ("places" | "geometry" | "visualization")[] = ["places", "geometry", "visualization"];

export default function DriverApp() {
  const router = useRouter();
  const { drivers, passengers, currentUser, setCurrentUser, rides, updateRideStatus, updateDriverStatus, updateRidePrice, isDemoMode, setDemoMode, updateUserLocation, addChatMessage, hotspots, updateDriverClearance, addWalletBalance, registerUser, loginUser, submitDriverDocs, deleteDriverAccount, globalError, triggerError, globalChats, addGlobalChatMessage, requestDriverWithdrawal, driverWithdrawals, updateDriverFleetVehicles } = useStore();
  const [activeTab, setActiveTab] = useState<'home' | 'earnings' | 'settings' | 'safety' | 'wallet' | 'benefits'>('home');
  const [activeSetting, setActiveSetting] = useState<'driver' | 'vehicle' | null>(null);

  // Auth & Docs state
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authName, setAuthName] = useState('');
  const [authCpf, setAuthCpf] = useState('');
  const [authEmail, setAuthEmail] = useState('');
  const [authPhone, setAuthPhone] = useState('');
  const [authError, setAuthError] = useState('');
  const [regGender, setRegGender] = useState<'MALE' | 'FEMALE' | ''>('');
  const [regFacialFile, setRegFacialFile] = useState<File | null>(null);
  const [regFacialPreview, setRegFacialPreview] = useState<string | null>(null);
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [withdrawInput, setWithdrawInput] = useState('');
  const [withdrawBusy, setWithdrawBusy] = useState(false);
  const [newFleetKind, setNewFleetKind] = useState<'CAR' | 'MOTO'>('CAR');
  const [newFleetModel, setNewFleetModel] = useState('');
  const [newFleetPlate, setNewFleetPlate] = useState('');
  const [newFleetCategory, setNewFleetCategory] = useState<'X' | 'Comfort' | 'Black'>('X');
  const [criminalRecordFile, setCriminalRecordFile] = useState<File | null>(null);
  const [criminalRecordName, setCriminalRecordName] = useState('');
  const [docAnalysisOpen, setDocAnalysisOpen] = useState(false);

  // Vehicle Docs states
  const [vehiclePlate, setVehiclePlate] = useState('');
  const [vehicleBrand, setVehicleBrand] = useState('');
  const [vehicleModel, setVehicleModel] = useState('');
  const [vehicleColor, setVehicleColor] = useState('');
  const [vehicleYear, setVehicleYear] = useState('');
  const [vehicleCapacity, setVehicleCapacity] = useState('4');
  const [isSubmittingDocs, setIsSubmittingDocs] = useState(false);
  const [isParsingPDF, setIsParsingPDF] = useState(false);
  const [cnhFileName, setCnhFileName] = useState('');
  const [cnhFile, setCnhFile] = useState<File | null>(null);
  const [cnhPreviewUrl, setCnhPreviewUrl] = useState<string | null>(null);
  const [crlvFileName, setCrlvFileName] = useState('');
  const [crlvFile, setCrlvFile] = useState<File | null>(null);
  const [crlvPreviewUrl, setCrlvPreviewUrl] = useState<string | null>(null);
  const [docZipFileName, setDocZipFileName] = useState('');
  const [certificationFile, setCertificationFile] = useState<File | null>(null);
  const [profilePhotoFile, setProfilePhotoFile] = useState<File | null>(null);
  const [profilePreviewUrl, setProfilePreviewUrl] = useState<string | null>(null);
  const [isBiometryActive, setIsBiometryActive] = useState(false);
  const [biometryStep, setBiometryStep] = useState<'IDLE' | 'SCANNING' | 'SUCCESS'>('IDLE');
  const [docFeedback, setDocFeedback] = useState<{ type: 'error' | 'success' | 'warning', message: string } | null>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showGroupMap, setShowGroupMap] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [groupChatMsg, setGroupChatMsg] = useState('');
  const [isRideInfoExpanded, setIsRideInfoExpanded] = useState(false);
  const [mapCenter, setMapCenter] = useState(defaultCenter);
  const [mapZoom, setMapZoom] = useState(18); // Default to 18 for drive mode
  const [directionsResponse, setDirectionsResponse] = useState<google.maps.DirectionsResult | null>(null);
  const [hotspotRouteResponse, setHotspotRouteResponse] = useState<google.maps.DirectionsResult | null>(null);
  const [carAnimPosition, setCarAnimPosition] = useState<google.maps.LatLngLiteral | null>(null);
  const [carHeading, setCarHeading] = useState(0);
  const [mapRef, setMapRef] = useState<google.maps.Map | null>(null);
  const routePolylineRef = useRef<google.maps.Polyline | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [surgePricingZones, setSurgePricingZones] = useState<{ id: number, lat: number, lng: number, value: number }[]>([]);
  const [heatmapLayer, setHeatmapLayer] = useState<google.maps.visualization.HeatmapLayer | null>(null);
  const [isAutoCenter, setIsAutoCenter] = useState(true);
  const [isDriveMode, setIsDriveMode] = useState(true);
  const [currentManeuver, setCurrentManeuver] = useState<string | null>(null);
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);
  const [radarRadius, setRadarRadius] = useState(8);
  const [searchMessage, setSearchMessage] = useState('Buscando passageiros próximos...');
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  /** Direção do dispositivo (graus), quando o GPS informa — ícone estilo mapas. */
  const [deviceHeading, setDeviceHeading] = useState(0);

  // Fase 1 & 2 States
  const [isGoingHome, setIsGoingHome] = useState(false);
  const [autoAccept, setAutoAccept] = useState(false);
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [isDashcamActive, setIsDashcamActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const dailyGoal = 300;
  const currentEarnings = 142.50;

  const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: apiKey || '',
    libraries,
  });

  const driverMe = currentUser?.role === 'DRIVER' ? (currentUser as Driver) : null;
  const currentUserRef = useRef(currentUser);
  useEffect(() => {
    currentUserRef.current = currentUser;
  }, [currentUser]);
  /** Otimista: clique muda On/Off na hora mesmo se o store/Supabase atrasar */
  const [optimisticOnline, setOptimisticOnline] = useState<boolean | null>(null);

  const derivedOnlineFromStore = useMemo(() => {
    if (currentUser?.role !== 'DRIVER') return false;
    const sid = String(currentUser.id);
    const fromSession = (currentUser as Driver).status === 'ONLINE';
    const fromList = drivers.some((d) => String(d.id) === sid && d.status === 'ONLINE');
    return fromSession || fromList;
  }, [currentUser, drivers]);

  useEffect(() => {
    if (optimisticOnline === null) return;
    if (derivedOnlineFromStore === optimisticOnline) {
      setOptimisticOnline(null);
    }
  }, [derivedOnlineFromStore, optimisticOnline]);

  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.location.search.includes('register=1')) {
        setAuthMode('register');
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!currentUser) setOptimisticOnline(null);
  }, [currentUser]);

  /** Ambiente de teste: após envio de documentos, modal "Em análise" e aprovação automática em 5s. */
  useEffect(() => {
    if (!docAnalysisOpen) return;
    const uid = currentUser?.id;
    const st = (currentUser as Driver | null)?.driverStatus;
    if (!uid || st !== 'UNDER_REVIEW') return;
    const timer = window.setTimeout(async () => {
      if (canUseSupabase()) {
        const { error } = await supabase.from('drivers').update({ driver_status: 'APPROVED' }).eq('id', uid);
        if (error) console.error('[DRIVER] Aprovação automática (teste):', error.message);
      }
      const prev = currentUserRef.current;
      if (prev && prev.role === 'DRIVER') {
        const d = prev as Driver;
        if (d.driverStatus === 'UNDER_REVIEW') {
          setCurrentUser({ ...d, driverStatus: 'APPROVED' } as AnyUser);
        }
      }
      setDocAnalysisOpen(false);
    }, 5000);
    return () => window.clearTimeout(timer);
  }, [docAnalysisOpen, currentUser?.id, (currentUser as Driver | null)?.driverStatus, setCurrentUser]);

  const isOnline = optimisticOnline !== null ? optimisticOnline : derivedOnlineFromStore;

  // Find active ride for this driver
  const activeRide = rides.find(r => {
    if (r.driverId !== currentUser?.id) return false;
    if (['COMPLETED', 'PAID', 'CANCELLED', 'NO_DRIVER'].includes(r.status)) return false;
    const ageHrs = (Date.now() - new Date(r.createdAt).getTime()) / (1000 * 60 * 60);
    if (ageHrs > 2) return false;
    return true;
  });

  // Expanded Radar logic (1km to 8km)
  useEffect(() => {
    if (isOnline && !activeRide) {
      const interval = setInterval(() => {
        setRadarRadius(prev => {
          if (prev < 8) {
            setSearchMessage(`Expandindo busca para ${prev + 1}km...`);
            return prev + 1;
          }
          setSearchMessage('Monitorando alta demanda em 8km...');
          return prev;
        });
      }, 5000); // Expands every 5 seconds
      return () => {
        clearInterval(interval);
        setRadarRadius(8);
        setSearchMessage('Buscando passageiros próximos...');
      };
    }
  }, [isOnline, activeRide]);

  // Find incoming ride request filtered by radar distance (usa mapa se GPS ainda não populou driverMe.location)
  const incomingRide = rides.find(r => {
    const isMatching = r.status === 'MATCHING' || (r.status === 'NEGOTIATING' && r.lastOfferBy === 'PASSENGER');
    if (!isMatching || !driverMe) return false;

    const driverLoc = driverMe.location
      ? { lat: driverMe.location.lat, lng: driverMe.location.lng }
      : { lat: mapCenter.lat, lng: mapCenter.lng };

    let distance = 999;
    if (typeof window !== 'undefined' && window.google?.maps?.geometry) {
      const rideOrigin = new window.google.maps.LatLng(r.origin.lat, r.origin.lng);
      const driverLatLng = new window.google.maps.LatLng(driverLoc.lat, driverLoc.lng);
      distance = window.google.maps.geometry.spherical.computeDistanceBetween(driverLatLng, rideOrigin) / 1000;
    } else {
      distance = getDistanceKM(driverLoc.lat, driverLoc.lng, r.origin.lat, r.origin.lng);
    }

    // Bypassa o radar se for corrida de terminal, ou aumenta raio pra 15km
    if (r.isTerminalRide) {
      if (distance > 20) return false; // 20km limite para terminal
    } else {
      if (distance > radarRadius) return false;
    }

    // Filters based on Driver properties
    const asDriver = currentUser as Driver;
    if (r.rideType === 'WOMEN_ONLY' && asDriver.gender !== 'FEMALE') return false;

    const fleet = driverMe.fleetVehicles || [];
    const activeVehicle =
      fleet.find((v) => v.id === driverMe.activeFleetVehicleId) || fleet[0];

    if (r.rideType === 'PET') {
      if (activeVehicle?.kind === 'MOTO') return false;
      if (activeVehicle) {
        if (activeVehicle.acceptsPet === false) return false;
      } else if (!asDriver.acceptsPetRides) {
        return false;
      }
    }

    if (r.category === 'Corrida Moto') {
      if (activeVehicle && activeVehicle.kind !== 'MOTO') return false;
    }

    return true;
  });

  const handleFindBestSpot = () => {
    if (!driverMe?.location || !window.google) return;

    const currentLoc = new window.google.maps.LatLng(driverMe.location.lat, driverMe.location.lng);
    let nearest: Hotspot | null = null;
    let minDistance = Infinity;

    const activeHotspots = hotspots.filter(h => h.active);
    for (const hotspot of activeHotspots) {
      const hotspotLoc = new window.google.maps.LatLng(hotspot.lat, hotspot.lng);
      const distance = window.google.maps.geometry.spherical.computeDistanceBetween(currentLoc, hotspotLoc);
      if (distance < minDistance) {
        minDistance = distance;
        nearest = hotspot;
      }
    }

    if (nearest) {
      setActiveHotspot(nearest.id);

      // Calculate route to hotspot
      const directionsService = new window.google.maps.DirectionsService();
      directionsService.route(
        {
          origin: currentLoc,
          destination: { lat: nearest.lat, lng: nearest.lng },
          travelMode: window.google.maps.TravelMode.DRIVING,
        },
        (result, status) => {
          if (status === window.google.maps.DirectionsStatus.OK && result) {
            setHotspotRouteResponse(result);
            setMapCenter({ lat: nearest.lat, lng: nearest.lng });
            setMapZoom(14);
            setIsAutoCenter(false);
          }
        }
      );
    } else {
      alert("Nenhuma zona de alta demanda encontrada próxima.");
    }
  };

  const clearHotspotRoute = () => {
    setActiveHotspot(null);
    setHotspotRouteResponse(null);
    setIsAutoCenter(true);
  };

  // Get current location and watch for changes
  useEffect(() => {
    if (navigator.geolocation) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          const pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          const h = position.coords.heading;
          if (h != null && !Number.isNaN(h)) {
            setDeviceHeading(h);
          }
          if (isAutoCenter && !activeRide) {
            setMapCenter(pos);
          }
          if (currentUser) {
            updateUserLocation(currentUser.id, { ...pos, address: 'Localização em tempo real' });
          }
        },
        (error) => console.error(error),
        { enableHighAccuracy: true, maximumAge: 0 }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, [currentUser, updateUserLocation, isAutoCenter, activeRide]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error("Erro ao acessar câmera:", err);
      // Fallback log
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video.videoWidth === 0 || video.videoHeight === 0) return;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.scale(-1, 1);
        ctx.translate(-canvas.width, 0);
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], 'biometry.jpg', { type: 'image/jpeg' });
            setBiometryStep('SCANNING');
            stopCamera();
            setTimeout(() => {
              setProfilePhotoFile(file);
              setProfilePreviewUrl(URL.createObjectURL(file));
              setBiometryStep('SUCCESS');
              setTimeout(() => {
                setIsBiometryActive(false);
                setBiometryStep('IDLE');
              }, 1500);
            }, 2000);
          }
        }, 'image/jpeg');
      }
    }
  };

  useEffect(() => {
    if (isBiometryActive && biometryStep === 'IDLE') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [isBiometryActive, biometryStep]);

  // Removido o login automático para permitir o fluxo real de cadastro e login
  // useEffect(() => {
  //   if (!currentUser || currentUser.role !== 'DRIVER') {
  //     const driver = users.find(u => u.role === 'DRIVER');
  //     if (driver) {
  //       setCurrentUser(driver);
  //     }
  //   }
  // }, [users, currentUser, setCurrentUser]);

  const handleRegisterDriver = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!regGender) {
      setAuthError('Selecione o gênero (obrigatório para regras de corrida e segurança).');
      return;
    }
    if (!regFacialFile) {
      setAuthError('Envie uma foto do rosto para validação cadastral (reconhecimento facial).');
      return;
    }
    const res = await registerUser({
      name: authName,
      role: 'DRIVER',
      cpf: authCpf,
      email: authEmail.trim() || undefined,
      phone: authPhone.replace(/\D/g, '') || undefined,
      driverStatus: 'PENDING_DOCS',
      walletBalance: 0,
      status: 'OFFLINE',
      gender: regGender,
      facialPhoto: regFacialFile,
    });
    if (res.ok) {
      setCurrentUser(res.user);
      setRegFacialFile(null);
      if (regFacialPreview) {
        try {
          URL.revokeObjectURL(regFacialPreview);
        } catch {
          /* ignore */
        }
        setRegFacialPreview(null);
      }
    } else {
      setAuthError(res.message);
    }
  };

  const handleLoginDriver = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!authCpf) {
      setAuthError("Por favor, digite seu CPF.");
      return;
    }
    const foundDriver = await loginUser(authCpf, 'DRIVER');
    if (foundDriver) {
      setCurrentUser(foundDriver);
    } else {
      setAuthError("Nenhum motorista encontrado com este CPF.");
    }
  };

  const handleCRLVUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setDocFeedback(null);
    if (!file || file.type !== 'application/pdf') {
      setDocFeedback({ type: 'error', message: "Por favor, anexe o CRLV Eletrônico no formato original (.pdf)." });
      return;
    }

    try {
      setIsParsingPDF(true);
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/parse-document', { method: 'POST', body: formData });
      const data = await response.json();

      if (!response.ok) throw new Error(data.error);

      setCrlvFile(file);

      // Auto-preenchimento
      if (data.plate) setVehiclePlate(data.plate);
      if (data.year) setVehicleYear(data.year);
      if (data.brand) setVehicleBrand(data.brand);
      if (data.model) setVehicleModel(data.model);
      if (data.color) setVehicleColor(data.color);
      if (data.capacity) setVehicleCapacity(data.capacity);

      setDocFeedback({ type: 'success', message: "✨ A Inteligência Artificial preencheu as informações do seu carro!" });

      // Criar preview se for PDF (blob url)
      const url = URL.createObjectURL(file);
      setCrlvPreviewUrl(url);
      setCrlvFile(file);
      setCrlvFileName(file.name);

    } catch (err: any) {
      // Força o anexo mesmo se a IA falhar
      setCrlvFile(file);
      setCrlvFileName(file.name);
      const url = URL.createObjectURL(file);
      setCrlvPreviewUrl(url);
      setDocFeedback({ type: 'warning', message: "Arquivo anexado! A IA não conseguiu ler os dados automaticamente, mas o arquivo foi salvo para conferência manual." });
      console.error(err);
    } finally {
      setIsParsingPDF(false);
      e.target.value = ''; // Reseta o input do html escondido
    }
  };

  const handleCNHUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setDocFeedback(null);
    if (!file) return;

    // Gerar preview url
    const url = URL.createObjectURL(file);
    setCnhPreviewUrl(url);

    if (file.type !== 'application/pdf') {
      // Se for imagem, apenas anexa para análise manual do admin posteriormente, mas avisa
      if (file.type.startsWith('image/')) {
        setCnhFileName(file.name);
        setCnhFile(file);
        setDocFeedback({ type: 'success', message: "Foto da CNH anexada. Ela passará por análise manual técnica." });
        return;
      }
      setDocFeedback({ type: 'error', message: "Para validação instantânea, use o PDF da CNH Digital." });
      return;
    }

    try {
      setIsParsingPDF(true);
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/parse-document', { method: 'POST', body: formData });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Falha na análise automática da CNH.");
      }

      setCnhFileName(file.name);
      setCnhFile(file);
      setDocFeedback({ type: 'success', message: `✨ CNH Validada: ${data.message}` });

    } catch (err: any) {
      // Se falhar o parse, ainda assim anexamos o arquivo para o admin ver
      setCnhFileName(file.name);
      setCnhFile(file);
      setDocFeedback({ type: 'warning', message: "Foto da CNH anexada. Analisaremos manualmente o documento." });
      console.error(err);
    } finally {
      setIsParsingPDF(false);
      e.target.value = '';
    }
  };

  const handleCertidaoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setDocFeedback(null);
    if (!file) return;

    if (file.type !== 'application/pdf') {
      setDocFeedback({ type: 'error', message: "Para validação automática, anexe a Certidão em PDF original." });
      return;
    }

    try {
      setIsParsingPDF(true);
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/parse-document', { method: 'POST', body: formData });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Falha na análise da Certidão.");
      }

      setDocZipFileName(file.name);
      setCertificationFile(file);

      if (data.isUncertain || data.isPositive) {
        setDocFeedback({
          type: 'warning',
          message: "Documento anexado! A IA não confirmou o 'Nada Consta' de forma automática, por isso ele passará por uma análise técnica manual."
        });
      } else {
        setDocFeedback({
          type: 'success',
          message: `✨ Certidão Validada: ${data.message}`
        });
      }

    } catch (err: any) {
      setDocFeedback({ type: 'error', message: err.message || "Erro ao processar Certidão." });
      console.error(err);
    } finally {
      setIsParsingPDF(false);
      e.target.value = '';
    }
  };

  const handleSendChat = () => {
    if (!chatMessage.trim() || !activeRide || !currentUser) return;
    addChatMessage(activeRide.id, currentUser.id, chatMessage);
    setChatMessage('');
  };

  const toggleOnline = (e?: React.MouseEvent) => {
    e?.preventDefault();
    e?.stopPropagation();
    if (!currentUser) return;
    const next = !isOnline;
    setOptimisticOnline(next);
    updateDriverStatus(currentUser.id, next ? 'ONLINE' : 'OFFLINE');
  };

  // Handle Drive Mode changes - MOVED TO BUTTON HANDLER

  // Rota no mapa: corrida ativa ou pré-visualização do pedido (inclui paradas)
  useEffect(() => {
    if (!isLoaded || !window.google) return;
    const preview = !activeRide ? incomingRide : null;
    const rideForMap = activeRide || preview;
    if (!rideForMap) {
      setDirectionsResponse(null);
      return;
    }
    const o = rideForMap.origin;
    const d = rideForMap.destination;
    const origin =
      Number.isFinite(o.lat) && Number.isFinite(o.lng) ? { lat: o.lat, lng: o.lng } : o.address;
    const destination =
      Number.isFinite(d.lat) && Number.isFinite(d.lng) ? { lat: d.lat, lng: d.lng } : d.address;
    const waypoints = (rideForMap.waypoints || [])
      .filter((w) => w && (Number.isFinite(w.lat) || (w.address && String(w.address).trim())))
      .map((w) => ({
        location:
          Number.isFinite(w.lat) && Number.isFinite(w.lng)
            ? { lat: w.lat, lng: w.lng }
            : w.address,
        stopover: true,
      }));
    const directionsService = new window.google.maps.DirectionsService();
    directionsService.route(
      {
        origin,
        destination,
        waypoints,
        travelMode: window.google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === window.google.maps.DirectionsStatus.OK && result) {
          setDirectionsResponse(result);
        } else {
          console.warn('[DRIVER] Rota:', status);
          setDirectionsResponse(null);
        }
      }
    );
  }, [activeRide?.id, incomingRide?.id, isLoaded, activeRide, incomingRide]);

  // Car Animation Logic (same as passenger)
  useEffect(() => {
    if (activeRide?.status === 'IN_PROGRESS' && directionsResponse && activeRide.startTime && window.google) {
      const path = directionsResponse.routes[0].overview_path;
      const totalDuration = (activeRide.estimatedTime || 5) * 2000;

      let animId: number;
      const animate = () => {
        const elapsed = Date.now() - (activeRide.startTime || 0);
        const progress = Math.min(elapsed / totalDuration, 1);

        if (path.length > 1) {
          const totalPoints = path.length;
          const floatIndex = progress * (totalPoints - 1);
          const index = Math.floor(floatIndex);
          const nextIndex = Math.min(index + 1, totalPoints - 1);
          const segmentProgress = floatIndex - index;

          const currentPoint = path[index];
          const nextPoint = path[nextIndex];

          const lat = currentPoint.lat() + (nextPoint.lat() - currentPoint.lat()) * segmentProgress;
          const lng = currentPoint.lng() + (nextPoint.lng() - currentPoint.lng()) * segmentProgress;

          if (index < totalPoints - 1) {
            const heading = window.google.maps.geometry.spherical.computeHeading(currentPoint, nextPoint);
            setCarHeading(heading);

            if (isDriveMode && mapRef) {
              mapRef.setHeading(heading);
              mapRef.setTilt(45);
            }
          }

          // Find current step for maneuver
          const steps = directionsResponse.routes[0].legs[0].steps;
          let distanceCovered = 0;
          const totalDistance = directionsResponse.routes[0].legs[0].distance?.value || 1;
          const currentDistance = progress * totalDistance;

          for (let i = 0; i < steps.length; i++) {
            distanceCovered += steps[i].distance?.value || 0;
            if (currentDistance <= distanceCovered) {
              // We are in this step
              if (steps[i].instructions) {
                // Strip HTML tags from instructions
                const cleanInstructions = steps[i].instructions.replace(/<[^>]*>?/gm, '');
                setCurrentManeuver(cleanInstructions);
              }
              break;
            }
          }

          const newPos = { lat, lng };
          setCarAnimPosition(newPos);

          // Update route polyline to erase traveled path
          if (routePolylineRef.current) {
            const remainingPath = [newPos, ...path.slice(nextIndex)];
            routePolylineRef.current.setPath(remainingPath);
          }

          if (isAutoCenter) {
            setMapCenter(newPos);
          }
        }

        if (progress < 1) {
          animId = requestAnimationFrame(animate);
        }
      };

      animId = requestAnimationFrame(animate);
      return () => cancelAnimationFrame(animId);
    } else if (carAnimPosition !== null) {
      setTimeout(() => setCarAnimPosition(null), 0);
    }
  }, [activeRide?.status, activeRide?.startTime, activeRide?.estimatedTime, directionsResponse, carAnimPosition, isAutoCenter, isDriveMode, mapRef]);

  // Heatmap Logic - MOVED TO BUTTON HANDLER

  useEffect(() => {
    if (isLoaded && mapRef && window.google && showHeatmap && surgePricingZones.length > 0) {
      // Generate points clustered around the surge zones
      const points: google.maps.LatLng[] = [];

      surgePricingZones.forEach(zone => {
        // The higher the value, the more points (denser/redder)
        const numPoints = Math.floor(zone.value * 30);
        for (let i = 0; i < numPoints; i++) {
          // Gaussian-like distribution around the zone center
          const r = (Math.random() + Math.random() + Math.random() - 1.5) * 0.015;
          const theta = Math.random() * 2 * Math.PI;
          points.push(new window.google.maps.LatLng(
            zone.lat + r * Math.cos(theta),
            zone.lng + r * Math.sin(theta)
          ));
        }
      });

      const layer = new window.google.maps.visualization.HeatmapLayer({
        data: points,
        map: mapRef,
        radius: 60,
        opacity: 0.4,
        gradient: [
          'rgba(255, 255, 255, 0)',
          'rgba(255, 200, 0, 0.3)',
          'rgba(255, 100, 0, 0.5)',
          'rgba(255, 0, 0, 0.7)'
        ]
      });
      setTimeout(() => setHeatmapLayer(layer), 0);

      return () => {
        layer.setMap(null);
      };
    } else if (heatmapLayer) {
      heatmapLayer.setMap(null);
      setTimeout(() => setHeatmapLayer(null), 0);
    }
  }, [isLoaded, mapRef, showHeatmap, surgePricingZones]);

  const handleAccept = (rideId: string) => {
    if (!currentUser) return;
    updateRideStatus(rideId, 'DRIVER_ASSIGNED', currentUser.id);
    updateDriverStatus(currentUser.id, 'IN_RIDE');
  };

  const handleCounterOffer = (rideId: string, currentPrice: number, increment: number) => {
    if (!currentUser) return;
    updateRidePrice(rideId, currentPrice + increment, 'DRIVER', currentUser.id);
  };

  const handleReject = (rideId: string) => {
    updateRideStatus(rideId, 'NO_DRIVER');
  };

  const handleArrived = () => {
    if (activeRide) updateRideStatus(activeRide.id, 'DRIVER_ARRIVING');
  };

  const handleStartTrip = () => {
    if (activeRide) updateRideStatus(activeRide.id, 'IN_PROGRESS');
  };

  const handleCompleteTrip = () => {
    if (activeRide && currentUser) {
      updateRideStatus(activeRide.id, 'COMPLETED');
      updateDriverStatus(currentUser.id, 'ONLINE');
    }
  };

  if (!currentUser) {
    return (
      <div className="flex flex-col h-[100dvh] min-h-0 bg-[#050505] text-white max-w-md mx-auto relative overflow-hidden font-sans">
        <div className="absolute top-[-10%] right-[-10%] w-[300px] h-[300px] bg-emerald-500/10 rounded-full blur-[80px] pointer-events-none"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[300px] h-[300px] bg-blue-500/10 rounded-full blur-[80px] pointer-events-none"></div>

        <div className="relative z-10 flex flex-1 flex-col min-h-0 overflow-y-auto overscroll-y-contain px-8 py-6">
        <div className="relative z-10 text-center mb-8 shrink-0">
          <div className="text-3xl font-bold tracking-tighter mb-4">INVIAGEM<span className="text-emerald-500">.</span><span className="text-white/50 text-sm ml-2">Motorista</span></div>
          <h1 className="text-2xl font-light tracking-tight">{authMode === 'login' ? 'Bem-vindo de volta' : 'Faça seu cadastro'}</h1>
          <p className="text-white/50 text-sm mt-3 font-light">
            {authMode === 'login' ? 'Faça login para continuar ganhando.' : 'Junte-se à revolução da mobilidade em Manaus.'}
          </p>
          {authError && (
            <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 text-red-500 text-xs rounded-xl">
              {authError}
            </div>
          )}
        </div>

        {authMode === 'login' ? (
          <form className="relative z-10 space-y-4" onSubmit={handleLoginDriver}>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">CPF (Acesso)</label>
              <input type="text" value={authCpf} onChange={(e) => setAuthCpf(e.target.value)} required className="w-full bg-transparent text-white outline-none font-medium text-sm" placeholder="000.000.000-00" />
            </div>

            <button type="submit" className="w-full py-4 mt-8 bg-emerald-600 rounded-full font-bold uppercase tracking-widest text-sm hover:bg-emerald-500 transition-colors shadow-[0_0_20px_rgba(16,185,129,0.2)]">
              Entrar na Conta
            </button>
            <div onClick={(e) => { e.preventDefault(); setAuthName(''); setAuthEmail(''); setAuthPhone(''); setAuthError(''); setAuthMode('register'); }} className="w-full py-4 text-center text-xs font-bold uppercase tracking-widest text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer">
              Não tem conta? Cadastre-se
            </div>
            <div onClick={() => router.push('/passenger')} className="w-full py-2 text-center text-[10px] font-bold uppercase tracking-widest text-white/40 hover:text-white/70 transition-colors cursor-pointer">
              Sou passageiro
            </div>
          </form>
        ) : (
          <form className="relative z-10 space-y-4" onSubmit={handleRegisterDriver}>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">Nome Completo</label>
              <input type="text" value={authName} onChange={(e) => setAuthName(e.target.value)} required className="w-full bg-transparent text-white outline-none font-medium text-sm" placeholder="Como quer ser chamado?" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">CPF</label>
              <input type="text" value={authCpf} onChange={(e) => setAuthCpf(e.target.value)} required className="w-full bg-transparent text-white outline-none font-mono text-sm tracking-wider" placeholder="000.000.000-00" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">E-mail</label>
              <input type="email" value={authEmail} onChange={(e) => setAuthEmail(e.target.value)} className="w-full bg-transparent text-white outline-none font-medium text-sm" placeholder="seu@email.com" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">Telefone</label>
              <input type="tel" value={authPhone} onChange={(e) => setAuthPhone(e.target.value)} className="w-full bg-transparent text-white outline-none font-medium text-sm" placeholder="(92) 90000-0000" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-2">Gênero</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setRegGender('FEMALE')}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold uppercase border transition ${regGender === 'FEMALE' ? 'bg-pink-500/20 border-pink-500/40 text-pink-300' : 'bg-white/5 border-white/10 text-white/50'}`}
                >
                  Feminino
                </button>
                <button
                  type="button"
                  onClick={() => setRegGender('MALE')}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold uppercase border transition ${regGender === 'MALE' ? 'bg-blue-500/20 border-blue-500/40 text-blue-300' : 'bg-white/5 border-white/10 text-white/50'}`}
                >
                  Masculino
                </button>
              </div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block">Reconhecimento facial</label>
              <p className="text-[10px] text-white/45 leading-relaxed">Selfie nítida do rosto. Reduz fraude e é exigida para análise cadastral.</p>
              <input
                type="file"
                accept="image/*"
                capture="user"
                className="text-xs text-white/70 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-emerald-600 file:text-black file:text-[10px] file:font-bold"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  setRegFacialFile(f);
                  setRegFacialPreview((prev) => {
                    if (prev) try { URL.revokeObjectURL(prev); } catch { /* ignore */ }
                    return URL.createObjectURL(f);
                  });
                }}
              />
              {regFacialPreview && (
                <img src={regFacialPreview} alt="Prévia" className="w-24 h-24 rounded-full object-cover border border-emerald-500/40 mx-auto" />
              )}
            </div>

            <button type="submit" className="w-full py-4 mt-8 bg-emerald-600 rounded-full font-bold uppercase tracking-widest text-sm hover:bg-emerald-500 transition-colors shadow-[0_0_20px_rgba(16,185,129,0.2)]">
              Criar Conta e Enviar Documentos
            </button>
            <div onClick={(e) => { e.preventDefault(); setAuthName(''); setAuthEmail(''); setAuthPhone(''); setAuthError(''); setAuthMode('login'); }} className="w-full py-4 text-center text-xs font-bold uppercase tracking-widest text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer">
              Já tem conta? Fazer Login
            </div>
          </form>
        )}
        </div>
      </div>
    );
  }

  // Fase 1: Bloqueio de Segurança Documental (IMMU)
  const docDriver = currentUser as Driver;
  if (docDriver.driverStatus === 'PENDING_DOCS' || docDriver.driverStatus === 'UNDER_REVIEW' || docDriver.driverStatus === 'REJECTED') {
    return (
      <div className="flex flex-col h-screen bg-[#050505] text-white max-w-md mx-auto relative overflow-y-auto p-6 font-sans">
        <div className="mb-8 mt-6">
          <div className="text-xl font-bold tracking-tighter mb-2">INVIAGEM<span className="text-emerald-500">.</span></div>
          <h1 className="text-2xl font-bold">Quase lá, {currentUser.name.split(' ')[0]}!</h1>
          <p className="text-white/50 text-sm mt-2">Para seguir a regulamentação municipal de Manaus (Lei 2.468), precisamos dos seus documentos operacionais.</p>
        </div>

        {/* PASSO 1: BIOMETRIA (FORÇADO NO TOPO ABSOLUTO PARA GARANTIR VISIBILIDADE) */}
        <div className="bg-emerald-500/10 p-5 rounded-3xl border-2 border-emerald-500/40 mb-6 shadow-[0_0_50px_rgba(16,185,129,0.1)]">
          <div className="flex items-center gap-4 mb-5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 flex items-center justify-center border border-emerald-500/30">
              <ShieldCheck className="text-emerald-500" size={28} />
            </div>
            <div>
              <h3 className="font-black text-lg tracking-tight uppercase">PASSO 1: FOTO 3D</h3>
              <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-widest opacity-70">Validação Biométrica</p>
            </div>
          </div>

          {profilePreviewUrl ? (
            <div className="relative aspect-square w-full max-w-[180px] mx-auto mb-4 rounded-full border-4 border-emerald-500 overflow-hidden shadow-[0_0_30px_rgba(16,185,129,0.3)]">
              <img src={profilePreviewUrl} alt="Selfie" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => setIsBiometryActive(true)}
                className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center text-[10px] font-black uppercase tracking-widest text-white"
              >
                Trocar Foto
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setIsBiometryActive(true)}
              className="w-full py-5 rounded-2xl bg-emerald-500 text-black font-black uppercase tracking-widest shadow-[0_10px_30px_rgba(16,185,129,0.3)] active:scale-95 transition-all text-sm flex items-center justify-center gap-3"
            >
              <UserIcon size={20} /> INICIAR BIOMETRIA AGORA
            </button>
          )}

          {profilePhotoFile && (
            <div className="mt-4 p-3 bg-emerald-500/20 rounded-xl border border-emerald-500/30 flex items-center justify-center gap-2 text-xs font-bold text-emerald-400">
              <CheckCircle2 size={16} /> IDENTIDADE CONFIRMADA
            </div>
          )}
        </div>

        {/* Modal de Biometria */}
        <AnimatePresence>
          {isBiometryActive && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center p-6 text-center"
            >
              <h2 className="text-xl font-bold mb-2">BIOMETRIA 3D</h2>
              <p className="text-xs text-white/50 mb-12">Posicione seu rosto dentro do círculo.</p>

              <div className="relative w-72 h-72 mb-16">
                <div className="absolute inset-0 rounded-full border-2 border-white/20" />
                <div className="absolute inset-2 rounded-full border border-dashed border-emerald-500/30 animate-spin" />

                <div className="absolute inset-4 rounded-full overflow-hidden bg-black flex items-center justify-center border border-white/10 group">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="absolute inset-0 w-full h-full object-cover scale-[1.2] -scale-x-100"
                  />
                  <canvas ref={canvasRef} className="hidden" />

                  {biometryStep === 'IDLE' && (
                    <button
                      type="button"
                      onClick={capturePhoto}
                      className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-emerald-500 hover:bg-emerald-400 text-black px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-[0_0_20px_rgba(16,185,129,0.4)] z-10 transition-colors"
                    >
                      Tirar Foto Agora
                    </button>
                  )}
                  {biometryStep === 'SCANNING' && (
                    <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center gap-4 z-20">
                      <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                      <span className="text-[10px] font-black text-emerald-500 uppercase animate-pulse">Analisando...</span>
                    </div>
                  )}
                  {biometryStep === 'SUCCESS' && (
                    <div className="absolute inset-0 bg-emerald-500/30 backdrop-blur-sm flex flex-col items-center justify-center gap-3 z-20">
                      <div className="w-16 h-16 rounded-full bg-emerald-500 flex items-center justify-center text-black shadow-[0_0_20px_rgba(16,185,129,0.4)]">
                        <Check size={32} />
                      </div>
                      <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Sucesso</span>
                    </div>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsBiometryActive(false)}
                className="px-8 py-3 rounded-full bg-white/10 text-white/50 text-[10px] font-bold uppercase tracking-widest"
              >
                CANCELAR
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {docDriver.driverStatus === 'UNDER_REVIEW' ? (
          docAnalysisOpen ? (
            <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/85 p-6 pointer-events-auto">
              <div className="bg-[#111] border border-emerald-500/30 rounded-3xl p-8 max-w-sm w-full text-center space-y-4 shadow-2xl">
                <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                </div>
                <h2 className="text-xl font-bold text-emerald-400">Em análise</h2>
                <p className="text-sm text-white/60">Documentos enviados. Estamos verificando CNH, foto e ficha criminal.</p>
                <p className="text-[10px] text-white/40 uppercase tracking-widest">Ambiente de teste: aprovação automática em 5 segundos</p>
              </div>
            </div>
          ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center px-4">
            <div className="w-20 h-20 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center mb-6">
              <ShieldCheck size={40} />
            </div>
            <h2 className="text-xl font-bold text-orange-400 mb-2">Em Análise Técnica</h2>
            <p className="text-white/50 text-sm max-w-[280px] mb-10">As informações do seu veículo, CNH e certidões criminais estão em processamento pelo time de análise. Avisaremos quando sua conta for desbloqueada.</p>

            <div className="flex flex-col gap-4 w-full mt-10">
              <button
                onClick={async () => {
                  if (window.confirm("⚠️ Deseja cancelar o envio e recomeçar o cadastro? Isso apagará seus dados atuais para que você possa enviar novos arquivos.")) {
                    const success = await deleteDriverAccount(currentUser.id);
                    if (success) {
                      setCurrentUser(null);
                    }
                  }
                }}
                className="w-full py-4 rounded-2xl bg-white text-black text-[12px] font-black uppercase tracking-widest transition-all shadow-[0_10px_30px_rgba(255,255,255,0.3)] active:scale-95 flex items-center justify-center gap-2"
              >
                <Trash2 size={16} /> CANCELAR E REVER DOCUMENTOS
              </button>

              <button
                onClick={() => setCurrentUser(null)}
                className="w-full py-3 rounded-2xl bg-white/5 border border-white/10 text-white/50 text-[10px] font-bold uppercase tracking-widest hover:bg-white/10 transition-colors"
              >
                SAIR DA CONTA
              </button>
            </div>
          </div>
          )
        ) : (
          <form
            className="flex-1 flex flex-col gap-5 pb-12"
            onSubmit={async (e) => {
              e.preventDefault();
              setDocFeedback(null);

              if (!cnhFileName) {
                setDocFeedback({ type: 'error', message: "Por favor, anexe sua CNH para continuar." });
                return;
              }
              if (!docZipFileName) {
                setDocFeedback({ type: 'error', message: "Por favor, anexe suas Certidões Criminais para continuar." });
                return;
              }
              if (!criminalRecordName) {
                setDocFeedback({ type: 'error', message: 'Anexe a ficha criminal / antecedentes (PDF ou imagem).' });
                return;
              }

              if (parseInt(vehicleYear) < 2019) {
                setDocFeedback({ type: 'error', message: "Atenção! Conforme Lei Municipal nº 2.468 do IMMU, seu veículo de cadastro excede o limite (Ano mínimo: 2019)." });
                return;
              }

              if (!profilePhotoFile) {
                window.alert("⚠️ Realize a Biometria Facial antes de enviar.");
                return;
              }

              setIsSubmittingDocs(true);
              const success = await submitDriverDocs(currentUser.id, {
                plate: vehiclePlate,
                brand: vehicleBrand,
                model: vehicleModel,
                color: vehicleColor,
                year: vehicleYear,
                capacity: vehicleCapacity
              }, {
                cnh: cnhFile || undefined,
                crlv: crlvFile || undefined,
                certification: certificationFile || undefined,
                criminalRecord: criminalRecordFile || undefined,
                profile: profilePhotoFile || undefined
              });
              setIsSubmittingDocs(false);
              if (success) {
                setDocAnalysisOpen(true);
              }
            }}
          >

            {/* Mensagem de Recusa */}
            {docDriver.driverStatus === 'REJECTED' && (
              <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-500 flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <AlertOctagon size={18} />
                  <span className="text-[10px] uppercase tracking-widest font-bold">Cadastro Recusado</span>
                </div>
                <p className="text-xs text-white/90 leading-relaxed italic">
                  "{docDriver.rejectionReason || 'Documentos inconsistentes com a regulamentação.'}"
                </p>
                <div className="h-px bg-red-500/20 my-1" />
                <p className="text-[10px] text-red-400/70">Atualize os campos abaixo com as informações corretas e envie novamente para análise.</p>
              </div>
            )}

            {/* Feedback Visual */}
            {docFeedback && (
              <div className={`p-4 rounded-xl border text-sm flex gap-3 items-start ${docFeedback.type === 'error' ? 'bg-red-500/10 border-red-500/30 text-red-400' :
                docFeedback.type === 'warning' ? 'bg-amber-500/10 border-amber-500/30 text-amber-500' :
                  'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                }`}>
                {docFeedback.type === 'error' ? <AlertTriangle size={20} className="shrink-0" /> :
                  docFeedback.type === 'warning' ? <AlertOctagon size={20} className="shrink-0" /> :
                    <CheckCircle2 size={20} className="shrink-0" />}
                <p>{docFeedback.message}</p>
              </div>
            )}

            {/* 1.1 Dados Pessoais e CNH com EAR */}
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex items-center gap-3 mb-2">
                <CreditCard className="text-emerald-500" size={20} />
                <h3 className="font-bold text-sm">Validar CNH e CPF</h3>
              </div>
              <p className="text-[10px] text-white/50 mb-3 leading-relaxed">Você entrou como {currentUser.name} ({currentUser.cpf}). Anexe sua CNH (Foto ou PDF).</p>

              <label className={`w-full py-3 rounded-xl text-xs font-medium transition-colors flex items-center justify-center gap-2 cursor-pointer mt-3 border ${cnhFileName ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-white/10 hover:bg-white/20 border-transparent text-white'}`}>
                {cnhFileName ? (
                  <><CheckCircle2 size={16} /> CNH Anexada: {cnhFileName}</>
                ) : (
                  <>📸 Enviar Arquivo CNH + EAR</>
                )}
                <input type="file" className="hidden" accept="image/*,.pdf" capture="environment" onChange={handleCNHUpload} />
              </label>

              {cnhPreviewUrl && (
                <button
                  type="button"
                  onClick={() => window.open(cnhPreviewUrl, '_blank')}
                  className="w-full mt-2 py-2 px-4 rounded-xl bg-white/5 border border-white/10 text-[10px] text-emerald-400 font-bold uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-white/10 transition-colors"
                >
                  <Eye size={14} /> Visualizar CNH Anexada
                </button>
              )}
            </div>

            {/* 1.2 Registro do Veículo e Limites do IMMU */}
            <div className="bg-white/5 p-4 rounded-2xl border border-emerald-500/30">
              <div className="flex items-center gap-3 mb-2">
                <Car className="text-emerald-500" size={20} />
                <h3 className="font-bold text-sm">Veículo & CRLV Digital</h3>
              </div>
              <p className="text-[10px] text-white/50 mb-3 leading-relaxed">Art. da Lei Exige Vistoria. Apenas carros com 5 anos de fabricação e porta-malas condizente para passageiros.</p>

              <div className="grid grid-cols-2 gap-2 mb-2">
                <div className="bg-black/50 p-2 rounded-lg">
                  <label className="text-[9px] uppercase tracking-widest text-white/40 block mb-1">Placa Oficial</label>
                  <input type="text" value={vehiclePlate} onChange={e => setVehiclePlate(e.target.value)} required placeholder="XXX-0000" className="w-full bg-transparent text-white outline-none font-mono text-xs uppercase" />
                </div>
                <div className="bg-black/50 p-2 rounded-lg">
                  <label className="text-[9px] uppercase tracking-widest text-white/40 block mb-1">Ano Fab.</label>
                  <input type="number" min="2012" max="2026" value={vehicleYear} onChange={e => setVehicleYear(e.target.value)} required placeholder="2020" className="w-full bg-transparent text-white outline-none font-mono text-xs" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 mb-2">
                <div className="bg-black/50 p-2 rounded-lg">
                  <label className="text-[9px] uppercase tracking-widest text-white/40 block mb-1">Marca</label>
                  <input type="text" value={vehicleBrand} onChange={e => setVehicleBrand(e.target.value)} required placeholder="Fiat, GM..." className="w-full bg-transparent text-white outline-none text-xs" />
                </div>
                <div className="bg-black/50 p-2 rounded-lg">
                  <label className="text-[9px] uppercase tracking-widest text-white/40 block mb-1">Modelo</label>
                  <input type="text" value={vehicleModel} onChange={e => setVehicleModel(e.target.value)} required placeholder="Mobi, Onix..." className="w-full bg-transparent text-white outline-none text-xs" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-black/50 p-2 rounded-lg">
                  <label className="text-[9px] uppercase tracking-widest text-white/40 block mb-1">Cor Predom.</label>
                  <input type="text" value={vehicleColor} onChange={e => setVehicleColor(e.target.value)} required placeholder="Prata, Preto..." className="w-full bg-transparent text-white outline-none text-xs" />
                </div>
                <div className="bg-black/50 p-2 rounded-lg">
                  <label className="text-[9px] uppercase tracking-widest text-white/40 block mb-1">Passageiros (Máx 7)</label>
                  <input type="number" min="1" max="7" value={vehicleCapacity} onChange={e => setVehicleCapacity(e.target.value)} required className="w-full bg-transparent text-white outline-none text-xs" />
                </div>
              </div>
              <label className="w-full py-3 bg-white/10 rounded-xl text-xs font-medium hover:bg-white/20 transition-colors flex items-center justify-center gap-2 cursor-pointer mt-4 group">
                {isParsingPDF ? (
                  <span className="animate-pulse">🤖 Lendo Documento Oficial (PDF)...</span>
                ) : (
                  <>
                    📄 Upload Extrato CRLV PDF
                    <span className="text-[9px] text-emerald-400 opacity-70 group-hover:opacity-100">(Auto-Completar)</span>
                  </>
                )}
                <input type="file" className="hidden" accept=".pdf" onChange={handleCRLVUpload} disabled={isParsingPDF} />
              </label>

              {crlvPreviewUrl && (
                <button
                  type="button"
                  onClick={() => window.open(crlvPreviewUrl, '_blank')}
                  className="w-full mt-2 py-2 px-4 rounded-xl bg-white/5 border border-white/10 text-[10px] text-emerald-400 font-bold uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-white/10 transition-colors"
                >
                  <Eye size={14} /> Visualizar CRLV Anexado
                </button>
              )}
            </div>

            {/* 1.3 Auditoria Criminal / Extratos Negativos */}
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex items-center gap-3 mb-2">
                <ShieldAlert className="text-emerald-500" size={20} />
                <h3 className="font-bold text-sm">Termos LGPD + Certidões Negativas</h3>
              </div>
              <p className="text-[10px] text-white/50 mb-3 leading-relaxed">Emita suas certidões (PDF) gratuitas nos links oficiais do Governo:</p>

              <div className="flex flex-col gap-2 mb-4 bg-black/30 p-3 rounded-xl border border-white/5">
                <a href="https://sistemas.trf1.jus.br/certidao/#/solicitacao" target="_blank" rel="noopener noreferrer" className="text-[10px] text-emerald-400 hover:text-emerald-300 flex justify-between items-center group">
                  <span>1. Certidão Federal (TRF1)</span>
                  <span className="opacity-0 group-hover:opacity-100 transition-opacity transition-transform transform translate-x-1">→</span>
                </a>
                <a href="https://www.gov.br/pf/pt-br/assuntos/antecedentes-criminais" target="_blank" rel="noopener noreferrer" className="text-[10px] text-emerald-400 hover:text-emerald-300 flex justify-between items-center group">
                  <span>2. Antecedentes (Polícia Federal)</span>
                  <span className="opacity-0 group-hover:opacity-100 transition-opacity transition-transform transform translate-x-1">→</span>
                </a>
              </div>

              <div className="flex flex-col gap-3">
                <label className={`w-full py-3 rounded-xl text-xs font-medium transition-colors flex items-center justify-center gap-2 cursor-pointer border ${docZipFileName ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-white/10 hover:bg-white/20 border-transparent text-white'}`}>
                  {isParsingPDF ? (
                    <span className="animate-pulse">🤖 Validando Certidões...</span>
                  ) : docZipFileName ? (
                    <><CheckCircle2 size={16} /> Certidões Anexadas: {docZipFileName}</>
                  ) : (
                    <>📑 Anexar Certidões (Nada Consta)</>
                  )}
                  <input type="file" className="hidden" accept=".pdf" onChange={handleCertidaoUpload} disabled={isParsingPDF} />
                </label>

                <label className={`w-full py-3 rounded-xl text-xs font-medium transition-colors flex items-center justify-center gap-2 cursor-pointer border ${criminalRecordName ? 'bg-blue-500/10 border-blue-500/30 text-blue-400' : 'bg-white/10 hover:bg-white/20 border-transparent text-white'}`}>
                  {criminalRecordName ? (
                    <><CheckCircle2 size={16} /> Ficha criminal: {criminalRecordName}</>
                  ) : (
                    <>📋 Anexar ficha criminal / antecedentes</>
                  )}
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*,.pdf"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) {
                        setCriminalRecordFile(f);
                        setCriminalRecordName(f.name);
                      }
                    }}
                  />
                </label>

              </div>
            </div>


            <div className="flex items-start gap-3 mt-4 p-3 bg-emerald-500/5 rounded-xl border border-emerald-500/10">
              <input type="checkbox" id="lgpd-opt" required className="mt-1 flex-shrink-0 w-4 h-4 rounded appearance-none border border-emerald-500/50 checked:bg-emerald-500 checked:before:content-['✓'] checked:before:text-black checked:before:flex checked:before:justify-center checked:before:items-center checked:before:text-xs" />
              <label htmlFor="lgpd-opt" className="text-[9px] text-white/70 font-light leading-relaxed">
                Dou fé de apresentar meus verdadeiros documentos sob as penas da falsidade (Art. 299 CP). Autorizo criptografia da LGPD e integração nativa com Relatórios Fiscais da Secretaria de Segurança de Manaus, repassando logs de transações.
              </label>
            </div>

            <button
              type="submit"
              disabled={isSubmittingDocs}
              className={`w-full py-4 mt-6 rounded-2xl font-bold uppercase tracking-widest text-sm transition-colors shadow-[0_0_20px_rgba(16,185,129,0.2)] flex-shrink-0 ${isSubmittingDocs ? 'bg-emerald-800 text-white/50 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-500'}`}
            >
              {isSubmittingDocs ? 'Processando Autenticação Jurídica...' : 'Assinar Termos & Enviar Para Análise'}
            </button>
          </form>
        )
        }
      </div >
    );
  }

  return (
    <div className="flex flex-col h-screen bg-[#050505] text-white max-w-md mx-auto relative overflow-hidden font-sans">
      {/* Map Background */}
      <div className="absolute inset-0 z-0">
        {!apiKey ? (
          <div className="w-full h-full bg-[#1a1a1a] flex flex-col items-center justify-center text-white/50 p-6 text-center">
            <MapPin size={48} className="mb-4 opacity-50" />
            <p className="font-medium">Chave da API do Google Maps não configurada.</p>
            <p className="text-xs mt-2">Adicione NEXT_PUBLIC_GOOGLE_MAPS_API_KEY nas variáveis de ambiente.</p>
          </div>
        ) : loadError ? (
          <div className="w-full h-full bg-[#1a1a1a] flex flex-col items-center justify-center text-white/50 p-6 text-center">
            <ShieldAlert size={48} className="mb-4 opacity-50 text-red-400" />
            <p className="font-medium">Erro ao carregar o mapa.</p>
            <p className="text-xs mt-2">Verifique se a chave da API é válida e se a Maps JavaScript API está ativada no Google Cloud Console.</p>
          </div>
        ) : isLoaded ? (
          <GoogleMap
            mapContainerStyle={mapContainerStyle}
            center={mapCenter}
            zoom={mapZoom}
            onLoad={(map) => {
              setMapRef(map);
              if (isDriveMode) {
                map.setTilt(45);
                map.setHeading(carHeading);
              }
            }}
            onDragStart={() => setIsAutoCenter(false)}
            options={{
              mapId: "DEMO_MAP_ID",
              disableDefaultUI: true,
              zoomControl: false,
              gestureHandling: "greedy",
              styles: [
                { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
                { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
                { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
                {
                  featureType: "administrative.locality",
                  elementType: "labels.text.fill",
                  stylers: [{ color: "#d59563" }],
                },
                {
                  featureType: "poi",
                  elementType: "labels.text.fill",
                  stylers: [{ color: "#d59563" }],
                },
                {
                  featureType: "poi.park",
                  elementType: "geometry",
                  stylers: [{ color: "#263c3f" }],
                },
                {
                  featureType: "poi.park",
                  elementType: "labels.text.fill",
                  stylers: [{ color: "#6b9a76" }],
                },
                {
                  featureType: "road",
                  elementType: "geometry",
                  stylers: [{ color: "#38414e" }],
                },
                {
                  featureType: "road",
                  elementType: "geometry.stroke",
                  stylers: [{ color: "#212a37" }],
                },
                {
                  featureType: "road",
                  elementType: "labels.text.fill",
                  stylers: [{ color: "#9ca5b3" }],
                },
                {
                  featureType: "road.highway",
                  elementType: "geometry",
                  stylers: [{ color: "#746855" }],
                },
                {
                  featureType: "road.highway",
                  elementType: "geometry.stroke",
                  stylers: [{ color: "#1f2835" }],
                },
                {
                  featureType: "road.highway",
                  elementType: "labels.text.fill",
                  stylers: [{ color: "#f3d19c" }],
                },
                {
                  featureType: "transit",
                  elementType: "geometry",
                  stylers: [{ color: "#2f3948" }],
                },
                {
                  featureType: "transit.station",
                  elementType: "labels.text.fill",
                  stylers: [{ color: "#d59563" }],
                },
                {
                  featureType: "water",
                  elementType: "geometry",
                  stylers: [{ color: "#17263c" }],
                },
                {
                  featureType: "water",
                  elementType: "labels.text.fill",
                  stylers: [{ color: "#515c6d" }],
                },
                {
                  featureType: "water",
                  elementType: "labels.text.stroke",
                  stylers: [{ color: "#17263c" }],
                },
              ],
            }}
          >
            {directionsResponse && (
              <>
                <DirectionsRenderer
                  directions={directionsResponse}
                  options={{
                    suppressMarkers: true,
                    suppressPolylines: true, // Explicitly suppress default polyline to hide traffic colors
                    preserveViewport: true,
                  }}
                />
                {/* Dynamic Route Polyline */}
                <Polyline
                  key={activeRide?.id} // Force re-mount on new ride
                  path={directionsResponse.routes[0].overview_path}
                  onLoad={(polyline) => {
                    routePolylineRef.current = polyline;
                  }}
                  options={{
                    strokeColor: "#3b82f6",
                    strokeWeight: 5,
                    strokeOpacity: 1,
                    zIndex: 10
                  }}
                />
              </>
            )}

            {/* Traffic Layer Removed as requested */}

            {/* Hotspots Visualization */}
            {hotspots.filter(h => h.active).map(hotspot => (
              <div key={hotspot.id}>
                <Circle
                  center={{ lat: hotspot.lat, lng: hotspot.lng }}
                  radius={hotspot.radius}
                  options={{
                    fillColor: '#10b981', // Emerald 500
                    fillOpacity: 0.15,
                    strokeColor: '#10b981',
                    strokeOpacity: 0.5,
                    strokeWeight: 1,
                    clickable: false,
                  }}
                />
                <OverlayViewF
                  position={{ lat: hotspot.lat, lng: hotspot.lng }}
                  mapPaneName="overlayMouseTarget"
                >
                  <div className="bg-emerald-500 text-black px-2 py-1 rounded-full text-xs font-bold shadow-md transform -translate-x-1/2 -translate-y-1/2 border border-white/20 whitespace-nowrap flex items-center gap-1">
                    <TrendingUp size={12} />
                    {hotspot.multiplier}x
                  </div>
                </OverlayViewF>
              </div>
            ))}

            {/* Route to Hotspot */}
            {hotspotRouteResponse && (
              <DirectionsRenderer
                directions={hotspotRouteResponse}
                options={{
                  suppressMarkers: false,
                  polylineOptions: {
                    strokeColor: '#10b981', // Emerald for opportunity route
                    strokeOpacity: 0.8,
                    strokeWeight: 5,
                    zIndex: 5
                  }
                }}
              />
            )}

            {showHeatmap && surgePricingZones.map((zone) => (
              <OverlayViewF
                key={`surge-${zone.id}`}
                position={{ lat: zone.lat, lng: zone.lng }}
                mapPaneName="overlayMouseTarget"
              >
                <div className="bg-[#d9534f] text-white px-2 py-1 rounded-full text-xs font-bold shadow-md transform -translate-x-1/2 -translate-y-1/2 border border-white/20 whitespace-nowrap">
                  +R$ {zone.value.toFixed(2).replace('.', ',')}
                </div>
              </OverlayViewF>
            ))}

            {activeRide && !carAnimPosition && (
              <>
                <Marker
                  position={{ lat: activeRide.origin.lat, lng: activeRide.origin.lng }}
                  icon={{
                    path: window.google.maps.SymbolPath.CIRCLE,
                    scale: 8,
                    fillColor: "#3b82f6",
                    fillOpacity: 1,
                    strokeWeight: 2,
                    strokeColor: "#ffffff",
                  }}
                />
                <Marker
                  position={{ lat: activeRide.destination.lat, lng: activeRide.destination.lng }}
                  icon={{
                    path: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z",
                    fillColor: "#ef4444",
                    fillOpacity: 1,
                    strokeWeight: 1,
                    strokeColor: "#ffffff",
                    scale: 1.5,
                    anchor: new window.google.maps.Point(12, 24)
                  }}
                />
              </>
            )}

            {/* My Car Location (When Online) */}
            {isOnline && (driverMe?.location || mapCenter) && !carAnimPosition && (
              <Marker
                position={
                  driverMe?.location
                    ? { lat: driverMe.location.lat, lng: driverMe.location.lng }
                    : { lat: mapCenter.lat, lng: mapCenter.lng }
                }
                zIndex={51}
                icon={{
                  path: window.google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                  scale: 6,
                  fillColor: '#22c55e',
                  fillOpacity: 1,
                  strokeColor: '#ffffff',
                  strokeWeight: 2,
                  rotation: deviceHeading,
                  anchor: new window.google.maps.Point(0, 3),
                }}
              />
            )}

            {carAnimPosition && (
              <>
                {/* Car Shadow */}
                <Marker
                  position={carAnimPosition}
                  zIndex={50}
                  icon={{
                    path: "M8,8 H42 V92 H8 Z",
                    scale: 0.35,
                    fillColor: "#000000",
                    fillOpacity: 0.2,
                    strokeWeight: 0,
                    rotation: carHeading,
                    anchor: new window.google.maps.Point(21, 46) // Offset shadow
                  }}
                />
                {/* Car Body (Yellow) */}
                <Marker
                  position={carAnimPosition}
                  zIndex={51}
                  icon={{
                    path: "M20,10 C20,5 30,0 50,0 C70,0 80,5 80,10 V90 C80,95 70,100 50,100 C30,100 20,95 20,90 Z M25,20 C25,20 35,15 50,15 C65,15 75,20 75,20 V35 C75,35 65,38 50,38 C35,38 25,35 25,35 Z M25,45 H75 V75 C75,75 60,80 50,80 C40,80 25,75 25,75 Z M18,25 L12,26 C11,27 11,33 12,34 L18,33 V25 Z M82,25 L88,26 C89,27 89,33 88,34 L82,33 V25 Z",
                    scale: 0.45,
                    fillColor: "#ffeb3b",
                    fillOpacity: 1,
                    strokeWeight: 2,
                    strokeColor: "#f59e0b",
                    rotation: carHeading,
                    anchor: new window.google.maps.Point(50, 50)
                  }}
                />
                {/* Car Roof (Orange-Yellow) */}
                <Marker
                  position={carAnimPosition}
                  zIndex={52}
                  icon={{
                    path: "M14,35 H36 V75 H14 Z",
                    scale: 0.35,
                    fillColor: "#F59E0B",
                    fillOpacity: 1,
                    strokeWeight: 0,
                    rotation: carHeading,
                    anchor: new window.google.maps.Point(25, 50)
                  }}
                />
                {/* Car Windows (Blue) */}
                <Marker
                  position={carAnimPosition}
                  zIndex={53}
                  icon={{
                    path: "M12,20 L14,35 H36 L38,20 Q25,15 12,20 Z M14,75 L12,90 Q25,95 38,90 L36,75 Z",
                    scale: 0.35,
                    fillColor: "#3B82F6",
                    fillOpacity: 1,
                    strokeWeight: 0,
                    rotation: carHeading,
                    anchor: new window.google.maps.Point(25, 50)
                  }}
                />
                {/* Side Mirrors (Yellow) */}
                <Marker
                  position={carAnimPosition}
                  zIndex={52}
                  icon={{
                    path: "M6,25 H10 V32 H6 Z M40,25 H44 V32 H40 Z",
                    scale: 0.35,
                    fillColor: "#FFC107",
                    fillOpacity: 1,
                    strokeWeight: 1,
                    strokeColor: "#D97706",
                    rotation: carHeading,
                    anchor: new window.google.maps.Point(25, 50)
                  }}
                />
              </>
            )}

            {/* Hotspots Visualization */}
            {hotspots.filter(h => h.active).map(hotspot => (
              <div key={hotspot.id}>
                <Circle
                  center={{ lat: hotspot.lat, lng: hotspot.lng }}
                  radius={hotspot.radius}
                  options={{
                    fillColor: '#10b981', // Emerald 500
                    fillOpacity: 0.15,
                    strokeColor: '#10b981',
                    strokeOpacity: 0.5,
                    strokeWeight: 1,
                    clickable: false,
                  }}
                />
                <OverlayViewF
                  position={{ lat: hotspot.lat, lng: hotspot.lng }}
                  mapPaneName="overlayMouseTarget"
                >
                  <div className="bg-emerald-500 text-black px-2 py-1 rounded-full text-xs font-bold shadow-md transform -translate-x-1/2 -translate-y-1/2 border border-white/20 whitespace-nowrap flex items-center gap-1">
                    <TrendingUp size={12} />
                    {hotspot.multiplier}x
                  </div>
                </OverlayViewF>
              </div>
            ))}

            {/* Route to Hotspot */}
            {hotspotRouteResponse && (
              <DirectionsRenderer
                directions={hotspotRouteResponse}
                options={{
                  suppressMarkers: false,
                  polylineOptions: {
                    strokeColor: '#10b981', // Emerald for opportunity route
                    strokeOpacity: 0.8,
                    strokeWeight: 5,
                    zIndex: 5
                  }
                }}
              />
            )}
          </GoogleMap>
        ) : (
          <div className="w-full h-full bg-[#1a1a1a] flex items-center justify-center text-white/50">Carregando Mapa...</div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-[#050505] pointer-events-none"></div>
      </div>

      {/* Header */}
      <header className="absolute top-0 inset-x-0 p-6 z-20 flex justify-between items-center pointer-events-none">
        <div className="flex items-center gap-3 pointer-events-auto">
          <button
            onClick={() => setShowMenu(true)}
            className="w-10 h-10 rounded-full glass-panel flex items-center justify-center border border-white/10 hover:bg-white/10 transition-colors"
          >
            <Menu size={20} />
          </button>
          <div className="text-xl font-bold tracking-tighter drop-shadow-md">INVIAGEM<span className="text-emerald-500">.</span></div>
        </div>
        <div className="flex items-center gap-4 pointer-events-auto">
          <button
            onClick={() => {
              const newShowHeatmap = !showHeatmap;
              setShowHeatmap(newShowHeatmap);

              if (newShowHeatmap && mapCenter) {
                // Generate zones
                const zones = Array.from({ length: 5 }).map((_, i) => {
                  const latOffset = (Math.random() - 0.5) * 0.05;
                  const lngOffset = (Math.random() - 0.5) * 0.05;
                  const value = Math.floor(Math.random() * 8) + 1 + (Math.random() > 0.5 ? 0.25 : 0.75);
                  return {
                    id: i,
                    lat: mapCenter.lat + latOffset,
                    lng: mapCenter.lng + lngOffset,
                    value: value
                  };
                });
                setSurgePricingZones(zones);
              } else {
                setSurgePricingZones([]);
              }
            }}
            className={`w-10 h-10 rounded-full flex items-center justify-center border transition-colors ${showHeatmap ? 'bg-red-500/20 border-red-500/50 text-red-500' : 'glass-panel border-white/10 hover:bg-white/10 text-white/70'}`}
            title="Mapa de Calor de Demanda"
          >
            <Flame size={20} />
          </button>

          {!activeRide && (
            <button
              onClick={activeHotspot ? clearHotspotRoute : handleFindBestSpot}
              className={`w-10 h-10 rounded-full flex items-center justify-center border transition-colors ${activeHotspot ? 'bg-emerald-500 text-black border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)]' : 'glass-panel border-white/10 hover:bg-white/10 text-emerald-400'}`}
              title={activeHotspot ? "Cancelar Rota" : "Encontrar Melhor Local"}
            >
              {activeHotspot ? <X size={20} /> : <TrendingUp size={20} />}
            </button>
          )}

          <div className="w-10 h-10 rounded-full glass-panel flex items-center justify-center text-sm font-medium border border-white/10">
            {currentUser.name.charAt(0)}
          </div>
        </div>
      </header>

      {/* Fase 1: Dashboard de Metas e Filtros Rápidos */}
      {!activeRide && activeTab === 'home' && (
        <div className="absolute top-24 inset-x-4 z-20 flex flex-col gap-2 pointer-events-none">
          <div className="glass-panel p-3 rounded-2xl border border-white/10 pointer-events-auto flex flex-col gap-2 bg-black/40 backdrop-blur-md">
            <div className="flex justify-between items-center">
              <span className="text-xs text-white/70 flex items-center gap-1"><Target size={12} /> Meta Diária</span>
              <span className="text-xs font-bold text-emerald-400">R$ {currentEarnings.toFixed(2)} / R$ {dailyGoal.toFixed(2)}</span>
            </div>
            <div className="w-full bg-white/10 rounded-full h-1.5">
              <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${(currentEarnings / dailyGoal) * 100}%` }}></div>
            </div>
          </div>

          <div className="flex gap-2 pointer-events-auto mt-1">
            <button
              onClick={() => setIsGoingHome(!isGoingHome)}
              className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 text-[10px] uppercase tracking-wider font-bold transition-colors border ${isGoingHome ? 'bg-blue-600/90 border-blue-500 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]' : 'glass-panel border-white/10 text-white/70 hover:bg-white/10'}`}
            >
              <Home size={14} />
              {isGoingHome ? 'Destino: Casa' : 'Filtro Destino'}
            </button>
            <button
              onClick={() => setAutoAccept(!autoAccept)}
              className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 text-[10px] uppercase tracking-wider font-bold transition-colors border ${autoAccept ? 'bg-emerald-600/90 border-emerald-500 text-white shadow-[0_0_15px_rgba(16,185,129,0.4)]' : 'glass-panel border-white/10 text-white/70 hover:bg-white/10'}`}
            >
              <TrendingUp size={14} />
              {autoAccept ? 'Auto-Aceitar ON' : 'Radar Ganhos'}
            </button>
            <button
              onClick={() => setIsPaused(!isPaused)}
              className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-2 text-[10px] uppercase tracking-wider font-bold transition-colors border ${isPaused ? 'bg-orange-600/90 border-orange-500 text-white shadow-[0_0_15px_rgba(234,88,12,0.4)]' : 'glass-panel border-white/10 text-white/70 hover:bg-white/10'}`}
            >
              <Coffee size={14} />
              {isPaused ? 'Em Pausa (15m)' : 'Pausa Café'}
            </button>
          </div>
        </div>
      )}

      {/* Side Menu / Drawer */}
      <AnimatePresence>
        {showMenu && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMenu(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm z-40"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="absolute inset-y-0 left-0 w-72 bg-[#0a0a0a] border-r border-white/10 z-50 p-6 flex flex-col"
            >
              <div className="flex justify-between items-center mb-10">
                <div className="text-xl font-bold tracking-tighter">INVIAGEM<span className="text-emerald-500">.</span></div>
                <button onClick={() => setShowMenu(false)} className="text-white/40 hover:text-white">&times;</button>
              </div>

              <div className="space-y-1 flex-1">
                <p className="text-[10px] uppercase tracking-widest text-white/30 mb-4 ml-2">Modo de Uso</p>
                <button
                  onClick={() => { setShowMenu(false); router.push('/passenger'); }}
                  className="w-full flex items-center gap-4 p-4 rounded-2xl hover:bg-white/5 text-white/60 hover:text-white transition-colors"
                >
                  <UserIcon size={20} />
                  <span className="font-medium">Passageiro</span>
                </button>
                <button
                  onClick={() => { setShowMenu(false); router.push('/driver'); }}
                  className="w-full flex items-center gap-4 p-4 rounded-2xl bg-emerald-600/10 text-emerald-400 border border-emerald-500/20"
                >
                  <Car size={20} />
                  <span className="font-medium">Motorista</span>
                </button>
                <div className="pt-4 mt-4 border-t border-white/5">
                  <p className="text-[10px] uppercase tracking-widest text-white/30 mb-4 ml-2">Configurações</p>
                  <button
                    onClick={() => setDemoMode(!isDemoMode)}
                    className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-colors ${isDemoMode ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-white/5 border-white/10 text-white/40'}`}
                  >
                    <div className="flex items-center gap-4">
                      <ShieldAlert size={20} />
                      <span className="font-medium text-sm">Modo Simulação</span>
                    </div>
                    <div className={`w-10 h-5 rounded-full relative transition-colors ${isDemoMode ? 'bg-emerald-500' : 'bg-white/20'}`}>
                      <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${isDemoMode ? 'right-1' : 'left-1'}`} />
                    </div>
                  </button>
                </div>
              </div>

              <div className="pt-6 border-t border-white/5">
                <div className="flex items-center gap-3 p-2">
                  <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center font-medium">
                    {currentUser.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{currentUser.name}</p>
                    <p className="text-[10px] text-white/40 uppercase tracking-tighter">Driver Partner</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* GLOBAL ERROR MODAL */}
      <AnimatePresence>
        {globalError && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="absolute top-4 left-4 right-4 z-50 bg-red-500/90 border border-red-500 rounded-2xl p-4 shadow-lg backdrop-blur-md"
          >
            <div className="flex items-center gap-3">
              <AlertOctagon size={20} className="text-white shrink-0" />
              <p className="text-sm font-semibold text-white">{globalError.message}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 relative pt-24 pb-28 pointer-events-none">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && !activeRide && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full flex flex-col items-center justify-center p-6 space-y-12 relative pointer-events-none"
            >
              <div className="relative pointer-events-auto mt-auto mb-8 w-full flex justify-center">
                {currentUser.walletBalance !== undefined && currentUser.walletBalance < 0 && (
                  <button
                    onClick={() => setActiveTab('earnings')}
                    className="relative px-8 py-4 rounded-full flex flex-col items-center justify-center gap-1 transition-all duration-500 border border-red-500/50 bg-red-500/20 text-red-500 shadow-[0_0_20px_rgba(239,68,68,0.3)] w-full mb-4"
                  >
                    <AlertTriangle size={24} className="animate-pulse" />
                    <span className="text-sm font-mono uppercase tracking-widest font-bold">
                      Saldo Negativo (Bloqueado)
                    </span>
                    <span className="text-[10px] text-white/70">Você deve taxas ao App. As corridas não vão tocar.</span>
                  </button>
                )}
              </div>
              <p className="text-center text-white/40 max-w-[250px] text-xs font-light leading-relaxed">
                {isOnline
                  ? (isPaused ? 'Você está em pausa.' : searchMessage)
                  : 'Fique online para receber corridas.'}
              </p>

              {/* Incoming Request Modal */}
              <AnimatePresence>
                {isOnline && incomingRide && (
                  <motion.div
                    key="incoming"
                    initial={{ opacity: 0, y: 50, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 50, scale: 0.95 }}
                    className="absolute inset-x-4 bottom-0 glass-panel rounded-[2rem] p-6 border border-emerald-500/30 z-50 flex flex-col gap-6 shadow-[0_0_50px_rgba(16,185,129,0.1)] pointer-events-auto"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-emerald-400 font-medium tracking-wide">Nova Solicitação</h3>
                        <p className="text-white/50 text-xs font-mono mt-1 uppercase tracking-widest">{incomingRide.category} • 2.5 KM</p>

                        {/* Fase 2: Badges de Segurança e Novos Tipos */}
                        <div className="flex gap-2 mt-3 flex-wrap">
                          <span className="bg-emerald-500/20 text-emerald-400 text-[9px] uppercase tracking-wider font-bold px-2 py-1 rounded-md flex items-center gap-1 border border-emerald-500/30">
                            <ShieldCheck size={10} /> {incomingRide.isTerminalRide ? 'Integração Terminal' : 'Verificado'}
                          </span>
                          {incomingRide.rideType === 'WOMEN_ONLY' && (
                            <span className="bg-fuchsia-500/20 text-fuchsia-400 text-[9px] uppercase tracking-wider font-bold px-2 py-1 rounded-md flex items-center gap-1 border border-fuchsia-500/30">
                              <UserIcon size={10} /> Só Mulheres
                            </span>
                          )}
                          {incomingRide.rideType === 'PET' && (
                            <span className="bg-blue-500/20 text-blue-400 text-[9px] uppercase tracking-wider font-bold px-2 py-1 rounded-md flex items-center gap-1 border border-blue-500/30">
                              <AlertCircle size={10} /> Pet Friendly
                            </span>
                          )}
                          {incomingRide.estimatedPrice > 30 && (
                            <span className="bg-orange-500/20 text-orange-400 text-[9px] uppercase tracking-wider font-bold px-2 py-1 rounded-md flex items-center gap-1 border border-orange-500/30">
                              <AlertTriangle size={10} /> Zona Laranja
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-light">
                          R$ {(incomingRide.offeredPrice || incomingRide.estimatedPrice).toFixed(2).replace('.', ',')}
                        </div>
                        {incomingRide.offeredPrice && incomingRide.offeredPrice !== incomingRide.estimatedPrice && (
                          <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider mb-1">Oferta do Passageiro</div>
                        )}
                        <div className="text-xs text-white/50 font-mono mt-1 uppercase tracking-widest">~{incomingRide.estimatedTime} MIN</div>
                      </div>
                    </div>

                    <div className="space-y-4 bg-white/5 p-4 rounded-2xl border border-white/5">
                      <div className="flex items-start gap-4">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 shadow-[0_0_10px_rgba(16,185,129,0.8)]"></div>
                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-white/40 mb-1">Origem</p>
                          <p className="font-medium text-sm">{incomingRide.origin.address}</p>
                        </div>
                      </div>
                      {(incomingRide.waypoints || []).map((w, i) => (
                        <div key={`wp-${i}`}>
                          <div className="w-px h-4 bg-white/10 ml-1"></div>
                          <div className="flex items-start gap-4">
                            <div className="w-2 h-2 rounded-full bg-amber-400 mt-1.5 shrink-0"></div>
                            <div>
                              <p className="text-[10px] uppercase tracking-widest text-white/40 mb-1">Parada {i + 1}</p>
                              <p className="font-medium text-sm">
                                {w.address?.trim() ||
                                  (Number.isFinite(w.lat) && Number.isFinite(w.lng)
                                    ? `${w.lat.toFixed(4)}, ${w.lng.toFixed(4)}`
                                    : 'Ponto no trajeto')}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                      <div className="w-px h-4 bg-white/10 ml-1"></div>
                      <div className="flex items-start gap-4">
                        <div className="w-2 h-2 rounded-full bg-white mt-1.5"></div>
                        <div>
                          <p className="text-[10px] uppercase tracking-widest text-white/40 mb-1">Destino</p>
                          <p className="font-medium text-sm">{incomingRide.destination.address}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-3">
                      <div className="flex gap-3">
                        <button
                          onClick={() => handleReject(incomingRide.id)}
                          className="flex-1 py-4 rounded-2xl bg-white/5 text-white/80 font-medium flex items-center justify-center gap-2 hover:bg-white/10 transition-colors border border-white/10"
                        >
                          <X size={20} />
                          Recusar
                        </button>
                        <button
                          onClick={() => handleAccept(incomingRide.id)}
                          className="flex-1 py-4 rounded-2xl bg-emerald-500 text-black font-medium flex items-center justify-center gap-2 hover:bg-emerald-400 transition-colors"
                        >
                          <Check size={20} />
                          Aceitar
                        </button>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleCounterOffer(incomingRide.id, incomingRide.offeredPrice || incomingRide.estimatedPrice, 2)}
                          className="flex-1 py-3 rounded-xl bg-white/5 text-white/60 text-xs font-medium border border-white/10 hover:bg-white/10 transition-colors"
                        >
                          + R$ 2,00
                        </button>
                        <button
                          onClick={() => handleCounterOffer(incomingRide.id, incomingRide.offeredPrice || incomingRide.estimatedPrice, 5)}
                          className="flex-1 py-3 rounded-xl bg-white/5 text-white/60 text-xs font-medium border border-white/10 hover:bg-white/10 transition-colors"
                        >
                          + R$ 5,00
                        </button>
                        <button
                          onClick={() => handleCounterOffer(incomingRide.id, incomingRide.offeredPrice || incomingRide.estimatedPrice, 10)}
                          className="flex-1 py-3 rounded-xl bg-white/5 text-white/60 text-xs font-medium border border-white/10 hover:bg-white/10 transition-colors"
                        >
                          + R$ 10,00
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {/* Active Ride View */}
          {activeRide && (
            <motion.div
              key="active-ride"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="h-full flex flex-col absolute inset-0 z-10 pointer-events-none"
            >
              {/* Map Placeholder */}
              <div className="flex-1 relative overflow-hidden pointer-events-none">
                {/* Drive Mode Maneuver HUD */}
                {isDriveMode && currentManeuver && activeRide?.status === 'IN_PROGRESS' && (
                  <div className="absolute top-36 left-4 right-20 z-20 pointer-events-none">
                    <div className="bg-emerald-600 text-white p-4 rounded-2xl shadow-lg flex items-center gap-4">
                      <Navigation size={32} className="shrink-0" />
                      <div className="flex-1">
                        <p className="text-sm font-bold uppercase tracking-wider opacity-80">Próxima Manobra</p>
                        <p className="text-lg font-medium leading-tight">{currentManeuver}</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Re-center Button */}
                {!isAutoCenter && (
                  <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-50 pointer-events-auto">
                    <button
                      onClick={() => {
                        setIsAutoCenter(true);
                        if (carAnimPosition) setMapCenter(carAnimPosition);
                      }}
                      className="bg-white text-blue-600 px-4 py-2 rounded-full shadow-lg flex items-center gap-2 font-medium hover:bg-gray-50 transition-colors"
                    >
                      <Navigation size={16} className="fill-current" />
                      Re-center
                    </button>
                  </div>
                )}

                <div className="absolute top-24 right-4 z-30 flex flex-col gap-2 pointer-events-auto">
                  {/* Drive Mode Button */}
                  <button
                    onClick={() => {
                      const newMode = !isDriveMode;
                      setIsDriveMode(newMode);
                      if (mapRef) {
                        if (newMode) {
                          mapRef.setTilt(45);
                          mapRef.setHeading(carHeading);
                          setMapZoom(18);
                        } else {
                          mapRef.setTilt(0);
                          mapRef.setHeading(0);
                          setMapZoom(15);
                        }
                      }
                    }}
                    className={`w-12 h-12 rounded-full backdrop-blur-md border flex items-center justify-center transition-colors shadow-lg ${isDriveMode ? 'bg-emerald-500 text-black border-emerald-400' : 'bg-black/60 text-white/50 border-white/10 hover:bg-white/10'}`}
                    title="Modo Direção (GPS 3D)"
                  >
                    <Map size={20} />
                  </button>

                  {/* Fase 3: Alertas na Via */}
                  {activeRide.status === 'IN_PROGRESS' && (
                    <button className="w-12 h-12 rounded-full bg-black/60 backdrop-blur-md border border-white/10 flex items-center justify-center text-red-400 hover:bg-white/10 transition-colors shadow-lg" title="Reportar Buraco/Perigo">
                      <AlertOctagon size={20} />
                    </button>
                  )}

                  {/* External Navigation Buttons */}
                  {(activeRide.status === 'DRIVER_ASSIGNED' || activeRide.status === 'IN_PROGRESS') && (
                    <>
                      <button
                        onClick={() => {
                          const dest = activeRide.status === 'DRIVER_ASSIGNED' ? activeRide.origin : activeRide.destination;
                          window.open(`https://www.google.com/maps/dir/?api=1&destination=${dest.lat},${dest.lng}`, '_blank');
                        }}
                        className="w-12 h-12 rounded-full bg-black/60 backdrop-blur-md border border-white/10 flex items-center justify-center text-blue-400 hover:bg-white/10 transition-colors shadow-lg"
                        title="Abrir no Google Maps"
                      >
                        <Map size={20} />
                      </button>
                      <button
                        onClick={() => {
                          const dest = activeRide.status === 'DRIVER_ASSIGNED' ? activeRide.origin : activeRide.destination;
                          window.open(`https://waze.com/ul?ll=${dest.lat},${dest.lng}&navigate=yes`, '_blank');
                        }}
                        className="w-12 h-12 rounded-full bg-black/60 backdrop-blur-md border border-white/10 flex items-center justify-center text-cyan-400 hover:bg-white/10 transition-colors shadow-lg"
                        title="Abrir no Waze"
                      >
                        <Navigation size={20} />
                      </button>
                    </>
                  )}
                </div>

                <div className="absolute top-24 left-4 z-10 pointer-events-auto">
                  <span className="font-medium text-xs tracking-widest uppercase bg-black/60 backdrop-blur-md border border-white/10 px-4 py-2 rounded-full text-emerald-400 shadow-lg">
                    {activeRide.status === 'DRIVER_ASSIGNED' && 'Navegando até o Local'}
                    {activeRide.status === 'DRIVER_ARRIVING' && 'Passageiro Embarcando'}
                    {activeRide.status === 'IN_PROGRESS' && 'A Caminho do Destino'}
                    {activeRide.status === 'COMPLETED' && 'Aguardando Pagamento'}
                  </span>
                </div>
              </div>

              {/* Controls Bottom Sheet */}
              <div className="glass-panel rounded-t-[2rem] p-5 space-y-4 z-20 border-t border-white/10 pointer-events-auto transition-all duration-300">
                <div
                  className="flex justify-between items-center cursor-pointer"
                  onClick={() => setIsRideInfoExpanded(!isRideInfoExpanded)}
                >
                  <div>
                    <h3 className="text-lg font-light tracking-tight">Nome do Passageiro</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-[10px] text-white/50 font-mono uppercase tracking-widest">Cartão</p>
                      <span className="bg-emerald-500/20 text-emerald-400 text-[9px] uppercase tracking-wider font-bold px-1.5 py-0.5 rounded flex items-center gap-1">
                        <ShieldCheck size={8} /> Verificado
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-emerald-400 hover:bg-white/10 transition-colors" onClick={(e) => { e.stopPropagation(); /* alert */ }}>
                      <AlertCircle size={18} />
                    </button>
                    <button className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/50 hover:bg-white/10 transition-colors">
                      {isRideInfoExpanded ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
                    </button>
                  </div>
                </div>

                <AnimatePresence>
                  {isRideInfoExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="space-y-4 overflow-hidden"
                    >
                      {/* Fase 2: Ferramentas de Segurança e Chat */}
                      <div className="flex gap-2 mb-2 pt-2">
                        <button
                          onClick={() => setIsRecordingAudio(!isRecordingAudio)}
                          className={`flex-1 py-2.5 rounded-xl flex flex-col items-center justify-center gap-1.5 border transition-colors ${isRecordingAudio ? 'bg-red-500/20 border-red-500 text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)]' : 'bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white/80'}`}
                        >
                          <Mic size={18} className={isRecordingAudio ? 'animate-pulse' : ''} />
                          <span className="text-[9px] uppercase tracking-wider font-bold">Áudio</span>
                        </button>
                        <button
                          onClick={() => setIsDashcamActive(!isDashcamActive)}
                          className={`flex-1 py-2.5 rounded-xl flex flex-col items-center justify-center gap-1.5 border transition-colors ${isDashcamActive ? 'bg-blue-500/20 border-blue-500 text-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.3)]' : 'bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white/80'}`}
                        >
                          <Video size={18} className={isDashcamActive ? 'animate-pulse' : ''} />
                          <span className="text-[9px] uppercase tracking-wider font-bold">Dashcam</span>
                        </button>
                        <button
                          onClick={() => setShowChat(true)}
                          className="flex-1 py-2.5 rounded-xl flex flex-col items-center justify-center gap-1.5 border bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white/80 transition-colors relative"
                        >
                          <MessageSquare size={18} />
                          <span className="text-[9px] uppercase tracking-wider font-bold">Chat</span>
                          {activeRide?.messages && activeRide.messages.length > 0 && activeRide.messages[activeRide.messages.length - 1].senderId !== currentUser?.id && (
                            <span className="absolute top-2 right-4 w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                          )}
                        </button>
                      </div>

                      <div className="space-y-4 bg-white/5 p-4 rounded-2xl border border-white/5">
                        <div className="flex items-center gap-4">
                          <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.8)]"></div>
                          <p className="text-sm truncate text-white/80">{activeRide.origin.address}</p>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="w-2 h-2 rounded-full bg-white"></div>
                          <p className="text-sm truncate text-white/80">{activeRide.destination.address}</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {activeRide.status === 'DRIVER_ASSIGNED' && (
                  <button onClick={handleArrived} className="w-full bg-emerald-500 text-black py-4 rounded-2xl font-medium hover:bg-emerald-400 transition-colors">
                    Cheguei no Local
                  </button>
                )}
                {activeRide.status === 'DRIVER_ARRIVING' && (
                  <button onClick={handleStartTrip} className="w-full bg-blue-500 text-white py-4 rounded-2xl font-medium hover:bg-blue-400 transition-colors">
                    Iniciar Viagem
                  </button>
                )}
                {activeRide.status === 'IN_PROGRESS' && (
                  <button onClick={handleCompleteTrip} className="w-full bg-white text-black py-4 rounded-2xl font-medium hover:bg-neutral-200 transition-colors">
                    Finalizar Viagem
                  </button>
                )}
                {activeRide.status === 'COMPLETED' && (
                  <div className="w-full glass-panel text-emerald-400 py-4 rounded-2xl font-medium text-center border-emerald-500/30">
                    Aguardando Pagamento...
                  </div>
                )}
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Hotspot Info Card */}
      <AnimatePresence>
        {activeHotspot && !activeRide && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute bottom-32 left-6 right-6 z-20 pointer-events-auto"
          >
            <div className="bg-[#111] border border-emerald-500/30 p-4 rounded-2xl shadow-2xl flex items-center justify-between backdrop-blur-md">
              <div>
                <div className="flex items-center gap-2 text-emerald-400 mb-1">
                  <TrendingUp size={16} />
                  <span className="font-bold text-sm uppercase tracking-wider">Oportunidade Detectada</span>
                </div>
                <h3 className="font-medium text-white">
                  {hotspots.find(h => h.id === activeHotspot)?.name}
                </h3>
                <p className="text-xs text-white/50 mt-1">
                  {hotspots.find(h => h.id === activeHotspot)?.message}
                </p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-emerald-400">
                  {hotspots.find(h => h.id === activeHotspot)?.multiplier}x
                </div>
                <div className="text-[10px] text-white/40 uppercase tracking-widest">Tarifa</div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Earnings / Wallet UI */}
      {activeTab === 'earnings' && !activeRide && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="absolute inset-x-6 top-6 bottom-24 z-20 pointer-events-auto"
        >
          <div className="bg-[#111] border border-white/10 rounded-[2rem] p-6 shadow-2xl h-full flex flex-col overflow-y-auto custom-scrollbar">
            <h2 className="text-xl font-bold mb-4 shrink-0">Faturamento & Carteira</h2>
            
            {(() => {
              const currentMonth = new Date().getMonth();
              const monthlyRides = rides.filter(r => {
                if (r.driverId !== currentUser?.id || r.status !== 'PAID') return false;
                return new Date(r.updatedAt || r.createdAt).getMonth() === currentMonth;
              });
              const totalFaturado = monthlyRides.reduce((acc, r) => acc + (r.offeredPrice || r.estimatedPrice), 0);
              const totalMotorista = monthlyRides.reduce((acc, r) => acc + (r.offeredPrice || r.estimatedPrice) * 0.70, 0);
              const totalApp = monthlyRides.reduce((acc, r) => {
                const p = r.offeredPrice || r.estimatedPrice;
                return acc + p * (r.isTerminalRide ? 0.15 : 0.22);
              }, 0);
              const ticketMedio = monthlyRides.length > 0 ? totalFaturado / monthlyRides.length : 0;
              
              return (
                <div className="space-y-6">
                  {/* Carteira Section */}
                  <div className={`p-5 rounded-2xl flex flex-col items-center justify-center text-center shadow-lg relative overflow-hidden shrink-0 ${(currentUser.walletBalance || 0) < 0 ? 'bg-red-500/10 border border-red-500/30' : 'bg-gradient-to-br from-emerald-900/40 to-black border border-emerald-500/20'}`}>
                    <p className="text-[10px] uppercase tracking-widest text-white/50 mb-1 font-mono">Saldo da Carteira</p>
                    <span className={`text-4xl font-light tracking-tighter ${(currentUser.walletBalance || 0) < 0 ? 'text-red-400' : 'text-emerald-400'}`}>R$ {(currentUser.walletBalance || 0).toFixed(2).replace('.', ',')}</span>
                    {(currentUser.walletBalance || 0) < 0 && (
                      <p className="text-[10px] text-red-400 mt-2 max-w-[200px]">Acesso bloqueado por taxas pendentes à plataforma. Adicione saldo para liberar.</p>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setWithdrawInput('');
                        setWithdrawOpen(true);
                      }}
                      className="mt-4 bg-white text-black px-6 py-2.5 rounded-full text-xs font-bold hover:bg-neutral-200 transition-colors uppercase tracking-widest"
                    >
                      Sacar valor
                    </button>
                    <button
                      type="button"
                      onClick={() => void addWalletBalance(currentUser.id, 50)}
                      className="mt-2 text-[10px] text-white/35 hover:text-white/55 uppercase tracking-widest"
                    >
                      Teste: +R$ 50 na carteira
                    </button>
                  </div>

                  <div className="rounded-2xl border border-white/10 bg-white/5 p-4 space-y-2 shrink-0">
                    <h4 className="text-[10px] text-white/50 uppercase tracking-widest font-bold">Saques (mock bancário)</h4>
                    {driverWithdrawals.filter((w) => w.driverId === currentUser?.id).length === 0 ? (
                      <p className="text-xs text-white/35">Nenhum saque registrado.</p>
                    ) : (
                      <div className="space-y-2 max-h-32 overflow-y-auto custom-scrollbar">
                        {driverWithdrawals
                          .filter((w) => w.driverId === currentUser?.id)
                          .map((w) => (
                            <div key={w.id} className="text-xs text-white/80 flex justify-between gap-2 border-b border-white/5 pb-2 last:border-0">
                              <span className="text-white/50 font-mono text-[10px]">
                                {new Date(w.createdAt).toLocaleString('pt-BR')}
                              </span>
                              <span className="text-emerald-400 font-bold">R$ {w.amount.toFixed(2).replace('.', ',')}</span>
                              <span className="text-[10px] text-white/40 truncate max-w-[100px]" title={w.reference}>
                                {w.reference}
                              </span>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>

                  {/* Faturamento Section */}
                  <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-4 grid grid-cols-2 gap-4 shrink-0">
                    <div>
                      <div className="text-[10px] text-white/50 uppercase tracking-widest font-bold mb-1">Total mês</div>
                      <div className="text-xl font-bold text-white">
                        R$ {totalFaturado.toFixed(2).replace('.', ',')}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-white/50 uppercase tracking-widest font-bold mb-1">Ganho motorista (70%)</div>
                      <div className="text-xl font-bold text-emerald-400">
                        R$ {totalMotorista.toFixed(2).replace('.', ',')}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-white/50 uppercase tracking-widest font-bold mb-1">Taxa app</div>
                      <div className="text-lg font-medium text-red-400">
                        -R$ {totalApp.toFixed(2).replace('.', ',')}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-white/50 uppercase tracking-widest font-bold mb-1">Ticket Médio</div>
                      <div className="text-lg font-medium text-blue-400">
                        R$ {ticketMedio.toFixed(2).replace('.', ',')} / {monthlyRides.length}x
                      </div>
                    </div>
                  </div>

                  <h3 className="font-medium text-white/50 px-2 text-sm uppercase tracking-widest shrink-0">Tabela de Corridas</h3>
                  <div className="space-y-3 shrink-0">
                    {monthlyRides.length === 0 ? (
                      <p className="text-white/40 text-sm text-center mt-2">Nenhuma corrida registrada neste mês.</p>
                    ) : monthlyRides.map(r => {
                      const basePrice = r.offeredPrice || r.estimatedPrice;
                      const appRate = r.isTerminalRide ? 0.15 : 0.22;
                      return (
                        <div key={r.id} className="glass-panel p-4 rounded-xl border border-white/5 bg-white/5 flex flex-col gap-2 relative">
                          <div className="flex justify-between items-start">
                            <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono border border-emerald-500/30">ID: {r.id.split('-')[0]}</span>
                            <span className="text-[10px] text-white/50 font-mono">
                              {new Date(r.updatedAt || r.createdAt).toLocaleDateString('pt-BR', {day:'2-digit', month:'short'})}
                            </span>
                          </div>
                          <div className="flex items-center justify-between mt-1">
                            <div>
                              <p className="text-sm font-bold text-white">R$ {basePrice.toFixed(2).replace('.', ',')}</p>
                              <p className="text-[10px] text-white/40 uppercase tracking-widest">Valor bruto</p>
                            </div>
                            <div className="text-center">
                              <p className="text-sm font-bold text-emerald-400">R$ {(basePrice * 0.7).toFixed(2).replace('.', ',')}</p>
                              <p className="text-[10px] text-white/40 uppercase tracking-widest">Motorista (70%)</p>
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-bold text-red-400">-R$ {(basePrice * appRate).toFixed(2).replace('.', ',')}</p>
                              <p className="text-[10px] text-white/40 uppercase tracking-widest">App ({(appRate * 100).toFixed(0)}%)</p>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              );
            })()}
          </div>
        </motion.div>
      )}

      <AnimatePresence>
        {withdrawOpen && currentUser && (
          <motion.div
            className="fixed inset-0 z-[160] flex items-end sm:items-center justify-center bg-black/70 pointer-events-auto p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              if (!withdrawBusy) setWithdrawOpen(false);
            }}
          >
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 40, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md bg-[#111] border border-white/10 rounded-3xl p-6 space-y-4 shadow-2xl"
            >
              <h3 className="text-lg font-bold">Sacar valor</h3>
              <p className="text-xs text-white/50 leading-relaxed">
                Simulação de integração bancária: o saldo da carteira é debitado e um comprovante fictício (referência PIX mock) é registrado.
              </p>
              <div>
                <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">Valor (R$)</label>
                <input
                  type="text"
                  inputMode="decimal"
                  value={withdrawInput}
                  onChange={(e) => setWithdrawInput(e.target.value)}
                  placeholder="0,00"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-emerald-500/50"
                />
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={withdrawBusy}
                  onClick={() => setWithdrawOpen(false)}
                  className="flex-1 py-3 rounded-xl border border-white/10 text-sm font-medium text-white/80 hover:bg-white/5 disabled:opacity-40"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  disabled={withdrawBusy}
                  onClick={async () => {
                    const v = parseFloat(String(withdrawInput).replace(',', '.'));
                    if (!Number.isFinite(v) || v <= 0) {
                      alert('Informe um valor válido.');
                      return;
                    }
                    setWithdrawBusy(true);
                    const ok = await requestDriverWithdrawal(currentUser.id, v);
                    setWithdrawBusy(false);
                    if (ok) {
                      alert(`Saque simulado concluído.\nValor: R$ ${v.toFixed(2).replace('.', ',')}`);
                      setWithdrawOpen(false);
                    } else {
                      alert('Saldo insuficiente ou valor inválido.');
                    }
                  }}
                  className="flex-1 py-3 rounded-xl bg-emerald-600 text-sm font-bold text-black hover:bg-emerald-500 disabled:opacity-40"
                >
                  Confirmar
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Safety Network UI */}
      {activeTab === 'safety' && !activeRide && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="absolute inset-x-6 top-6 bottom-24 z-20 pointer-events-auto flex flex-col"
        >
          <div className="bg-[#111] border border-blue-500/30 rounded-[2rem] p-6 shadow-2xl flex-1 flex flex-col h-full">
            <div className="flex items-center gap-3 mb-6">
              <ShieldCheck size={28} className="text-blue-400" />
              <h2 className="text-xl font-bold">Rede de Segurança</h2>
            </div>
            
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-2xl p-4 mb-4 relative overflow-hidden transition-all">
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/20 rounded-full blur-2xl -mr-10 -mt-10"></div>
              <h3 className="font-bold mb-1 relative z-10 text-white">Grupo: Anjos da Noite</h3>
              <p className="text-xs text-white/60 relative z-10 mb-3">
                {
                  drivers.filter(
                    (d) => d.status === 'ONLINE' && d.shareLocationOnSafetyRadar !== false
                  ).length
                }{' '}
                motorista(s) no radar remoto
              </p>
              
              {showGroupMap ? (
                <div className="w-full h-40 rounded-xl overflow-hidden mb-3 border border-blue-500/30 relative z-10">
                  {isLoaded ? (
                     <GoogleMap mapContainerStyle={{width:'100%', height:'100%'}} center={mapCenter} zoom={13} options={{disableDefaultUI: true, styles: [{stylers:[{invert_lightness:true}]}]}}>
                       {drivers.filter(d => d.status === 'ONLINE' && d.location && d.shareLocationOnSafetyRadar !== false).map(d => (
                         <Marker key={d.id} position={{lat: d.location!.lat, lng: d.location!.lng}} icon={{path: window.google.maps.SymbolPath.CIRCLE, scale: 5, fillColor: '#3b82f6', fillOpacity: 1, strokeColor: '#fff', strokeWeight: 1}} />
                       ))}
                     </GoogleMap>
                  ) : <div className="w-full h-full bg-[#111] flex items-center justify-center text-xs">Carregando Mapa...</div>}
                </div>
              ) : null}

              <button onClick={() => setShowGroupMap(!showGroupMap)} className="py-2 px-4 bg-blue-500 text-black font-semibold rounded-xl text-xs hover:bg-blue-400 transition-colors relative z-10">
                {showGroupMap ? 'Ocultar Mapa' : 'Ver Mapa do Grupo'}
              </button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar space-y-4 mb-4 pr-2">
              {(() => {
                if (!globalChats || globalChats.length === 0) return <p className="text-xs text-white/40 text-center mt-4">Nenhuma mensagem hoje.</p>;
                return globalChats.map(msg => (
                  <div key={msg.id} className={`flex flex-col gap-1 items-${msg.senderId === currentUser?.id ? 'end' : 'start'}`}>
                    <span className={`text-[10px] text-white/40 ${msg.senderId === currentUser?.id ? 'mr-2' : 'ml-2'}`}>
                      {msg.senderId === currentUser?.id ? 'Você' : msg.senderName} ({new Date(msg.timestamp).toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'})})
                    </span>
                    <div className={`px-4 py-2 rounded-2xl text-sm ${msg.senderId === currentUser?.id ? 'bg-blue-600 rounded-tr-sm text-white' : 'bg-white/10 border border-white/5 rounded-tl-sm'}`}>
                      {msg.text}
                    </div>
                  </div>
                ));
              })()}
            </div>

            <div className="flex gap-2 items-center mb-4 pt-2 border-t border-blue-500/20">
              <button 
                onClick={() => setShowEmergencyModal(true)}
                className="w-full py-2.5 px-3 bg-red-600/20 border border-red-500 text-red-500 hover:bg-red-600/30 hover:text-red-400 font-semibold uppercase tracking-wider text-[10px] rounded-lg flex items-center justify-center gap-1.5 transition-colors">
                <AlertTriangle size={14} /> Emergência ao grupo
              </button>
            </div>

            <div className="flex gap-2 mt-auto">
              <input
                type="text"
                placeholder="Alertar o grupo..."
                value={groupChatMsg}
                onChange={(e) => setGroupChatMsg(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && groupChatMsg.trim()) {
                    addGlobalChatMessage(groupChatMsg);
                    setGroupChatMsg('');
                  }
                }}
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500/50 transition-colors"
                
              />
              <button 
                disabled={!groupChatMsg.trim()}
                onClick={() => {
                  addGlobalChatMessage(groupChatMsg);
                  setGroupChatMsg('');
                }}
                className="bg-blue-600 text-white p-3 rounded-xl hover:bg-blue-500 disabled:bg-blue-500/20 disabled:text-white/20 transition-colors">
                <MessageSquare size={20} />
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Driver Settings UI */}
      {activeTab === 'settings' && !activeRide && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="absolute inset-x-6 top-6 bottom-24 z-20 pointer-events-auto min-h-0"
        >
          <div className="bg-[#111] border border-white/10 rounded-[2rem] p-6 shadow-2xl h-full min-h-0 flex flex-col">
            <h2 className="text-xl font-bold mb-6 shrink-0">Configurações</h2>

            <div className="space-y-4 flex-1 min-h-0 overflow-y-auto overscroll-y-contain pr-1">
              <div className="glass-panel p-5 rounded-2xl flex flex-col gap-2 border border-white/5 hover:bg-white/5 transition-colors cursor-pointer" onClick={() => setActiveSetting(activeSetting === 'driver' ? null : 'driver')}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <UserIcon size={20} className="text-emerald-400" />
                    <div>
                      <p className="font-medium text-sm">Dados do Motorista</p>
                      <p className="text-xs text-white/40 mt-1">Nome, CNH e Documentos</p>
                    </div>
                  </div>
                  {activeSetting === 'driver' ? <ChevronUp size={16} className="text-white/30" /> : <ChevronDown size={16} className="text-white/30" />}
                </div>
                {activeSetting === 'driver' && (
                  <div className="mt-4 pt-4 border-t border-white/10 space-y-2 cursor-default" onClick={e => e.stopPropagation()}>
                    <div className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                      <span className="text-white/50">Nome Completo</span>
                      <span className="text-white font-medium">{currentUser?.name}</span>
                    </div>
                    <div className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                      <span className="text-white/50">CPF</span>
                      <span className="text-white font-medium">{currentUser?.cpf}</span>
                    </div>
                    <div className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                      <span className="text-white/50">E-mail</span>
                      <span className="text-white font-medium text-right truncate max-w-[55%]">{(currentUser as Driver)?.email || '—'}</span>
                    </div>
                    <div className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                      <span className="text-white/50">Telefone</span>
                      <span className="text-white font-medium">{(currentUser as Driver)?.phone || '—'}</span>
                    </div>
                    <div className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                      <span className="text-white/50">Status da Conta</span>
                      <span className="text-emerald-400 font-bold tracking-widest text-[10px] uppercase bg-emerald-500/10 px-2 py-1 rounded">{(currentUser as any)?.driverStatus || 'APPROVED'}</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="glass-panel p-5 rounded-2xl flex flex-col gap-2 border border-white/5 hover:bg-white/5 transition-colors cursor-pointer" onClick={() => setActiveSetting(activeSetting === 'vehicle' ? null : 'vehicle')}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Car size={20} className="text-emerald-400" />
                    <div>
                      <p className="font-medium text-sm">Veículo Cadastrado</p>
                      <p className="text-xs text-white/40 mt-1">Placa, Categoria, Aceite Pet/Mulheres</p>
                    </div>
                  </div>
                  {activeSetting === 'vehicle' ? <ChevronUp size={16} className="text-white/30" /> : <ChevronDown size={16} className="text-white/30" />}
                </div>
                {activeSetting === 'vehicle' && driverMe && (
                  <div className="mt-4 pt-4 border-t border-white/10 space-y-3 cursor-default text-sm" onClick={(e) => e.stopPropagation()}>
                    {driverMe.vehicle && (!driverMe.fleetVehicles || driverMe.fleetVehicles.length === 0) && (
                      <p className="text-[10px] text-white/45 leading-relaxed">
                        CRLV cadastrado nos documentos: {driverMe.vehicle.model} · {driverMe.vehicle.plate}. Inclua o mesmo na frota abaixo para usar nas corridas.
                      </p>
                    )}
                    <div className="text-[10px] uppercase text-white/40 font-bold tracking-widest">Frota (vários veículos)</div>
                    {(driverMe.fleetVehicles || []).length === 0 && (
                      <p className="text-xs text-white/40">Nenhum veículo na frota. Adicione carro ou moto e defina qual está ativo.</p>
                    )}
                    {(driverMe.fleetVehicles || []).map((v) => (
                      <div
                        key={v.id}
                        className="flex flex-col gap-2 bg-black/20 p-3 rounded-xl border border-white/5"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <div className="text-emerald-400 text-[10px] font-bold uppercase">
                              {v.kind === 'MOTO' ? 'Moto' : 'Carro'} · {v.plate}
                            </div>
                            <div className="text-white/60 text-xs">
                              {v.model}
                              {v.kind === 'CAR' && v.category ? ` · ${v.category}` : ''}
                            </div>
                          </div>
                          <div className="flex flex-wrap items-center gap-2">
                          {driverMe.activeFleetVehicleId === v.id ? (
                            <span className="text-[10px] bg-emerald-500/30 text-emerald-300 px-2 py-1 rounded font-bold uppercase">Ativo</span>
                          ) : (
                            <button
                              type="button"
                              className="text-[10px] bg-white/10 px-2 py-1 rounded uppercase font-bold hover:bg-white/20"
                              onClick={() =>
                                void updateDriverFleetVehicles(currentUser!.id, driverMe.fleetVehicles || [], v.id)
                              }
                            >
                              Usar este
                            </button>
                          )}
                          <button
                            type="button"
                            className="text-[10px] bg-red-500/15 text-red-300 border border-red-500/30 px-2 py-1 rounded uppercase font-bold hover:bg-red-500/25 flex items-center gap-1"
                            title="Remover veículo da frota"
                            onClick={() => {
                              if (!currentUser) return;
                              if (!window.confirm('Remover este veículo da frota? Esta ação atualiza a lista e o veículo ativo.')) return;
                              const fleet = driverMe.fleetVehicles || [];
                              const nextFleet = fleet.filter((x) => x.id !== v.id);
                              const wasActive = driverMe.activeFleetVehicleId === v.id;
                              const nextActive = wasActive ? nextFleet[0]?.id : driverMe.activeFleetVehicleId;
                              void updateDriverFleetVehicles(currentUser.id, nextFleet, nextActive);
                            }}
                          >
                            <Trash2 size={12} className="inline" /> Excluir
                          </button>
                          </div>
                        </div>
                        <div className="flex items-center justify-between gap-2 border-t border-white/5 pt-2">
                          <span className="text-[10px] text-white/45 uppercase tracking-wide">Pet-friendly (este veículo)</span>
                          {v.kind === 'MOTO' ? (
                            <span className="text-[10px] text-white/35 uppercase">Não disponível para moto</span>
                          ) : (
                            <button
                              type="button"
                              className={`text-[10px] px-2 py-1 rounded font-bold uppercase border ${
                                v.acceptsPet === false
                                  ? 'bg-white/10 text-white/40 border-white/10'
                                  : 'bg-orange-500/20 text-orange-300 border-orange-500/30'
                              }`}
                              onClick={(e) => {
                                e.stopPropagation();
                                if (!currentUser) return;
                                const nextPet = v.acceptsPet === false ? true : false;
                                const nextFleet = (driverMe.fleetVehicles || []).map((x) =>
                                  x.id === v.id ? { ...x, acceptsPet: nextPet } : x
                                );
                                void updateDriverFleetVehicles(
                                  currentUser.id,
                                  nextFleet,
                                  driverMe.activeFleetVehicleId
                                );
                              }}
                            >
                              {v.acceptsPet === false ? 'Pet OFF' : 'Pet ON'}
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                    <div className="border border-white/10 rounded-xl p-3 space-y-2 bg-black/30">
                      <div className="text-[10px] text-white/50 uppercase font-bold">Adicionar veículo</div>
                      <select
                        value={newFleetKind}
                        onChange={(e) => setNewFleetKind(e.target.value as 'CAR' | 'MOTO')}
                        className="w-full bg-zinc-800 border border-white/10 rounded-lg px-2 py-2 text-xs text-white [&>option]:bg-zinc-800 [&>option]:text-white"
                      >
                        <option value="CAR">Carro</option>
                        <option value="MOTO">Moto</option>
                      </select>
                      {newFleetKind === 'CAR' && (
                        <select
                          value={newFleetCategory}
                          onChange={(e) => setNewFleetCategory(e.target.value as 'X' | 'Comfort' | 'Black')}
                          className="w-full bg-zinc-800 border border-white/10 rounded-lg px-2 py-2 text-xs text-white [&>option]:bg-zinc-800 [&>option]:text-white"
                        >
                          <option value="X">Categoria X</option>
                          <option value="Comfort">Comfort</option>
                          <option value="Black">Black</option>
                        </select>
                      )}
                      <input
                        placeholder="Modelo"
                        value={newFleetModel}
                        onChange={(e) => setNewFleetModel(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-2 text-xs text-white placeholder:text-white/30"
                      />
                      <input
                        placeholder="Placa"
                        value={newFleetPlate}
                        onChange={(e) => setNewFleetPlate(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-2 text-xs text-white uppercase placeholder:text-white/30"
                      />
                      <button
                        type="button"
                        className="w-full py-2.5 bg-emerald-600 rounded-lg text-xs font-bold uppercase tracking-wider text-black hover:bg-emerald-500"
                        onClick={() => {
                          if (!currentUser || !newFleetModel.trim() || !newFleetPlate.trim()) return;
                          const id = `fv_${Date.now()}`;
                          const item: DriverFleetVehicle = {
                            id,
                            kind: newFleetKind,
                            model: newFleetModel.trim(),
                            plate: newFleetPlate.trim().toUpperCase(),
                            category: newFleetKind === 'CAR' ? newFleetCategory : undefined,
                            acceptsPet: newFleetKind === 'CAR',
                          };
                          const next = [...(driverMe.fleetVehicles || []), item];
                          const active = driverMe.activeFleetVehicleId || id;
                          void updateDriverFleetVehicles(currentUser.id, next, active);
                          setNewFleetModel('');
                          setNewFleetPlate('');
                        }}
                      >
                        Salvar veículo
                      </button>
                    </div>
                    <p className="text-[10px] text-white/40 leading-relaxed">
                      Corridas pet usam apenas o veículo marcado como <span className="text-white/60">Ativo</span> e o interruptor Pet-friendly desse veículo.
                    </p>
                    <div className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                      <span className="text-white/50">Gênero</span>
                      <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={() => {
                            if (!currentUser) return;
                            setCurrentUser({ ...(currentUser as Driver), gender: 'FEMALE' } as AnyUser);
                            if (canUseSupabase()) {
                              void supabase.from('drivers').update({ gender: 'FEMALE' }).eq('id', currentUser.id);
                            }
                          }}
                          className={`px-2 py-1 rounded text-[10px] uppercase font-bold border transition ${(currentUser as Driver).gender === 'FEMALE' ? 'bg-pink-500/20 text-pink-400 border-pink-500/30' : 'bg-white/5 text-white/40 border-transparent'}`}
                        >
                          Feminino
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (!currentUser) return;
                            setCurrentUser({ ...(currentUser as Driver), gender: 'MALE' } as AnyUser);
                            if (canUseSupabase()) {
                              void supabase.from('drivers').update({ gender: 'MALE' }).eq('id', currentUser.id);
                            }
                          }}
                          className={`px-2 py-1 rounded text-[10px] uppercase font-bold border transition ${(currentUser as Driver).gender === 'MALE' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : 'bg-white/5 text-white/40 border-transparent'}`}
                        >
                          Masculino
                        </button>
                      </div>
                    </div>
                    <div className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                      <span className="text-white/50">Pet-friendly (receber corridas pet)</span>
                      <button
                        type="button"
                        className={`text-[10px] px-2 py-1 rounded font-bold uppercase border ${
                          (currentUser as Driver).acceptsPetRides
                            ? 'bg-orange-500/20 text-orange-300 border-orange-500/30'
                            : 'bg-white/10 text-white/40 border-white/10'
                        }`}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!currentUser) return;
                          const next = !(currentUser as Driver).acceptsPetRides;
                          setCurrentUser({ ...(currentUser as Driver), acceptsPetRides: next } as AnyUser);
                          if (canUseSupabase()) {
                            void supabase.from('drivers').update({ accepts_pet_rides: next }).eq('id', currentUser.id);
                          }
                        }}
                      >
                        {(currentUser as Driver).acceptsPetRides ? 'Pet ON' : 'Pet OFF'}
                      </button>
                    </div>
                    <div className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                      <span className="text-white/50 text-xs leading-snug pr-2">
                        Aparecer no mapa da Rede de Segurança
                      </span>
                      <button
                        type="button"
                        className={`text-[10px] px-2 py-1 rounded font-bold uppercase border shrink-0 ${
                          (currentUser as Driver).shareLocationOnSafetyRadar !== false
                            ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                            : 'bg-white/10 text-white/40 border-white/10'
                        }`}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!currentUser) return;
                          const cur = (currentUser as Driver).shareLocationOnSafetyRadar !== false;
                          const next = !cur;
                          setCurrentUser({
                            ...(currentUser as Driver),
                            shareLocationOnSafetyRadar: next,
                          } as AnyUser);
                          if (canUseSupabase()) {
                            void supabase
                              .from('drivers')
                              .update({ share_location_safety_radar: next })
                              .eq('id', currentUser.id);
                          }
                        }}
                      >
                        {(currentUser as Driver).shareLocationOnSafetyRadar !== false ? 'Visível' : 'Oculto'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
              <div className="glass-panel p-5 rounded-2xl flex justify-between items-center border border-white/5 hover:bg-white/5 transition-colors cursor-pointer" onClick={() => setDemoMode(!isDemoMode)}>
                <div className="flex items-center gap-4">
                  <ShieldAlert size={20} className="text-orange-400" />
                  <div>
                    <p className="font-medium text-sm">Modo de Simulação</p>
                    <p className="text-xs text-white/40 mt-1">Status: {isDemoMode ? 'Ativo' : 'Desativado'}</p>
                  </div>
                </div>
                <div className={`w-10 h-5 rounded-full relative transition-colors ${isDemoMode ? 'bg-emerald-500' : 'bg-white/20'}`}>
                  <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${isDemoMode ? 'right-1' : 'left-1'}`} />
                </div>
              </div>
            </div>

            <div className="shrink-0 pt-4 border-t border-white/5 mt-2">
              <button 
                onClick={() => {
                  setCurrentUser(null);
                  router.push('/');
                }}
                className="w-full py-4 border border-red-500/20 text-red-400 font-bold uppercase tracking-widest text-xs rounded-2xl hover:bg-red-500/10 transition-colors"
                >
                Sair da Conta
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Bottom Navigation */}
      {!activeRide && (
        <nav className="absolute bottom-6 inset-x-6 z-[130] pointer-events-auto">
          <div className="glass-panel rounded-full flex justify-around p-2 border border-white/10">
            <button onClick={() => setActiveTab('home')} className={`flex flex-col items-center gap-1 p-3 rounded-full transition-colors ${activeTab === 'home' ? 'bg-white/10 text-emerald-400' : 'text-white/40 hover:text-white/80'}`}>
              <Map size={20} />
            </button>
            <button onClick={() => setActiveTab('earnings')} className={`flex flex-col items-center gap-1 p-3 rounded-full transition-colors ${activeTab === 'earnings' ? 'bg-white/10 text-emerald-400' : 'text-white/40 hover:text-white/80'}`}>
              <DollarSign size={20} />
            </button>
            <button onClick={() => setActiveTab('safety')} className={`flex flex-col items-center gap-1 p-3 rounded-full transition-colors ${activeTab === 'safety' ? 'bg-white/10 text-blue-400' : 'text-white/40 hover:text-white/80'}`}>
              <ShieldAlert size={20} />
            </button>
            <button onClick={() => setActiveTab('settings')} className={`flex flex-col items-center gap-1 p-3 rounded-full transition-colors ${activeTab === 'settings' ? 'bg-white/10 text-emerald-400' : 'text-white/40 hover:text-white/80'}`}>
              <Settings size={20} />
            </button>
          </div>
        </nav>
      )}
      {/* Chat Modal */}
      <AnimatePresence>
        {showChat && activeRide && (
          <motion.div
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            className="fixed inset-0 z-[100] bg-[#050505] flex flex-col pointer-events-auto"
          >
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <h2 className="text-xl font-bold">Chat com Passageiro</h2>
              <button onClick={() => setShowChat(false)} className="p-2 rounded-full hover:bg-white/10 transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-4">
              {activeRide.messages?.map((msg) => {
                const isMe = msg.senderId === currentUser?.id;
                return (
                  <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-3 rounded-2xl ${isMe ? 'bg-emerald-600 text-white rounded-tr-sm' : 'bg-white/10 text-white rounded-tl-sm'}`}>
                      <p className="text-sm">{msg.text}</p>
                      <span className="text-[10px] opacity-50 mt-1 block text-right">
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                );
              })}
              {(!activeRide.messages || activeRide.messages.length === 0) && (
                <div className="flex-1 flex items-center justify-center text-white/40 text-sm">
                  Nenhuma mensagem ainda.
                </div>
              )}
            </div>

            <div className="p-4 border-t border-white/10 bg-[#0a0a0a]">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
                  placeholder="Digite uma mensagem..."
                  className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500/50 transition-colors"
                />
                <button
                  onClick={handleSendChat}
                  disabled={!chatMessage.trim()}
                  className="bg-emerald-500 text-black p-3 rounded-xl hover:bg-emerald-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <MessageSquare size={20} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Online/offline: z acima da nav (z-130) para o toque não ir para o mapa/nav */}
      {!activeRide && activeTab === 'home' && !showMenu && !showEmergencyModal && (((currentUser as Driver | null)?.driverStatus ?? 'APPROVED') === 'APPROVED') && (
        <div className="fixed inset-x-0 bottom-0 z-[160] flex justify-center pointer-events-none">
          <div className="w-full max-w-md flex justify-end px-5 pb-36 pointer-events-none">
            <button
              type="button"
              onClick={toggleOnline}
              onPointerDown={(e) => e.stopPropagation()}
              aria-pressed={isOnline}
              className={`relative z-[170] w-16 h-16 rounded-full flex flex-col items-center justify-center shadow-xl border-4 transition-all duration-500 group overflow-hidden touch-manipulation cursor-pointer active:scale-95 pointer-events-auto ${isOnline ? 'border-lime-400 bg-emerald-950/90 shadow-[0_0_28px_rgba(52,211,153,0.55)]' : 'border-white/10 bg-[#222]'}`}
            >
              {isOnline && <div className="absolute inset-0 bg-lime-400/25 animate-ping opacity-60 rounded-full pointer-events-none" />}
              <Power size={22} className={`relative z-10 drop-shadow-[0_0_8px_rgba(74,222,128,0.9)] ${isOnline ? 'text-lime-400' : 'text-white/40'}`} />
              <span className={`text-[9px] font-bold uppercase tracking-wider relative z-10 mt-0.5 ${isOnline ? 'text-lime-300' : 'text-white/40'}`}>
                {isOnline ? 'On' : 'Off'}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Emergency Modal Confirmation */}
      {showEmergencyModal && (
        <div className="absolute inset-0 bg-black/80 z-[100] flex items-center justify-center p-6 pointer-events-auto">
          <div className="bg-[#111] border border-red-500/50 p-6 rounded-3xl w-full max-w-sm text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-red-500/20 border-2 border-red-500 mx-auto flex items-center justify-center">
              <AlertTriangle size={32} className="text-red-500 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white mb-2">Confirmar Emergência?</h2>
              <p className="text-sm text-white/50">Todos os motoristas num raio de 5km e as autoridades locais receberão sua localização exata imediatamente.</p>
            </div>
            <div className="space-y-3">
              <button onClick={() => {
                setShowEmergencyModal(false);
                alert("🚨 ALERTA GERAL ENVIADO: Autoridades e motoristas notificados!");
              }} className="w-full py-4 bg-red-600 text-white font-bold rounded-xl uppercase tracking-widest text-sm hover:bg-red-500 transition-colors">
                CONFIRMAR E ALERTAR
              </button>
              <button onClick={() => setShowEmergencyModal(false)} className="w-full py-4 border border-white/20 text-white font-bold rounded-xl uppercase tracking-widest text-sm hover:bg-white/10 transition-colors">
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
