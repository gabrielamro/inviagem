/**
 * Evita que o campo "nome" exiba o CPF (dados errados ou autofill).
 * Se o nome for só dígitos iguais ao CPF, ou vazio, devolve string vazia.
 */
export function passengerDisplayName(
  rawName: string | null | undefined,
  cpf: string | null | undefined
): string {
  const name = (rawName ?? '').trim();
  const cpfDigits = (cpf ?? '').replace(/\D/g, '');
  if (!name) return '';
  const nameDigits = name.replace(/\D/g, '');
  if (cpfDigits.length >= 11 && nameDigits === cpfDigits) return '';
  if (nameDigits.length >= 11 && nameDigits === cpfDigits) return '';
  return name;
}
