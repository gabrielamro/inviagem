-- INVIAGEM v1.14.1 — colunas opcionais (idempotente no PostgreSQL/Supabase)

alter table if exists passengers add column if not exists gender text;
alter table if exists passengers add column if not exists saved_payment_methods jsonb default '[]'::jsonb;
alter table if exists passengers add column if not exists profile_photo_url text;

alter table if exists drivers add column if not exists gender text;
alter table if exists drivers add column if not exists profile_photo_url text;
alter table if exists drivers add column if not exists share_location_safety_radar boolean default true;
-- Documentos motorista (ver também scripts/ensure-drivers-document-columns.sql)
alter table if exists drivers add column if not exists cnh_url text;
alter table if exists drivers add column if not exists certification_url text;
alter table if exists drivers add column if not exists criminal_record_url text;
alter table if exists drivers add column if not exists driver_status text;
