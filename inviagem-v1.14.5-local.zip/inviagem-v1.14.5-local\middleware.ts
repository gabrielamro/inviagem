import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * Evita que o navegador guarde HTML antigo (que aponta para chunks JS antigos).
 * Assets em /_next/static/* continuam com cache longo (hashes mudam a cada build).
 */
export function middleware(request: NextRequest) {
  const res = NextResponse.next();
  const p = request.nextUrl.pathname;
  if (
    p.startsWith('/_next/static') ||
    p.startsWith('/_next/image') ||
    p === '/favicon.ico'
  ) {
    return res;
  }
  res.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
  res.headers.set('Pragma', 'no-cache');
  return res;
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
