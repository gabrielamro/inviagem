/**
 * Estimativa de tarifa alinhada a mercado (referência Uber/99 em trechos urbanos).
 * Base mínima + km + minuto; categorias com multiplicadores e piso por modalidade.
 */

export type PriceCategory =
  | 'X'
  | 'Comfort'
  | 'Black'
  | 'Moto Entrega'
  | 'Carro Entrega'
  | 'Corrida Moto';

/** Piso mínimo por categoria (evita moto “R$ 4” em trechos curtos e corrige distorções). */
const FLOOR_BY_CATEGORY: Record<PriceCategory, number> = {
  X: 8.9,
  Comfort: 11.5,
  Black: 16.5,
  /** Entrega urbana: abaixo da corrida de passageiro (menos SLA / sem deslocamento “premium”). */
  'Moto Entrega': 6.8,
  'Carro Entrega': 7.2,
  'Corrida Moto': 8.9,
};

export function estimateRidePrice(params: {
  category: string;
  distanceKm: number;
  durationMin: number;
}): number {
  const d = Math.max(0, Number(params.distanceKm) || 0);
  const m = Math.max(1, Math.ceil(Number(params.durationMin) || 1));
  const cat = params.category as PriceCategory;

  let base = 8.5;
  let perKm = 2.55;
  let perMin = 0.48;

  switch (cat) {
    case 'Comfort':
      base = 10.2;
      perKm = 3.2;
      perMin = 0.58;
      break;
    case 'Black':
      base = 15.0;
      perKm = 5.05;
      perMin = 0.82;
      break;
    case 'Moto Entrega':
      base = 6.2;
      perKm = 1.65;
      perMin = 0.32;
      break;
    case 'Carro Entrega':
      base = 6.8;
      perKm = 1.95;
      perMin = 0.38;
      break;
    case 'Corrida Moto':
      base = 8.2;
      perKm = 2.05;
      perMin = 0.42;
      break;
    default:
      break;
  }

  const raw = base + d * perKm + m * perMin;
  const floor = FLOOR_BY_CATEGORY[cat] ?? FLOOR_BY_CATEGORY.X;
  return Math.round(Math.max(floor, raw) * 100) / 100;
}
