-- =============================================================================
-- INVIAGEM — Colunas de documentos / status em public.drivers
-- =============================================================================
-- Erro típico sem alguma coluna:
--   "Could not find the 'certification_url' column of 'drivers' in the schema cache"
--
-- ONDE RODAR: Supabase → SQL → New query → colar → Run (idempotente)
-- =============================================================================

ALTER TABLE IF EXISTS public.drivers ADD COLUMN IF NOT EXISTS cnh_url text;
ALTER TABLE IF EXISTS public.drivers ADD COLUMN IF NOT EXISTS certification_url text;
ALTER TABLE IF EXISTS public.drivers ADD COLUMN IF NOT EXISTS criminal_record_url text;
ALTER TABLE IF EXISTS public.drivers ADD COLUMN IF NOT EXISTS profile_photo_url text;

-- Status cadastral (PENDING_DOCS | UNDER_REVIEW | APPROVED | REJECTED, etc.)
ALTER TABLE IF EXISTS public.drivers ADD COLUMN IF NOT EXISTS driver_status text;

COMMENT ON COLUMN public.drivers.cnh_url IS 'URL pública da CNH (Storage)';
COMMENT ON COLUMN public.drivers.certification_url IS 'URL certificação / curso (Storage)';
COMMENT ON COLUMN public.drivers.criminal_record_url IS 'URL antecedentes (Storage)';
COMMENT ON COLUMN public.drivers.profile_photo_url IS 'URL foto perfil / facial (Storage)';
