import { createClient, SupabaseClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

/** True se o Supabase está configurado (evita requests que travam em loading). */
export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

function createSafeClient(): SupabaseClient {
  if (!isSupabaseConfigured) return {} as SupabaseClient;
  try {
    return createClient(supabaseUrl, supabaseAnonKey);
  } catch (e) {
    console.error('[supabaseClient] Falha ao criar cliente:', e);
    return {} as SupabaseClient;
  }
}

export const supabase: SupabaseClient = createSafeClient();

/** Evita chamadas quando o cliente não foi criado (env vazio ou falha no createClient). */
export function canUseSupabase(): boolean {
  return isSupabaseConfigured && typeof (supabase as { from?: unknown }).from === 'function';
}

/**
 * Realtime (channel / broadcast) só existe no cliente JS real.
 * O stub `{}` em falha de config tem `.from` ausente, mas qualquer código que chame
 * `supabase.channel()` sem este guard quebra em runtime.
 */
export function canUseSupabaseRealtime(): boolean {
  return canUseSupabase() && typeof (supabase as { channel?: unknown }).channel === 'function';
}

/**
 * Coluna na tabela `drivers` para OFFLINE / ONLINE / IN_RIDE.
 * Padrão `online_status` — schemas sem coluna `status` geram PGRST204 no PostgREST.
 * Se a coluna no seu banco for outra, defina: NEXT_PUBLIC_DRIVER_AVAILABILITY_COLUMN=status
 */
export function getDriverAvailabilityColumn(): string {
  const c = process.env.NEXT_PUBLIC_DRIVER_AVAILABILITY_COLUMN?.trim();
  if (c) return c;
  return 'online_status';
}

export function readDriverAvailabilityStatus(row: Record<string, unknown> | null | undefined): unknown {
  if (!row) return undefined;
  const preferred = getDriverAvailabilityColumn();
  return row[preferred] ?? row.status ?? row.online_status ?? row.availability_status;
}
