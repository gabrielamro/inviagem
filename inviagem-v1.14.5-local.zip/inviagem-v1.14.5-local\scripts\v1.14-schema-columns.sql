-- INVIAGEM v1.14.0 — colunas opcionais (idempotente no PostgreSQL/Supabase)
-- Execute no SQL Editor do Supabase se ainda não existirem no seu projeto.

alter table if exists drivers add column if not exists criminal_record_url text;
alter table if exists drivers add column if not exists gender text;

-- fleet_json já coberto em v1.13; veículos podem incluir acceptsPet no JSON em list[].acceptsPet
