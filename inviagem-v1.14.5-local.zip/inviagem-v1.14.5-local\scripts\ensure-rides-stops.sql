-- Paradas intermediárias da corrida (JSON: [{ "lat", "lng", "address" }, ...])
-- Rode no Supabase → SQL se createRide falhar por coluna ausente.

ALTER TABLE IF EXISTS public.rides ADD COLUMN IF NOT EXISTS stops jsonb DEFAULT '[]'::jsonb;

COMMENT ON COLUMN public.rides.stops IS 'Paradas entre origem e destino (array de {lat, lng, address})';
