/* Remove pasta .next de forma segura (Windows/macOS/Linux). */
const fs = require('fs');
const path = require('path');
const dir = path.join(process.cwd(), '.next');
try {
  fs.rmSync(dir, { recursive: true, force: true });
  console.log('[inviagem] Pasta .next removida.');
} catch (e) {
  console.log('[inviagem] Nada a limpar em .next ou pasta em uso — feche o servidor (node) e tente de novo.');
  process.exitCode = 0;
}
