'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  supabase,
  canUseSupabase,
  canUseSupabaseRealtime,
  isSupabaseConfigured,
  getDriverAvailabilityColumn,
  readDriverAvailabilityStatus,
} from './supabaseClient';
import { passengerDisplayName } from './passengerPrefill';

/** Buckets tentados na ordem; configure NEXT_PUBLIC_SUPABASE_DRIVER_DOCS_BUCKET com o nome exato do projeto. */
function getDriverDocumentBucketCandidates(): string[] {
  const env =
    (typeof process !== 'undefined' &&
      (process.env.NEXT_PUBLIC_SUPABASE_DRIVER_DOCS_BUCKET || process.env.NEXT_PUBLIC_STORAGE_DRIVER_BUCKET)) ||
    '';
  const extra = String(env).trim();
  const list = [extra, 'driver-documents', 'driver_documents'].filter(Boolean) as string[];
  return [...new Set(list)];
}

function formatDriverStorageError(err: unknown, bucketsTried: string[]): string {
  const msg = err && typeof err === 'object' && 'message' in err ? String((err as { message?: string }).message) : String(err);
  const lower = msg.toLowerCase();
  if (lower.includes('bucket not found') || lower.includes('not found')) {
    const tried = [...new Set(bucketsTried)].join(', ') || '(nenhum)';
    return `Armazenamento de documentos indisponível (bucket). No painel Supabase > Storage, crie um bucket público ou ajuste as políticas. Buckets tentados: ${tried}. Opcional: variável de ambiente NEXT_PUBLIC_SUPABASE_DRIVER_DOCS_BUCKET com o nome exato do bucket.`;
  }
  return msg;
}

/** Coluna que funcionou no UPDATE, ou MISSING se o schema não tem nenhuma candidata */
let driverAvailabilityColumnCache: string | 'MISSING' | null = null;

async function persistDriverAvailabilityToSupabase(
  userId: string,
  status: 'OFFLINE' | 'ONLINE' | 'IN_RIDE'
): Promise<{ data: unknown; error: { message: string; code?: string } | null }> {
  if (driverAvailabilityColumnCache === 'MISSING') {
    return { data: null, error: null };
  }

  const columns = driverAvailabilityColumnCache
    ? [driverAvailabilityColumnCache]
    : [...new Set([getDriverAvailabilityColumn(), 'online_status', 'status', 'availability_status'])];

  for (const col of columns) {
    const { data, error } = await supabase
      .from('drivers')
      .update({ [col]: status })
      .eq('id', userId)
      .select(col)
      .maybeSingle();

    if (!error) {
      driverAvailabilityColumnCache = col;
      return { data, error: null };
    }

    const isMissingColumn =
      error.code === 'PGRST204' || /schema cache|could not find.*column/i.test(error.message || '');
    if (isMissingColumn) continue;

    return { data: null, error };
  }

  driverAvailabilityColumnCache = 'MISSING';
  if (typeof window !== 'undefined') {
    console.warn(
      '[STORE] Nenhuma coluna de disponibilidade em drivers (online_status, status, …). Estado local continua OK; adicione coluna no Supabase ou veja scripts/ensure-driver-online-status.sql'
    );
  }
  return { data: null, error: null };
}

export type RideStatus =
  | 'CREATED'
  | 'WAITING_PAYMENT'
  | 'MATCHING'
  | 'NEGOTIATING'
  | 'DRIVER_ASSIGNED'
  | 'DRIVER_ARRIVING'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'PAID'
  | 'CANCELLED'
  | 'NO_DRIVER';

export interface Location {
  lat: number;
  lng: number;
  address: string;
}

export interface Sponsor {
  id: string;
  name: string;
  logoUrl?: string;
  active: boolean;
}

export interface SponsoredLocation {
  id: string;
  sponsorId: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  description: string;
  tags: string[];
  rating: number;
  active: boolean;
  bidAmount?: number;
  stats?: {
    impressions: number;
    clicks: number;
    conversions: number;
  };
}

export interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: number;
}

export interface GlobalChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
}

export interface Ride {
  id: string;
  passengerId: string;
  driverId?: string;
  origin: Location;
  destination: Location;
  /** Paradas intermediárias (origem → paradas → destino). */
  waypoints?: Location[];
  category: 'X' | 'Comfort' | 'Black' | 'Moto Entrega' | 'Carro Entrega' | 'Corrida Moto';
  status: RideStatus;
  estimatedPrice: number;
  offeredPrice: number;
  lastOfferBy?: 'PASSENGER' | 'DRIVER';
  estimatedTime: number; // minutes
  startTime?: number; // timestamp when status became IN_PROGRESS
  createdAt: Date;
  updatedAt: Date;
  messages?: ChatMessage[];
  rideType?: 'NORMAL' | 'WOMEN_ONLY' | 'PET';
  isTerminalRide?: boolean;
  terminalOriginId?: string;
  terminalDestinationId?: string;
  originalPrice?: number;
  discountApplied?: number;
  finalPrice?: number;
  cashbackGenerated?: number;
  cashbackBlockedReason?: string;
  /** Valor do saldo/cashback do passageiro abatido neste pagamento (antes da corrida iniciar). */
  cashbackAppliedToPayment?: number;
  paymentMethod?: 'Pix' | 'Cartão' | 'Dinheiro' | 'Cashback' | 'Crédito' | 'Débito' | 'Saldo';
}

export interface Vehicle {
  plate: string;
  brand: string;
  model: string;
  year: number;
  color: string;
  capacity: number;
  crlvUrl?: string; // Link direto para o storage
}

export interface BaseUser {
  id: string;
  name: string;
  cpf?: string;
  walletBalance?: number;
}
export interface SavedPlace {
  title: string;
  address: string;
  lat?: number;
  lng?: number;
}

export interface DriverFleetVehicle {
  id: string;
  kind: 'CAR' | 'MOTO';
  model: string;
  plate: string;
  category?: 'X' | 'Comfort' | 'Black';
  /** Pet friendly neste veículo (corrida pet usa só o veículo ativo). Default true se omitido. */
  acceptsPet?: boolean;
}

export interface DriverWithdrawal {
  id: string;
  driverId: string;
  amount: number;
  createdAt: string;
  status: 'COMPLETED' | 'PENDING';
  reference: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
}

export interface PassengerSavedCard {
  id: string;
  last4: string;
  holderLabel?: string;
  /** Apelido / nome de exibição do cartão */
  cardNickname?: string;
  modality: 'DEBIT' | 'CREDIT';
  isDefault?: boolean;
  /** Validade MM/AA (somente referência; não é dado de pagamento real) */
  expiry?: string;
}

export interface Passenger extends BaseUser {
  role: 'PASSENGER';
  gender?: 'MALE' | 'FEMALE' | 'OTHER' | null;
  savedPlaces?: SavedPlace[];
  emergencyContacts?: EmergencyContact[];
  email?: string;
  phone?: string;
  /** Cartões salvos (débito/crédito) — espelho de `saved_payment_methods` no Supabase */
  savedPaymentMethods?: PassengerSavedCard[];
  profilePhotoUrl?: string;
}
export interface Driver extends BaseUser {
  role: 'DRIVER';
  driverStatus?: 'PENDING_DOCS' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED'; 
  status?: 'OFFLINE' | 'ONLINE' | 'IN_RIDE'; 
  location?: Location; 
  vehicle?: Vehicle; 
  /** Frota (carro/moto); veículo legado em `vehicle` quando vazio */
  fleetVehicles?: DriverFleetVehicle[];
  activeFleetVehicleId?: string;
  cnhUrl?: string; 
  certificationUrl?: string; 
  /** Ficha / certidão criminal (URL em storage) */
  criminalRecordUrl?: string;
  profilePhotoUrl?: string; 
  rejectionReason?: string; 
  acceptsPetRides?: boolean;
  gender?: 'MALE' | 'FEMALE' | 'OTHER' | null;
  email?: string;
  phone?: string;
  /** Quando false, não aparece no mapa da Rede de Segurança (radar). Default: true */
  shareLocationOnSafetyRadar?: boolean;
}

function normalizeDriverStatus(v: unknown): 'OFFLINE' | 'ONLINE' | 'IN_RIDE' {
  if (v == null || v === '') return 'OFFLINE';
  const s = String(v).toUpperCase();
  if (s === 'ONLINE' || s === 'OFFLINE' || s === 'IN_RIDE') return s as 'OFFLINE' | 'ONLINE' | 'IN_RIDE';
  return 'OFFLINE';
}

export interface Admin extends BaseUser {
  role: 'ADMIN';
}
export type AnyUser = Passenger | Driver | Admin;

export type RegisterUserResult =
  | { ok: true; user: AnyUser }
  | { ok: false; message: string };

export interface BusTerminal {
  id: string;
  name: string;
  address: string;
  zone_or_bairro: string;
  lat: number;
  lng: number;
  active: boolean;
}

export interface Violation {
  id: string;
  driverId: string;
  violationTime: string;
  lastKnownLocation: { lat: number; lng: number };
  addressText: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'PENDING' | 'REVIEWED' | 'RESOLVED';
}

export interface Hotspot {
  id: string;
  lat: number;
  lng: number;
  radius: number; // in meters
  multiplier: number; // e.g. 1.2x
  name: string;
  message: string;
  active: boolean;
}

interface StoreContextType {
  rides: Ride[];
  drivers: Driver[];
  passengers: Passenger[];
  admins: Admin[];
  terminals: BusTerminal[];
  sponsors: Sponsor[];
  sponsoredLocations: SponsoredLocation[];
  hotspots: Hotspot[];
  currentUser: AnyUser | null;
  setCurrentUser: (user: AnyUser | null) => void;
  registerUser: (user: any) => Promise<RegisterUserResult>;
  loginUser: (cpf: string, role: string) => Promise<AnyUser | null>;
  submitDriverDocs: (userId: string, vehicleData: any, files: { cnh?: File, crlv?: File, certification?: File, criminalRecord?: File, profile?: File }) => Promise<boolean>;
  createRide: (ride: Omit<Ride, 'id' | 'status' | 'createdAt' | 'updatedAt'>) => Promise<Ride | null>;
  updateRideStatus: (id: string, status: RideStatus, driverId?: string) => Promise<void>;
  confirmRidePayment: (
    rideId: string,
    opts: { cashbackApplied: number; remainderMethod: string }
  ) => Promise<void>;
  updateRidePrice: (id: string, newPrice: number, offeredBy: 'PASSENGER' | 'DRIVER', driverId?: string) => Promise<void>;
  updateUserLocation: (userId: string, location: Location) => void;
  updateDriverStatus: (userId: string, status: 'OFFLINE' | 'ONLINE' | 'IN_RIDE') => void;
  addSponsor: (sponsor: Omit<Sponsor, 'id'>) => void;
  addSponsoredLocation: (location: Omit<SponsoredLocation, 'id'>) => void;
  toggleSponsorStatus: (id: string) => void;
  toggleLocationStatus: (id: string) => void;
  trackAdEvent: (locationId: string, event: 'impression' | 'click' | 'conversion') => void;
  addChatMessage: (rideId: string, senderId: string, text: string) => void;
  addHotspot: (hotspot: Omit<Hotspot, 'id'>) => void;
  removeHotspot: (id: string) => void;
  updateHotspot: (id: string, updates: Partial<Hotspot>) => void;
  updateDriverClearance: (userId: string, status: 'PENDING_DOCS' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED', reason?: string) => Promise<void>;
  globalError: { message: string, timestamp: number } | null;
  triggerError: (message: string) => void;
  addWalletBalance: (userId: string, amount: number) => Promise<void>;
  requestDriverWithdrawal: (userId: string, amount: number) => Promise<boolean>;
  driverWithdrawals: DriverWithdrawal[];
  updateDriverFleetVehicles: (userId: string, fleet: DriverFleetVehicle[], activeId: string | undefined) => Promise<void>;
  deleteDriverAccount: (userId: string) => Promise<boolean>;
  addTerminal: (terminal: Omit<BusTerminal, 'id'>) => Promise<boolean>;
  updateTerminal: (id: string, updates: Partial<BusTerminal>) => Promise<boolean>;
  deleteTerminal: (id: string) => Promise<boolean>;
  violations: Violation[];
  resolveViolation: (id: string) => Promise<void>;
  isDemoMode: boolean;
  setDemoMode: (enabled: boolean) => void;
  immuTaxCollected: number; // Variável global pro tesouro municipal
  globalChats: GlobalChatMessage[];
  addGlobalChatMessage: (text: string) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

function vehicleFromVehiclesTableRow(v: Record<string, unknown>): Vehicle {
  return {
    plate: String(v.plate ?? ''),
    brand: String(v.brand ?? ''),
    model: String(v.model ?? ''),
    year: Number(v.manufacturing_year) || new Date().getFullYear(),
    color: String(v.color ?? ''),
    capacity: Number(v.maximum_capacity) > 0 ? Number(v.maximum_capacity) : 4,
    crlvUrl: typeof v.crlv_url === 'string' ? v.crlv_url : undefined,
  };
}

function mergeDriverVehicleFromJson(d: Record<string, unknown>): Vehicle | undefined {
  const v = d.vehicle;
  if (!v || typeof v !== 'object') return undefined;
  const o = v as Record<string, unknown>;
  if (!o.plate && !o.model) return undefined;
  return {
    plate: String(o.plate ?? ''),
    brand: String(o.brand ?? ''),
    model: String(o.model ?? ''),
    year: Number(o.year ?? o.manufacturing_year) || new Date().getFullYear(),
    color: String(o.color ?? ''),
    capacity: Number(o.capacity ?? o.maximum_capacity) > 0 ? Number(o.capacity ?? o.maximum_capacity) : 4,
    crlvUrl: typeof o.crlvUrl === 'string' ? o.crlvUrl : typeof o.crlv_url === 'string' ? o.crlv_url : undefined,
  };
}

function parseDriverFleetFromRow(d: Record<string, unknown>): {
  fleetVehicles?: DriverFleetVehicle[];
  activeFleetVehicleId?: string;
} {
  try {
    let fv: unknown = d.fleet_vehicles ?? d.fleet_json;
    if (typeof fv === 'string') {
      try {
        fv = JSON.parse(fv) as unknown;
      } catch {
        fv = undefined;
      }
    }
    if (Array.isArray(fv)) {
      const list = fv as DriverFleetVehicle[];
      return {
        fleetVehicles: list,
        activeFleetVehicleId: (d.active_fleet_vehicle_id as string) || list[0]?.id,
      };
    }
    if (fv && typeof fv === 'object' && !Array.isArray(fv)) {
      const o = fv as { list?: DriverFleetVehicle[]; activeId?: string };
      if (Array.isArray(o.list)) {
        return { fleetVehicles: o.list, activeFleetVehicleId: o.activeId || o.list[0]?.id };
      }
    }
  } catch (_) {
    /* ignore */
  }
  return {};
}

function normalizeSavedPlaces(raw: unknown): SavedPlace[] {
  if (!Array.isArray(raw)) return [];
  return raw.map((item: unknown) => {
    if (typeof item === 'string') return { title: item, address: item };
    const o = item as Record<string, unknown>;
    const lat = o.lat != null ? Number(o.lat) : undefined;
    const lng = o.lng != null ? Number(o.lng) : undefined;
    return {
      title: String(o.title ?? o.name ?? 'Local'),
      address: String(o.address ?? ''),
      lat: Number.isFinite(lat) ? lat : undefined,
      lng: Number.isFinite(lng) ? lng : undefined,
    };
  });
}

function normalizeSavedPaymentMethods(raw: unknown): PassengerSavedCard[] {
  if (!Array.isArray(raw)) return [];
  return raw.map((item: unknown, i: number) => {
    const o = item as Record<string, unknown>;
    const raw4 = String(o.last4 ?? o.last_four ?? '0000').replace(/\D/g, '');
    const last4 = raw4.length >= 4 ? raw4.slice(-4) : raw4.padStart(4, '0');
    const mod = String(o.modality ?? o.kind ?? 'CREDIT').toUpperCase();
    return {
      id: String(o.id ?? `card_${Date.now()}_${i}`),
      last4,
      holderLabel: o.holderLabel != null ? String(o.holderLabel) : undefined,
      cardNickname: o.cardNickname != null ? String(o.cardNickname) : undefined,
      expiry: o.expiry != null ? String(o.expiry) : undefined,
      modality: mod === 'DEBIT' ? 'DEBIT' : 'CREDIT',
      isDefault: Boolean(o.isDefault ?? o.is_default),
    };
  });
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [rides, setRides] = useState<Ride[]>([]);
  const [driverWithdrawals, setDriverWithdrawals] = useState<DriverWithdrawal[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const raw = localStorage.getItem('inviagem_driver_withdrawals');
      if (!raw) return [];
      const arr = JSON.parse(raw) as unknown;
      return Array.isArray(arr) ? (arr as DriverWithdrawal[]) : [];
    } catch {
      return [];
    }
  });

  const [drivers, setDrivers] = useState<Driver[]>([{
    id: 'd_mock_1',
    name: 'Márcia Silva (Teste)',
    role: 'DRIVER',
    cpf: '11111111111',
    walletBalance: 145.50,
    driverStatus: 'APPROVED',
    status: 'ONLINE',
    gender: 'FEMALE',
    acceptsPetRides: true,
    location: { lat: -3.1180, lng: -60.0220, address: 'Centro Histórico - Manaus' },
    vehicle: { brand: 'Chevrolet', model: 'Onix', year: 2022, color: 'Prata', plate: 'ABC-1234', capacity: 4 }
  }]);
  const [passengers, setPassengers] = useState<Passenger[]>([{
    id: 'p_mock_1',
    name: 'Amanda Costa (Teste)',
    role: 'PASSENGER',
    cpf: '22222222222',
    walletBalance: 8.50,
    gender: 'FEMALE'
  }]);
  const [admins, setAdmins] = useState<Admin[]>([{ id: 'admin_001', name: 'Admin', role: 'ADMIN' }]);
  const [terminals, setTerminals] = useState<BusTerminal[]>([]);
  const [violations, setViolations] = useState<Violation[]>([]);
  const [globalError, setGlobalError] = useState<{ message: string, timestamp: number } | null>(null);

  const triggerError = useCallback((message: string) => {
    setGlobalError({ message, timestamp: Date.now() });
    setTimeout(() => {
      setGlobalError(null);
    }, 5000);
  }, []);

  const mapSupabaseRideToFront = useCallback((row: any): Ride => {
    let waypoints: Location[] | undefined;
    const rawStops = row.stops;
    if (Array.isArray(rawStops)) {
      waypoints = rawStops
        .map((s: any) => {
          const lat = Number(s?.lat);
          const lng = Number(s?.lng);
          const addr = String(s?.address ?? '').trim();
          const address =
            addr ||
            (Number.isFinite(lat) && Number.isFinite(lng)
              ? `Parada (${lat.toFixed(4)}, ${lng.toFixed(4)})`
              : '');
          return { lat, lng, address };
        })
        .filter((s: Location) => Number.isFinite(s.lat) && Number.isFinite(s.lng));
      if (waypoints.length === 0) waypoints = undefined;
    }
    return {
    id: row.id,
    passengerId: row.passenger_id,
    driverId: row.driver_id,
    origin: { lat: row.origin_lat, lng: row.origin_lng, address: row.origin_address },
    destination: { lat: row.dest_lat, lng: row.dest_lng, address: row.dest_address },
    waypoints,
    category: row.category,
    status: row.status,
    estimatedPrice: row.estimated_price,
    offeredPrice: row.offered_price,
    lastOfferBy: row.last_offer_by,
    estimatedTime: row.estimated_time,
    startTime: row.start_time,
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
    rideType: row.ride_type,
    isTerminalRide: row.is_terminal_ride,
    terminalOriginId: row.terminal_origin_id,
    terminalDestinationId: row.terminal_destination_id,
    originalPrice: row.original_price,
    discountApplied: row.discount_applied,
    finalPrice: row.final_price,
    cashbackGenerated: row.cashback_generated,
    cashbackBlockedReason: row.cashback_blocked_reason,
    cashbackAppliedToPayment: row.cashback_applied_to_payment != null ? Number(row.cashback_applied_to_payment) : undefined,
    paymentMethod: row.payment_method || 'Pix', // Defaulting gracefully if column missing
  };
  }, []);

  // Carrega dados do Supabase (não bloqueia a renderização; falhas não travam a página)
  useEffect(() => {
    if (!canUseSupabase()) return;

    const fetchAllUsers = async () => {
      try {
        const { data: drivers, error: dError } = await supabase.from('drivers').select('*');
        const { data: passengers, error: pError } = await supabase.from('passengers').select('*');

        if (dError) console.error("Erro ao carregar motoristas:", dError);
        if (pError) console.error("Erro ao carregar passageiros:", pError);

        if (!dError && !pError && drivers && passengers) {
          console.log(`[STORE] Carregados ${drivers.length} motoristas e ${passengers.length} passageiros.`);
          const cu = currentUserRef.current;

          const vehicleByDriver: Record<string, Vehicle> = {};
          try {
            const ids = (drivers as { id: string }[]).map((x) => x.id).filter(Boolean);
            if (ids.length) {
              const { data: vrows } = await supabase.from('vehicles').select('*').in('driver_id', ids);
              if (vrows) {
                for (const row of vrows as Record<string, unknown>[]) {
                  const did = String(row.driver_id ?? '');
                  if (did && !vehicleByDriver[did]) {
                    vehicleByDriver[did] = vehicleFromVehiclesTableRow(row);
                  }
                }
              }
            }
          } catch (e) {
            console.warn('[STORE] Frota vehicles (join):', e);
          }

          setDrivers(drivers.map((d: any) => {
            const dr = d as Record<string, unknown>;
            let status = normalizeDriverStatus(readDriverAvailabilityStatus(dr));
            // Sempre preferir a sessão do motorista logado (ONLINE/OFFLINE/IN_RIDE).
            if (cu?.role === 'DRIVER' && String(cu.id) === String(d.id)) {
              status = normalizeDriverStatus((cu as Driver).status);
            }
            const fleetFromRow = parseDriverFleetFromRow(dr);
            const fromJson = mergeDriverVehicleFromJson(dr);
            const fromTable = vehicleByDriver[String(d.id)];
            const resolvedVehicle = fromJson?.plate ? fromJson : fromTable?.plate ? fromTable : undefined;
            return {
              id: d.id,
              name: d.name,
              role: 'DRIVER' as const,
              cpf: d.cpf,
              email: typeof d.email === 'string' ? d.email : undefined,
              phone: typeof d.phone === 'string' ? d.phone : undefined,
              driverStatus: d.driver_status,
              walletBalance: d.wallet_balance ? Number(d.wallet_balance) : 0,
              status,
              location: d.location,
              vehicle: resolvedVehicle,
              fleetVehicles: fleetFromRow.fleetVehicles,
              activeFleetVehicleId: fleetFromRow.activeFleetVehicleId,
              cnhUrl: d.cnh_url,
              certificationUrl: d.certification_url,
              criminalRecordUrl: typeof d.criminal_record_url === 'string' ? d.criminal_record_url : undefined,
              profilePhotoUrl: d.profile_photo_url,
              rejectionReason: d.rejection_reason,
              acceptsPetRides: d.accepts_pet_rides,
              gender: d.gender,
              shareLocationOnSafetyRadar:
                (d as { share_location_safety_radar?: boolean }).share_location_safety_radar !== false,
            };
          }));
          setPassengers(passengers.map((p: any) => ({
              id: p.id,
              name: p.name,
              role: 'PASSENGER' as const,
              cpf: p.cpf,
              email: typeof p.email === 'string' ? p.email : undefined,
              phone: typeof p.phone === 'string' ? p.phone : undefined,
              walletBalance: p.wallet_balance ? Number(p.wallet_balance) : 0,
              gender: p.gender,
              savedPlaces: normalizeSavedPlaces(p.saved_places),
              savedPaymentMethods: normalizeSavedPaymentMethods(
                (p as { saved_payment_methods?: unknown }).saved_payment_methods
              ),
              profilePhotoUrl:
                typeof (p as { profile_photo_url?: string }).profile_photo_url === 'string'
                  ? (p as { profile_photo_url?: string }).profile_photo_url
                  : undefined,
          })));
        }
      } catch (err) {
        console.error("Erro ao carregar usuários:", err);
      }
    };

    const fetchActiveRides = async () => {
      try {
        if (!canUseSupabase()) return;
        const { data, error } = await supabase
          .from('rides')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(50);

        if (!error && data) {
          const maxAgeMs = 6 * 60 * 60 * 1000;
          const maxWaitPaymentMs = 90 * 60 * 1000;
          const now = Date.now();
          const filtered = data.filter((row: any) => {
            const t = new Date(row.created_at).getTime();
            if (now - t > maxAgeMs) return false;
            if (row.status === 'WAITING_PAYMENT' && now - t > maxWaitPaymentMs) return false;
            return true;
          });
          setRides(filtered.map((row: any) => mapSupabaseRideToFront(row)));
        }
      } catch (_) {
        // ignora erro; não bloqueia a UI
      }
    };

    const fetchViolations = async () => {
      try {
        if (!canUseSupabase()) return;
        const { data, error } = await supabase
          .from('geo_fence_violations')
          .select('*')
          .order('violation_time', { ascending: false });

        if (!error && data) {
          setViolations(data.map((v: any) => ({
            id: v.id,
            driverId: v.driver_id,
            violationTime: v.violation_time,
            lastKnownLocation: { lat: v.last_known_location?.lat, lng: v.last_known_location?.lng },
            addressText: v.address_text,
            severity: v.severity,
            status: v.status
          })));
        }
      } catch (_) {
        // ignora erro
      }
    };

    const fetchTerminals = async () => {
      try {
        if (!canUseSupabase()) return;
        const { data, error } = await supabase.from('bus_terminals').select('*').eq('active', true);
        if (!error && data) {
          setTerminals(data.map((t: any) => ({
            id: t.id,
            name: t.name,
            address: t.address,
            zone_or_bairro: t.zone_or_bairro,
            lat: Number(t.lat),
            lng: Number(t.lng),
            active: t.active
          })));
        }
      } catch (_) {}
    };

    fetchActiveRides();
    fetchAllUsers();
    fetchViolations();
    fetchTerminals();

    let driversChannel: ReturnType<typeof supabase.channel> | undefined;
    let passengersChannel: ReturnType<typeof supabase.channel> | undefined;
    let violationsChannel: ReturnType<typeof supabase.channel> | undefined;
    let ridesChannel: ReturnType<typeof supabase.channel> | undefined;

    if (canUseSupabaseRealtime()) {
      driversChannel = supabase.channel('drivers_channel')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'drivers' }, fetchAllUsers)
        .subscribe();

      passengersChannel = supabase.channel('passengers_channel')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'passengers' }, fetchAllUsers)
        .subscribe();

      violationsChannel = supabase.channel('violations_channel')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'geo_fence_violations' }, fetchViolations)
        .subscribe();

      ridesChannel = supabase
        .channel('rides_channel')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'rides' }, () => {
          void fetchActiveRides();
        })
        .subscribe();
    }

    return () => {
      if (driversChannel) supabase.removeChannel(driversChannel);
      if (passengersChannel) supabase.removeChannel(passengersChannel);
      if (violationsChannel) supabase.removeChannel(violationsChannel);
      if (ridesChannel) supabase.removeChannel(ridesChannel);
    };
  }, [mapSupabaseRideToFront]);

  const [immuTaxCollected, setImmuTaxCollected] = useState(0);
  const [sponsors, setSponsors] = useState<Sponsor[]>([
    { id: 's1', name: 'Hamburgueria do Zé', active: true },
    { id: 's2', name: 'Shopping Cidade', active: true }
  ]);
  const [sponsoredLocations, setSponsoredLocations] = useState<SponsoredLocation[]>([
    {
      id: 'l1',
      sponsorId: 's1',
      name: 'Hamburgueria do Zé (Matriz)',
      address: 'Avenida Paulista, 1000, São Paulo',
      lat: -23.565,
      lng: -46.652,
      description: 'O melhor blend artesanal da cidade. Ganhe 10% OFF pedindo pelo Inviagem.',
      tags: ['hamburguer', 'lanche', 'jantar', 'fast food'],
      rating: 4.9,
      active: true,
      bidAmount: 2.50,
      stats: { impressions: 1450, clicks: 320, conversions: 45 }
    },
    {
      id: 'l2',
      sponsorId: 's2',
      name: 'Shopping Cidade',
      address: 'Rua Augusta, 2000, São Paulo',
      lat: -23.558,
      lng: -46.660,
      description: 'O maior centro de compras da região. Desembarque VIP.',
      tags: ['shopping', 'compras', 'cinema', 'passeio'],
      rating: 4.7,
      active: true,
      bidAmount: 1.50,
      stats: { impressions: 3200, clicks: 540, conversions: 82 }
    }
  ]);
  const [currentUser, setCurrentUser] = useState<AnyUser | null>(null);
  const currentUserRef = useRef<AnyUser | null>(null);
  useEffect(() => {
    currentUserRef.current = currentUser;
  }, [currentUser]);
  // Com Supabase configurado, modo demo inicia desligado para persistir ONLINE/OFFLINE no banco.
  const [isDemoMode, setDemoMode] = useState(() => !isSupabaseConfigured);

  const [hotspots, setHotspots] = useState<Hotspot[]>([
    {
      id: 'h1',
      lat: -3.13028,
      lng: -60.02333,
      radius: 1000,
      multiplier: 1.5,
      name: 'Teatro Amazonas',
      message: 'Alta demanda turística',
      active: true
    },
    {
      id: 'h2',
      lat: -3.10444,
      lng: -60.01167,
      radius: 800,
      multiplier: 1.3,
      name: 'Manauara Shopping',
      message: 'Happy Hour bombando!',
      active: true
    }
  ]);
  const [globalChats, setGlobalChats] = useState<GlobalChatMessage[]>([
    { id: 'mock1', senderId: 'd_2', senderName: 'Marcos', text: 'Alguém pelo centro? Tá meio estranho aqui.', timestamp: Date.now() - 60000 },
  ]);

  const resolveViolation = useCallback(async (id: string) => {
    setViolations(prev => prev.map(v => v.id === id ? { ...v, status: 'RESOLVED' } : v));
    await supabase.from('geo_fence_violations').update({ status: 'RESOLVED' }).eq('id', id);
  }, []);

  const addHotspot = useCallback((hotspot: Omit<Hotspot, 'id'>) => {
    setHotspots(prev => [...prev, { ...hotspot, id: `h_${Date.now()}` }]);
  }, []);

  const removeHotspot = useCallback((id: string) => {
    setHotspots(prev => prev.filter(h => h.id !== id));
  }, []);

  const updateHotspot = useCallback((id: string, updates: Partial<Hotspot>) => {
    setHotspots(prev => prev.map(h => h.id === id ? { ...h, ...updates } : h));
  }, []);

  const registerUser = useCallback(async (userData: any): Promise<RegisterUserResult> => {
    if (!canUseSupabase()) {
      return {
        ok: false,
        message: 'Supabase não configurado. Defina NEXT_PUBLIC_SUPABASE_URL e NEXT_PUBLIC_SUPABASE_ANON_KEY.',
      };
    }

    const tableName = userData.role === 'PASSENGER' ? 'passengers' : 'drivers';
    const normalizedCpf = userData.cpf ? String(userData.cpf).replace(/\D/g, '') : '';
    if (normalizedCpf.length < 11) {
      return { ok: false, message: 'CPF inválido (informe 11 dígitos).' };
    }

    const genderVal: 'MALE' | 'FEMALE' | undefined =
      userData.gender === 'MALE' || userData.gender === 'FEMALE' ? userData.gender : undefined;

    const describeRegisterError = (error: { message?: string; code?: string; details?: string }): string => {
      const code = error.code || '';
      const msg = (error.message || '').toLowerCase();
      if (code === '23505' || msg.includes('duplicate') || msg.includes('unique')) {
        return 'Este CPF já está cadastrado.';
      }
      if (code === '42501' || msg.includes('permission denied') || msg.includes('rls')) {
        return 'Não foi possível registrar (permissão no banco). Verifique políticas RLS no Supabase.';
      }
      if (code === 'PGRST204' || msg.includes('could not find') || msg.includes('schema cache')) {
        return 'Erro de schema: coluna ou tabela incompatível com o projeto.';
      }
      return error.message || 'Não foi possível concluir o cadastro. Tente novamente.';
    };

    const isColumnMissingError = (error: { code?: string; message?: string }) => {
      const m = error.message || '';
      return error.code === 'PGRST204' || /could not find.*column|schema cache/i.test(m);
    };

    const buildDriverInsertVariants = (): Record<string, unknown>[] => {
      const availabilityCol = getDriverAvailabilityColumn();
      const wb = userData.walletBalance ?? 0;
      const variants: Record<string, unknown>[] = [];

      const v = (opts: {
        emailPhone: boolean;
        role: boolean;
        availability: boolean;
        wallet: boolean;
        driverStatus: boolean;
        gender: boolean;
      }) => {
        const row: Record<string, unknown> = {
          name: userData.name,
          cpf: normalizedCpf,
        };
        if (opts.wallet) row.wallet_balance = wb;
        if (opts.emailPhone) {
          if (userData.email) row.email = String(userData.email).trim();
          if (userData.phone) row.phone = String(userData.phone).replace(/\D/g, '');
        }
        if (opts.driverStatus) row.driver_status = userData.driverStatus || 'PENDING_DOCS';
        if (opts.role) row.role = 'DRIVER';
        if (opts.availability) row[availabilityCol] = userData.status || 'OFFLINE';
        if (opts.gender && genderVal) row.gender = genderVal;
        variants.push(row);
      };

      v({ emailPhone: true, role: true, availability: true, wallet: true, driverStatus: true, gender: true });
      v({ emailPhone: false, role: true, availability: true, wallet: true, driverStatus: true, gender: true });
      v({ emailPhone: false, role: false, availability: true, wallet: true, driverStatus: true, gender: true });
      v({ emailPhone: false, role: false, availability: false, wallet: true, driverStatus: true, gender: true });
      v({ emailPhone: false, role: false, availability: false, wallet: false, driverStatus: true, gender: true });
      v({ emailPhone: false, role: false, availability: false, wallet: false, driverStatus: false, gender: true });
      v({ emailPhone: false, role: false, availability: false, wallet: false, driverStatus: false, gender: false });
      return variants;
    };

    const buildPassengerInsertVariants = (): Record<string, unknown>[] => {
      const wb = userData.walletBalance ?? 0;
      const variants: Record<string, unknown>[] = [];
      const v = (emailPhone: boolean, wallet: boolean, gender: boolean) => {
        const row: Record<string, unknown> = { name: userData.name, cpf: normalizedCpf };
        if (wallet) row.wallet_balance = wb;
        if (emailPhone) {
          if (userData.email) row.email = String(userData.email).trim();
          if (userData.phone) row.phone = String(userData.phone).replace(/\D/g, '');
        }
        if (gender && genderVal) row.gender = genderVal;
        variants.push(row);
      };
      v(true, true, true);
      v(false, true, true);
      v(false, false, true);
      v(false, false, false);
      return variants;
    };

    const { data: existingCpf } = await supabase.from(tableName).select('id').eq('cpf', normalizedCpf).maybeSingle();
    if (existingCpf) {
      return {
        ok: false,
        message: 'Este CPF já está cadastrado nesta base. Use a opção de login.',
      };
    }

    const attempts =
      userData.role === 'DRIVER' ? buildDriverInsertVariants() : buildPassengerInsertVariants();

    let data: Record<string, unknown> | null = null;
    let lastError: { message?: string; code?: string } | null = null;

    for (let i = 0; i < attempts.length; i++) {
      const insertData = attempts[i];
      console.log(`[STORE] Cadastro ${userData.role} tentativa ${i + 1}/${attempts.length}:`, Object.keys(insertData));
      const res = await supabase.from(tableName).insert([insertData]).select().single();
      if (!res.error && res.data) {
        data = res.data as Record<string, unknown>;
        break;
      }
      lastError = res.error;
      if (res.error && !isColumnMissingError(res.error)) {
        console.error(`[STORE] Erro ao registrar ${userData.role}:`, res.error.message, res.error.code);
        return { ok: false, message: describeRegisterError(res.error) };
      }
      console.warn('[STORE] Retentando cadastro (coluna ausente ou schema):', res.error?.message);
    }

    if (!data) {
      console.error(`[STORE] Cadastro ${userData.role} esgotou variantes. Último erro:`, lastError);
      return {
        ok: false,
        message: lastError ? describeRegisterError(lastError) : 'Não foi possível concluir o cadastro.',
      };
    }

    const rowId = String(data.id);

    const facialFile: File | undefined =
      userData.facialPhoto instanceof File ? (userData.facialPhoto as File) : undefined;
    if (facialFile && facialFile.size > 0) {
      try {
        const ext = facialFile.name.split('.').pop() || 'jpg';
        const fileName = `${rowId}/facial_register_${Date.now()}.${ext}`;
        const buckets = getDriverDocumentBucketCandidates();
        let uploadedUrl: string | null = null;
        for (const bucket of buckets) {
          const { error: upErr } = await supabase.storage.from(bucket).upload(fileName, facialFile);
          if (!upErr) {
            const { data: pub } = supabase.storage.from(bucket).getPublicUrl(fileName);
            uploadedUrl = pub.publicUrl;
            break;
          }
          console.warn(`[STORE] Upload facial bucket "${bucket}":`, upErr.message);
        }
        if (uploadedUrl) {
          const { error: patchErr } = await supabase
            .from(tableName)
            .update({ profile_photo_url: uploadedUrl })
            .eq('id', rowId);
          if (patchErr) {
            console.warn('[STORE] Foto facial enviada mas update profile_photo_url falhou:', patchErr.message);
          } else {
            (data as { profile_photo_url?: string }).profile_photo_url = uploadedUrl;
          }
        }
      } catch (e) {
        console.warn('[STORE] Exceção no upload facial:', e);
      }
    }

    console.log(`[STORE] Registro bem-sucedido: ID=${rowId}`);

    const dataRec = data as Record<string, unknown>;
    const fleetParsed = userData.role === 'DRIVER' ? parseDriverFleetFromRow(dataRec) : {};

    const mergedGender =
      (data.gender as string | undefined) ||
      genderVal ||
      (userData.gender === 'MALE' || userData.gender === 'FEMALE' || userData.gender === 'OTHER'
        ? userData.gender
        : null);

    const newUser: AnyUser = {
      id: data.id as string,
      name: data.name as string,
      role: userData.role as any,
      cpf: data.cpf as string,
      email: typeof data.email === 'string' ? data.email : userData.email,
      phone: typeof data.phone === 'string' ? data.phone : userData.phone,
      walletBalance: data.wallet_balance != null ? Number(data.wallet_balance) : Number(userData.walletBalance ?? 0),
      ...(userData.role === 'DRIVER' && {
        driverStatus: (data.driver_status as string) || userData.driverStatus || 'PENDING_DOCS',
        status: normalizeDriverStatus(readDriverAvailabilityStatus(data as Record<string, unknown>)),
        acceptsPetRides: Boolean((data as { accepts_pet_rides?: boolean }).accepts_pet_rides),
        gender: mergedGender as Driver['gender'],
        fleetVehicles: fleetParsed.fleetVehicles,
        activeFleetVehicleId: fleetParsed.activeFleetVehicleId,
        vehicle: mergeDriverVehicleFromJson(dataRec) || undefined,
        profilePhotoUrl:
          typeof (data as { profile_photo_url?: string }).profile_photo_url === 'string'
            ? (data as { profile_photo_url?: string }).profile_photo_url
            : undefined,
        shareLocationOnSafetyRadar: true,
      }),
      ...(userData.role === 'PASSENGER' && {
        savedPlaces: normalizeSavedPlaces((data as { saved_places?: unknown }).saved_places),
        emergencyContacts: (data as { emergency_contacts?: EmergencyContact[] }).emergency_contacts || [],
        gender: mergedGender as Passenger['gender'],
        savedPaymentMethods: normalizeSavedPaymentMethods(
          (data as { saved_payment_methods?: unknown }).saved_payment_methods
        ),
        profilePhotoUrl:
          typeof (data as { profile_photo_url?: string }).profile_photo_url === 'string'
            ? (data as { profile_photo_url?: string }).profile_photo_url
            : undefined,
      }),
    } as AnyUser;

    if (newUser.role === 'DRIVER') {
      setDrivers((prev) => [...prev, newUser as Driver]);
    } else if (newUser.role === 'PASSENGER') {
      setPassengers((prev) => [...prev, newUser as Passenger]);
    }
    return { ok: true, user: newUser };
  }, []);

  const loginUser = useCallback(async (cpf: string, role: string) => {
    const tableName = role === 'PASSENGER' ? 'passengers' : 'drivers';
    const normalizedCpf = cpf.replace(/\D/g, '');
    
    console.log(`[STORE] Login attempt: role=${role}, cpf=${cpf}, normalized=${normalizedCpf}`);

    // Try Supabase first
    const { data: dbUser, error: dbError } = await supabase
      .from(tableName)
      .select('*')
      .eq('cpf', normalizedCpf)
      .single();

    if (dbError) {
      console.warn(`[STORE] Supabase login error for ${normalizedCpf}:`, dbError.message);
    }

    let userToReturn: AnyUser | null = null;

    if (dbUser) {
      console.log(`[STORE] User found in Supabase: ${dbUser.name}`);
      const displayName =
        role === 'PASSENGER'
          ? passengerDisplayName(dbUser.name, dbUser.cpf)
          : (dbUser.name as string);
      const dbRec = dbUser as Record<string, unknown>;
      const fleetLogin = role === 'DRIVER' ? parseDriverFleetFromRow(dbRec) : {};

      let loginVehicle: Vehicle | undefined;
      if (role === 'DRIVER') {
        const vj = mergeDriverVehicleFromJson(dbRec);
        if (vj?.plate) loginVehicle = vj;
        else {
          try {
            const { data: vOne } = await supabase
              .from('vehicles')
              .select('*')
              .eq('driver_id', dbUser.id)
              .limit(1)
              .maybeSingle();
            if (vOne && typeof vOne === 'object') {
              loginVehicle = vehicleFromVehiclesTableRow(vOne as Record<string, unknown>);
            }
          } catch {
            /* ignore */
          }
        }
      }

      userToReturn = {
        id: dbUser.id,
        name: displayName,
        role: role as any,
        cpf: dbUser.cpf,
        email: typeof dbUser.email === 'string' ? dbUser.email : undefined,
        phone: typeof dbUser.phone === 'string' ? dbUser.phone : undefined,
        walletBalance: dbUser.wallet_balance ? Number(dbUser.wallet_balance) : 0,
        ...(role === 'DRIVER' && {
          driverStatus: dbUser.driver_status || undefined,
          status: normalizeDriverStatus(readDriverAvailabilityStatus(dbUser as Record<string, unknown>)),
          acceptsPetRides: dbUser.accepts_pet_rides || false,
          gender: dbUser.gender || null,
          location: dbUser.location,
          vehicle: loginVehicle,
          fleetVehicles: fleetLogin.fleetVehicles,
          activeFleetVehicleId: fleetLogin.activeFleetVehicleId,
          cnhUrl: dbUser.cnh_url,
          certificationUrl: dbUser.certification_url,
          criminalRecordUrl: typeof (dbUser as { criminal_record_url?: string }).criminal_record_url === 'string'
            ? (dbUser as { criminal_record_url?: string }).criminal_record_url
            : undefined,
          profilePhotoUrl: dbUser.profile_photo_url,
          shareLocationOnSafetyRadar:
            (dbUser as { share_location_safety_radar?: boolean }).share_location_safety_radar !== false,
        }),
        ...(role === 'PASSENGER' && {
          savedPlaces: normalizeSavedPlaces(dbUser.saved_places),
          emergencyContacts: dbUser.emergency_contacts || [],
          gender: dbUser.gender || null,
          savedPaymentMethods: normalizeSavedPaymentMethods(
            (dbUser as { saved_payment_methods?: unknown }).saved_payment_methods
          ),
          profilePhotoUrl:
            typeof (dbUser as { profile_photo_url?: string }).profile_photo_url === 'string'
              ? (dbUser as { profile_photo_url?: string }).profile_photo_url
              : undefined,
        })
      } as AnyUser;
    } else {
      // Fallback: search in the loaded users list (in case of RLS or other Supabase issues)
      console.log(`[STORE] Not found in Supabase table ${tableName}. Checking local users list...`);
      const localUser = role === 'DRIVER' 
        ? drivers.find(u => u.cpf?.replace(/\D/g, '') === normalizedCpf)
        : passengers.find(u => u.cpf?.replace(/\D/g, '') === normalizedCpf);
      
      if (localUser) {
        console.log(`[STORE] User found in local list: ${localUser.name}`);
        userToReturn =
          role === 'PASSENGER'
            ? ({
                ...localUser,
                name: passengerDisplayName(localUser.name, localUser.cpf),
              } as AnyUser)
            : localUser;
      }
    }

    if (!userToReturn) {
      console.error(`[STORE] No user found for CPF ${normalizedCpf} in ${role} role.`);
    } else {
      if (role === 'DRIVER') {
        const d = userToReturn as Driver;
        setDrivers((prev) => {
          if (prev.some((x) => x.id === d.id)) {
            return prev.map((x) => (x.id === d.id ? { ...x, ...d } : x));
          }
          return [...prev, d];
        });
      }
      if (role === 'PASSENGER') {
        const p = userToReturn as Passenger;
        setPassengers((prev) => {
          if (prev.some((x) => x.id === p.id)) {
            return prev.map((x) => (x.id === p.id ? { ...x, ...p } : x));
          }
          return [...prev, p];
        });
      }
    }

    return userToReturn;
  }, [drivers, passengers]);

  const submitDriverDocs = useCallback(async (userId: string, vehicleData: any, files: { cnh?: File, crlv?: File, certification?: File, criminalRecord?: File, profile?: File }) => {
    try {
      let cnhUrl = '';
      let crlvUrl = '';
      let certificationUrl = '';
      let criminalRecordUrl = '';
      let profileUrl = '';

      console.log('[STORE] submitDriverDocs arquivos:', {
        cnh: !!files.cnh,
        crlv: !!files.crlv,
        certification: !!files.certification,
        criminalRecord: !!files.criminalRecord,
        profile: !!files.profile,
      });

      const uploadFile = async (file: File, path: string) => {
        const bucketsTried: string[] = [];
        const fileExt = file.name.split('.').pop();
        const fileName = `${userId}/${path}_${Date.now()}.${fileExt}`;
        let lastErr: { message?: string } | null = null;
        for (const bucket of getDriverDocumentBucketCandidates()) {
          bucketsTried.push(bucket);
          const { error: uploadError } = await supabase.storage.from(bucket).upload(fileName, file);
          if (!uploadError) {
            const { data } = supabase.storage.from(bucket).getPublicUrl(fileName);
            console.log(`[STORE] URL ${path} (bucket ${bucket}):`, data.publicUrl);
            return data.publicUrl;
          }
          lastErr = uploadError;
          console.error(`[STORE] Storage bucket "${bucket}" ${path}:`, uploadError.message);
        }
        throw new Error(formatDriverStorageError(lastErr, bucketsTried));
      };

      if (files.cnh) cnhUrl = await uploadFile(files.cnh, 'cnh');
      if (files.crlv) crlvUrl = await uploadFile(files.crlv, 'crlv');
      if (files.certification) certificationUrl = await uploadFile(files.certification, 'certification');
      if (files.criminalRecord) criminalRecordUrl = await uploadFile(files.criminalRecord, 'criminal_record');
      if (files.profile) profileUrl = await uploadFile(files.profile, 'profile_photo');

      console.log('[STORE] URLs geradas:', { cnhUrl, crlvUrl, certificationUrl, criminalRecordUrl, profileUrl });

      // 1. Insere dados do Veículo (Placa, Ano, Modelo...)
      const { error: vehError } = await supabase
        .from('vehicles')
        .upsert([{
          driver_id: userId,
          plate: vehicleData.plate,
          model: vehicleData.model,
          brand: vehicleData.brand,
          color: vehicleData.color,
          manufacturing_year: parseInt(vehicleData.year),
          maximum_capacity: parseInt(vehicleData.capacity),
          status: 'PENDING',
          crlv_url: crlvUrl || null // Garante que mandamos null se vazio para o BD
        }], { onConflict: 'plate' });

      if (vehError) {
        const msg = `${vehError.message || ''} ${(vehError as { code?: string }).code || ''}`;
        const vehiclesTableMissing =
          /could not find the table.*vehicles|schema cache.*vehicles|relation.*vehicles.*does not exist/i.test(
            msg
          );
        if (vehiclesTableMissing) {
          console.warn(
            '[STORE] Tabela public.vehicles ausente no Supabase; seguindo sem upsert de veículo. Rode scripts/ensure-vehicles-table.sql no SQL Editor.'
          );
        } else {
          console.error('Erro ao salvar veículo:', vehError);
          alert('Erro no banco de dados (Veículo): ' + vehError.message);
          return false;
        }
      }

      // 2. Registra o LOG LGPD Imutável
      await supabase
        .from('lgpd_terms_logs')
        .insert([{
          user_id: userId,
          ip_address: '127.0.0.1',
          term_version: 'v1.0-IMMU'
        }]);

      // 3. Atualiza status e URLs na tabela de Drivers
      const driverUpdate: Record<string, unknown> = { driver_status: 'UNDER_REVIEW' };
      if (cnhUrl) driverUpdate.cnh_url = cnhUrl;
      if (certificationUrl) driverUpdate.certification_url = certificationUrl;
      if (criminalRecordUrl) driverUpdate.criminal_record_url = criminalRecordUrl;
      if (profileUrl) driverUpdate.profile_photo_url = profileUrl;

      let { error: userError } = await supabase.from('drivers').update(driverUpdate).eq('id', userId);

      /** PostgREST: coluna ausente em drivers — remove do payload e tenta de novo (URLs ficam no estado local). */
      const isDriversSchemaColumnError = (err: { message?: string; code?: string } | null) => {
        if (!err) return false;
        const blob = `${err.message || ''} ${err.code || ''}`;
        return /column|schema cache|PGRST204/i.test(blob);
      };
      const parseMissingDriversColumn = (message: string | undefined): string | null => {
        if (!message) return null;
        const m1 = /Could not find the '([^']+)' column of 'drivers'/i.exec(message);
        if (m1?.[1]) return m1[1];
        const m2 = /Could not find the "([^"]+)" column of 'drivers'/i.exec(message);
        if (m2?.[1]) return m2[1];
        return null;
      };
      const droppableDriverDocColumns = new Set(['cnh_url', 'certification_url', 'criminal_record_url', 'profile_photo_url']);
      let schemaRetries = 0;
      while (userError && isDriversSchemaColumnError(userError) && schemaRetries < 16) {
        const col = parseMissingDriversColumn(userError.message);
        if (!col || !(col in driverUpdate) || !droppableDriverDocColumns.has(col)) break;
        delete driverUpdate[col];
        console.warn(
          `[STORE] Coluna drivers.${col} ausente no Supabase; reintentando update sem ela. Adicione a coluna (scripts/ensure-drivers-document-columns.sql).`
        );
        ({ error: userError } = await supabase.from('drivers').update(driverUpdate).eq('id', userId));
        schemaRetries += 1;
      }

      if (userError) {
        console.error('Erro ao atualizar motorista:', userError);
        alert('Erro no banco de dados (Motorista): ' + userError.message);
        return false;
      }

      setCurrentUser(prev => prev ? {
        ...prev,
        driverStatus: 'UNDER_REVIEW',
        cnhUrl: cnhUrl || (prev as Driver).cnhUrl,
        certificationUrl: certificationUrl || (prev as Driver).certificationUrl,
        criminalRecordUrl: criminalRecordUrl || (prev as Driver).criminalRecordUrl,
        profilePhotoUrl: profileUrl || (prev as Driver).profilePhotoUrl,
        vehicle: (prev as Driver).vehicle ? {
          ...(prev as Driver).vehicle,
          crlvUrl: crlvUrl || (prev as Driver).vehicle?.crlvUrl
        } : undefined
      } as AnyUser : null);

      return true;
    } catch (err) {
      console.error("Erro geral no submitDriverDocs:", err);
      const detail = err instanceof Error ? err.message : "Erro desconhecido ao enviar";
      alert(`❌ Documentos não enviados\n\n${detail}`);
      return false;
    }
  }, []);

  const createRide = useCallback(async (rideData: Omit<Ride, 'id' | 'status' | 'createdAt' | 'updatedAt'>) => {
    if (!canUseSupabase()) {
      console.error('[STORE] createRide: Supabase não disponível (URL/chave ou cliente inválido).');
      return null;
    }

    const pid = String(rideData.passengerId ?? '').trim();
    if (!pid) {
      console.error('[STORE] createRide: passengerId obrigatório.');
      return null;
    }

    const oLat = Number(rideData.origin?.lat);
    const oLng = Number(rideData.origin?.lng);
    const dLat = Number(rideData.destination?.lat);
    const dLng = Number(rideData.destination?.lng);
    if (![oLat, oLng, dLat, dLng].every((n) => Number.isFinite(n))) {
      console.error('[STORE] createRide: origem/destino com coordenadas inválidas.');
      return null;
    }
    if (oLat < -90 || oLat > 90 || dLat < -90 || dLat > 90 || oLng < -180 || oLng > 180 || dLng < -180 || dLng > 180) {
      console.error('[STORE] createRide: coordenadas fora do intervalo válido.');
      return null;
    }

    const oAddr = String(rideData.origin?.address ?? '').trim();
    const dAddr = String(rideData.destination?.address ?? '').trim();
    if (!oAddr || !dAddr) {
      console.error('[STORE] createRide: endereços de origem e destino são obrigatórios.');
      return null;
    }

    const estPrice = Number(rideData.estimatedPrice);
    const offPrice = Number(rideData.offeredPrice);
    const estTime = Number(rideData.estimatedTime);
    if (!Number.isFinite(estPrice) || estPrice < 0 || !Number.isFinite(offPrice) || offPrice < 0) {
      console.error('[STORE] createRide: preços inválidos.');
      return null;
    }
    if (!Number.isFinite(estTime) || estTime < 0) {
      console.error('[STORE] createRide: tempo estimado inválido.');
      return null;
    }

    const origPrice = rideData.originalPrice != null ? Number(rideData.originalPrice) : estPrice;
    const finPrice = rideData.finalPrice != null ? Number(rideData.finalPrice) : estPrice;
    const disc = rideData.discountApplied != null ? Number(rideData.discountApplied) : 0;
    const cb = rideData.cashbackGenerated != null ? Number(rideData.cashbackGenerated) : 0;

    const insertRow: Record<string, unknown> = {
      passenger_id: pid,
      origin_lat: oLat,
      origin_lng: oLng,
      origin_address: oAddr,
      dest_lat: dLat,
      dest_lng: dLng,
      dest_address: dAddr,
      category: rideData.category,
      estimated_price: estPrice,
      offered_price: offPrice,
      estimated_time: estTime,
      last_offer_by: rideData.lastOfferBy ?? 'PASSENGER',
      ride_type: rideData.rideType || 'NORMAL',
      is_terminal_ride: Boolean(rideData.isTerminalRide),
      terminal_origin_id: rideData.terminalOriginId ?? null,
      terminal_destination_id: rideData.terminalDestinationId ?? null,
      original_price: origPrice,
      discount_applied: disc,
      final_price: finPrice,
      cashback_generated: cb,
      cashback_blocked_reason: rideData.cashbackBlockedReason ?? null,
      status: 'WAITING_PAYMENT',
    };

    if (rideData.paymentMethod != null && rideData.paymentMethod !== undefined) {
      insertRow.payment_method = rideData.paymentMethod;
    }

    if (rideData.waypoints?.length) {
      insertRow.stops = rideData.waypoints.map((w) => ({
        lat: w.lat,
        lng: w.lng,
        address: w.address,
      }));
    }

    let { data, error } = await supabase.from('rides').insert([insertRow]).select().single();

    if (error && insertRow.stops != null && /stops|column|schema cache/i.test(String(error.message || ''))) {
      const { stops: _s, ...withoutStops } = insertRow;
      const retry = await supabase.from('rides').insert([withoutStops]).select().single();
      data = retry.data;
      error = retry.error;
      if (!error) {
        console.warn('[STORE] Corrida criada sem coluna stops; rode scripts/ensure-rides-stops.sql no Supabase.');
      }
    }

    if (error) {
      console.error(
        '[STORE] Erro ao criar corrida no Supabase:',
        error.message,
        error.code ?? '',
        error.details ?? '',
        error.hint ?? ''
      );
      return null;
    }

    const ride = mapSupabaseRideToFront(data);
    setRides((prev) => (prev.some((r) => r.id === ride.id) ? prev : [ride, ...prev]));
    return ride;
  }, [mapSupabaseRideToFront]);

  const updateRideStatus = useCallback(async (id: string, status: RideStatus, driverId?: string) => {
    // 1. Store previous state for rollback
    let previousRides: Ride[] | undefined;
    setRides(prev => {
      previousRides = [...prev];
      return prev.map(ride => ride.id === id ? { ...ride, status, driverId: driverId || ride.driverId, updatedAt: new Date() } : ride);
    });

    if (isDemoMode || !canUseSupabase()) {
      return;
    }

    const updateObj: any = { status, updated_at: new Date().toISOString() };
    if (driverId) updateObj.driver_id = driverId;
    if (status === 'IN_PROGRESS') updateObj.start_time = Date.now();

    const { error } = await supabase.from('rides').update(updateObj).eq('id', id);

    if (error) {
      console.error("Erro ao atualizar status no Supabase:", error);
      if (previousRides) {
        setRides(previousRides);
        alert("Erro de conexão: O status da corrida não pôde ser atualizado.");
      }
      return;
    }

    // Business logic for completed/paid rides
    if (status === 'PAID') {
      const ride = rides.find(r => r.id === id);
      if (ride) {
        const gross = Number(ride.offeredPrice || 0);
        const platformRate = ride.isTerminalRide ? 0.15 : 0.22;
        const platformCut = gross * platformRate;
        const driverCut = gross * 0.70;

        // 1. Update Driver State and DB
        const isCash = ride.paymentMethod === 'Dinheiro';
        const netDriverAmount = isCash ? -platformCut : driverCut;

        setDrivers(prev => prev.map(d => {
          if (d.id === (driverId || ride.driverId)) {
            return { ...d, walletBalance: (d.walletBalance || 0) + netDriverAmount };
          }
          return d;
        }));

        const dId = driverId || ride.driverId;
        if (dId) {
          supabase.from('drivers').select('wallet_balance').eq('id', dId).single().then(({ data: dbDriver }: any) => {
            if (dbDriver) {
              const newBal = Number(dbDriver.wallet_balance || 0) + netDriverAmount;
              supabase.from('drivers').update({ wallet_balance: newBal }).eq('id', dId).then();
              
              const transactions = [];
              if (!isCash) {
                transactions.push({ user_id: dId, user_role: 'DRIVER', amount: ride.offeredPrice, transaction_type: 'RIDE_PAYMENT', ride_id: ride.id, description: `Pagamento da Corrida (${ride.paymentMethod || 'App'})` });
              }
              transactions.push({ user_id: dId, user_role: 'DRIVER', amount: -platformCut, transaction_type: 'TAKE_RATE_APP', ride_id: ride.id, description: `Taxa plataforma (${(platformRate * 100).toFixed(0)}%)` });
              
              supabase.from('wallet_transactions').insert(transactions).then();
            }
          });
        }

        // 2. Cashback logic for Passenger
        if (!ride.isTerminalRide) {
          const cashbackBase = Number(ride.finalPrice ?? ride.offeredPrice ?? 0);
          const cashback = cashbackBase * 0.08;
          setPassengers(prev => prev.map(p => {
            if (p.id === ride.passengerId) {
              return { ...p, walletBalance: (p.walletBalance || 0) + cashback };
            }
            return p;
          }));

          supabase.from('rides').update({ cashback_generated: cashback }).eq('id', ride.id).then();
          supabase.from('passengers').select('wallet_balance').eq('id', ride.passengerId).single().then(({ data: dbPass }: any) => {
            if (dbPass) {
              const newBal = Number(dbPass.wallet_balance || 0) + cashback;
              supabase.from('passengers').update({ wallet_balance: newBal }).eq('id', ride.passengerId).then();
              supabase.from('wallet_transactions').insert([
                { user_id: ride.passengerId, user_role: 'PASSENGER', amount: cashback, transaction_type: 'CASHBACK', ride_id: ride.id, description: 'Cashback 8%' }
              ]).then();
            }
          });
        } else {
          // Nullify cashback
          supabase.from('rides').update({ cashback_generated: 0, cashback_blocked_reason: 'Integracao Terminal (15% OFF)' }).eq('id', ride.id).then();
        }
      }
    }
  }, [rides, isDemoMode]);

  const confirmRidePayment = useCallback(
    async (rideId: string, opts: { cashbackApplied: number; remainderMethod: string }) => {
      const ride = rides.find((r) => r.id === rideId);
      if (!ride) return;

      const totalDue = Number(ride.finalPrice ?? ride.offeredPrice ?? 0);
      if (totalDue <= 0) {
        triggerError('Valor da corrida inválido.');
        return;
      }

      const passengerId = ride.passengerId;
      const passRow = passengers.find((p) => p.id === passengerId);
      const walletPass = passRow?.walletBalance ?? 0;
      const walletCurrent =
        currentUser?.role === 'PASSENGER' && currentUser.id === passengerId
          ? (currentUser.walletBalance ?? 0)
          : walletPass;
      const wallet = Math.max(walletPass, walletCurrent);

      const cashbackApplied = ride.isTerminalRide
        ? 0
        : Math.min(Math.max(0, opts.cashbackApplied), totalDue, wallet);
      const remainder = Math.round((totalDue - cashbackApplied) * 100) / 100;

      if (remainder > 0 && !['Pix', 'Crédito', 'Débito', 'Dinheiro'].includes(opts.remainderMethod)) {
        triggerError('Escolha Pix, Crédito, Débito ou Dinheiro para pagar o valor restante.');
        return;
      }
      if (remainder <= 0 && cashbackApplied <= 0) {
        triggerError('Use o cashback disponível ou escolha uma forma de pagamento.');
        return;
      }

      const paymentLabel =
        remainder > 0 ? opts.remainderMethod : cashbackApplied > 0 ? 'Cashback' : opts.remainderMethod;

      const applyLocalSuccess = () => {
        setPassengers((prev) =>
          prev.map((p) =>
            p.id === passengerId ? { ...p, walletBalance: (p.walletBalance || 0) - cashbackApplied } : p
          )
        );
        setCurrentUser((prev) => {
          if (!prev || prev.id !== passengerId || prev.role !== 'PASSENGER') return prev;
          return {
            ...prev,
            walletBalance: (prev.walletBalance || 0) - cashbackApplied,
          } as AnyUser;
        });
        setRides((prev) =>
          prev.map((r) =>
            r.id === rideId
              ? {
                  ...r,
                  cashbackAppliedToPayment: cashbackApplied,
                  paymentMethod: paymentLabel as Ride['paymentMethod'],
                  status: 'MATCHING',
                  updatedAt: new Date(),
                }
              : r
          )
        );
      };

      /** Testes / demo: não depende do Supabase (evita RLS/erro de rede). */
      const simulateOk =
        isDemoMode ||
        process.env.NEXT_PUBLIC_SIMULATE_PAYMENTS === 'true' ||
        !canUseSupabase();

      if (simulateOk) {
        applyLocalSuccess();
        return;
      }

      const ts = new Date().toISOString();
      const baseRideUpdate = {
        payment_method: paymentLabel,
        status: 'MATCHING' as const,
        updated_at: ts,
      };

      if (cashbackApplied > 0) {
        const { error: wErr } = await supabase
          .from('passengers')
          .update({ wallet_balance: wallet - cashbackApplied })
          .eq('id', passengerId);
        if (wErr) {
          console.error('[STORE] Erro ao debitar cashback:', wErr.message);
          triggerError('Não foi possível usar o saldo de cashback. Tente outra forma de pagamento.');
          return;
        }
      }

      let { error: rideErr } = await supabase
        .from('rides')
        .update(
          !ride.isTerminalRide
            ? { ...baseRideUpdate, cashback_applied_to_payment: cashbackApplied }
            : baseRideUpdate
        )
        .eq('id', rideId);

      if (rideErr) {
        const { error: retryErr } = await supabase.from('rides').update(baseRideUpdate).eq('id', rideId);
        if (retryErr) {
          if (cashbackApplied > 0) {
            await supabase.from('passengers').update({ wallet_balance: wallet }).eq('id', passengerId);
          }
          console.error('[STORE] Erro ao confirmar pagamento da corrida:', retryErr.message);
          triggerError('Não foi possível confirmar o pagamento. Tente novamente.');
          return;
        }
      }

      applyLocalSuccess();
    },
    [rides, passengers, currentUser, triggerError, isDemoMode]
  );

  const updateRidePrice = useCallback(async (id: string, newPrice: number, offeredBy: 'PASSENGER' | 'DRIVER', driverId?: string) => {
    // 1. Store previous state for rollback
    let previousRides: Ride[] | undefined;
    setRides(prev => {
      previousRides = [...prev];
      return prev.map(ride => ride.id === id ? { ...ride, offeredPrice: newPrice, lastOfferBy: offeredBy, status: 'NEGOTIATING', updatedAt: new Date() } : ride);
    });

    if (isDemoMode || !canUseSupabase()) {
      return;
    }

    const updateObj: any = {
      offered_price: newPrice,
      last_offer_by: offeredBy,
      status: 'NEGOTIATING',
      updated_at: new Date().toISOString()
    };
    if (driverId) updateObj.driver_id = driverId;

    const { error } = await supabase.from('rides').update(updateObj).eq('id', id);
    if (error) {
      console.error("Erro ao atualizar preço no Supabase:", error);
      if (previousRides) {
        setRides(previousRides);
        alert("Erro ao enviar contraproposta: Verifique sua conexão.");
      }
    }
  }, [isDemoMode]);

  const updateUserLocation = useCallback(async (userId: string, location: Location, role: 'DRIVER' | 'PASSENGER' = 'DRIVER') => {
    if (role === 'DRIVER') {
      setDrivers((prev) => {
        if (prev.some((d) => d.id === userId)) {
          return prev.map((d) => (d.id === userId ? { ...d, location } : d));
        }
        return prev;
      });
    }
    setCurrentUser((prev) => {
      if (!prev || prev.id !== userId) return prev;
      const next = { ...prev, location } as AnyUser;
      if (prev.role === 'DRIVER') {
        setDrivers((dprev) => {
          if (dprev.some((d) => d.id === userId)) return dprev;
          return [...dprev, { ...(next as Driver) }];
        });
      }
      return next;
    });

    if (!canUseSupabase()) return;
    const tableName = role === 'PASSENGER' ? 'passengers' : 'drivers';
    try {
      await supabase.from(tableName).update({
        location: { lat: location.lat, lng: location.lng },
        address_text: location.address
      }).eq('id', userId);
    } catch (e) {
      console.warn('[STORE] updateUserLocation:', e);
    }
  }, []);

  const updateDriverStatus = useCallback(async (userId: string, status: 'OFFLINE' | 'ONLINE' | 'IN_RIDE') => {
    const uid = String(userId);
    const cuSync = currentUserRef.current;
    if (cuSync && String(cuSync.id) === uid) {
      currentUserRef.current = { ...(cuSync as Driver), role: 'DRIVER', status } as AnyUser;
    }

    setCurrentUser((prev) => {
      if (!prev || String(prev.id) !== uid) return prev;
      return { ...(prev as Driver), role: 'DRIVER', status } as AnyUser;
    });
    setDrivers((prev) => {
      if (prev.some((d) => String(d.id) === uid)) {
        return prev.map((d) => (String(d.id) === uid ? { ...d, status } : d));
      }
      const cu = currentUserRef.current;
      if (cu && String(cu.id) === uid) {
        return [...prev, { ...(cu as Driver), role: 'DRIVER', status }];
      }
      return prev;
    });

    if (isDemoMode || !canUseSupabase()) {
      return;
    }

    const { data, error } = await persistDriverAvailabilityToSupabase(uid, status);

    if (error) {
      console.warn('[STORE] Erro ao atualizar status online/offline:', error.message, error.code);
      const perm =
        error.code === '42501' ||
        /permission denied|rls|row-level security/i.test(error.message || '');
      if (perm) {
        triggerError(
          'Não foi possível salvar ONLINE no banco (permissão/RLS). O app mantém o estado local; ajuste as políticas UPDATE na tabela drivers no Supabase.'
        );
      }
      return;
    }

    const persisted = data
      ? normalizeDriverStatus(readDriverAvailabilityStatus(data as unknown as Record<string, unknown>))
      : status;
    if (persisted !== status) {
      console.warn('[STORE] Status persistido diferente do solicitado:', { pedido: status, retorno: persisted });
    }
  }, [isDemoMode, triggerError]);

  const updateDriverClearance = useCallback(async (userId: string, driverStatus: 'PENDING_DOCS' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED', reason?: string) => {
    // 1. Store previous state for rollback
    let previousDriver: Driver | undefined;

    setDrivers(prev => {
      previousDriver = prev.find(d => d.id === userId);
      return prev.map(d => d.id === userId ? { ...d, driverStatus, rejectionReason: reason } : d);
    });

    setCurrentUser(prev => prev?.id === userId ? { ...prev, driverStatus, rejectionReason: reason } as AnyUser : prev);

    // 2. Prepare Payload
    const updatePayload: any = { driver_status: driverStatus };
    if (driverStatus === 'REJECTED') {
      updatePayload.rejection_reason = reason || 'Documentos inconsistentes';
    } else {
      updatePayload.rejection_reason = null;
    }

    // 3. Update remote
    const { error } = await supabase.from('drivers').update(updatePayload).eq('id', userId);

    if (error) {
      console.error("Erro crítico ao sincronizar status com Supabase:", error);

      // 4. Robust Rollback
      if (previousDriver) {
        setDrivers(prev => prev.map(d => d.id === userId ? previousDriver! : d));
        if (currentUser?.id === userId) {
          setCurrentUser(previousDriver);
        }
        alert(`Falha na sincronização: O status de ${previousDriver.name} foi revertido devido a um erro de rede ou permissão.`);
      }
    }
  }, [currentUser]);

  const addTerminal = async (terminal: Omit<BusTerminal, 'id'>) => {
    try {
      const { data, error } = await supabase.from('bus_terminals').insert(terminal).select().single();
      if (error) throw error;
      setTerminals(prev => [...prev, {
        id: data.id,
        name: data.name,
        address: data.address,
        zone_or_bairro: data.zone_or_bairro,
        lat: Number(data.lat),
        lng: Number(data.lng),
        active: data.active
      }]);
      return true;
    } catch (err) {
      console.error("Erro ao adicionar terminal:", err);
      triggerError("Erro ao criar terminal de ônibus. Verifique conexão.");
      return false;
    }
  };

  const updateTerminal = async (id: string, updates: Partial<BusTerminal>) => {
    try {
      const { data, error } = await supabase.from('bus_terminals').update(updates).eq('id', id).select().single();
      if (error) throw error;
      setTerminals(prev => prev.map(t => t.id === id ? {
        ...t,
        name: data.name,
        address: data.address,
        zone_or_bairro: data.zone_or_bairro,
        lat: Number(data.lat),
        lng: Number(data.lng),
        active: data.active
      } : t));
      return true;
    } catch (err) {
      console.error("Erro ao atualizar terminal:", err);
      return false;
    }
  };

  const deleteTerminal = async (id: string) => {
    try {
      const { error } = await supabase.from('bus_terminals').delete().eq('id', id);
      if (error) throw error;
      setTerminals(prev => prev.filter(t => t.id !== id));
      return true;
    } catch (err) {
      console.error("Erro ao excluir terminal:", err);
      return false;
    }
  };

  const addWalletBalance = useCallback(async (userId: string, amount: number) => {
    const amt = Math.round(Number(amount) * 100) / 100;
    if (!Number.isFinite(amt) || amt === 0) return;

    const sid = String(userId);
    const isDriver = drivers.some((d) => String(d.id) === sid);
    const isPassenger = passengers.some((p) => String(p.id) === sid);
    const sessionRole = currentUserRef.current?.role;
    const table: 'drivers' | 'passengers' | null = isDriver
      ? 'drivers'
      : isPassenger
        ? 'passengers'
        : sessionRole === 'DRIVER' && String(currentUserRef.current?.id) === sid
          ? 'drivers'
          : sessionRole === 'PASSENGER' && String(currentUserRef.current?.id) === sid
            ? 'passengers'
            : null;

    if (table === 'drivers') {
      setDrivers((prev) => {
        const i = prev.findIndex((d) => String(d.id) === sid);
        if (i < 0) {
          const cu = currentUserRef.current;
          if (cu?.role === 'DRIVER' && String(cu.id) === sid) {
            const d = cu as Driver;
            return [...prev, { ...d, walletBalance: (d.walletBalance || 0) + amt }];
          }
          return prev;
        }
        return prev.map((d) => (String(d.id) === sid ? { ...d, walletBalance: (d.walletBalance || 0) + amt } : d));
      });
    } else if (table === 'passengers') {
      setPassengers((prev) => {
        const i = prev.findIndex((p) => String(p.id) === sid);
        if (i < 0) {
          const cu = currentUserRef.current;
          if (cu?.role === 'PASSENGER' && String(cu.id) === sid) {
            const p = cu as Passenger;
            return [...prev, { ...p, walletBalance: (p.walletBalance || 0) + amt }];
          }
          return prev;
        }
        return prev.map((p) => (String(p.id) === sid ? { ...p, walletBalance: (p.walletBalance || 0) + amt } : p));
      });
    }

    setCurrentUser((prev) =>
      prev && String(prev.id) === sid
        ? ({ ...prev, walletBalance: (prev.walletBalance || 0) + amt } as AnyUser)
        : prev
    );

    if (!canUseSupabase() || !table) return;
    const { data: row } = await supabase.from(table).select('wallet_balance').eq('id', userId).maybeSingle();
    if (row != null) {
      const base = row.wallet_balance != null ? Number(row.wallet_balance) : 0;
      const nb = Math.round((base + amt) * 100) / 100;
      await supabase.from(table).update({ wallet_balance: nb }).eq('id', userId);
    }
  }, [drivers, passengers]);

  const requestDriverWithdrawal = useCallback(async (userId: string, amount: number): Promise<boolean> => {
    const amt = Math.round(Number(amount) * 100) / 100;
    if (!Number.isFinite(amt) || amt <= 0) return false;
    const sid = String(userId);

    const cu = currentUserRef.current;
    const sessionBal =
      cu?.role === 'DRIVER' && String(cu.id) === sid ? Number((cu as Driver).walletBalance ?? 0) : 0;
    const listed = drivers.find((x) => String(x.id) === sid);
    const listBal = listed != null ? Number(listed.walletBalance ?? 0) : 0;
    const effective = Math.max(sessionBal, listBal);

    if (effective < amt) return false;

    setDrivers((prev) => {
      const i = prev.findIndex((x) => String(x.id) === sid);
      if (i < 0) {
        if (cu?.role === 'DRIVER' && String(cu.id) === sid) {
          return [...prev, { ...(cu as Driver), walletBalance: Math.max(0, effective - amt) }];
        }
        return prev;
      }
      const curListed = Number(prev[i].walletBalance ?? 0);
      const baseForRow = Math.max(curListed, sessionBal);
      return prev.map((x, idx) =>
        idx === i ? { ...x, walletBalance: Math.max(0, baseForRow - amt) } : x
      );
    });

    setCurrentUser((prev) =>
      prev?.role === 'DRIVER' && String(prev.id) === sid
        ? { ...(prev as Driver), walletBalance: Math.max(0, effective - amt) }
        : prev
    );

    const ref = `MOCK-PIX-${Date.now()}`;
    const entry: DriverWithdrawal = {
      id: `w_${Date.now()}`,
      driverId: String(userId),
      amount: amt,
      createdAt: new Date().toISOString(),
      status: 'COMPLETED',
      reference: ref,
    };
    setDriverWithdrawals((prev) => {
      const next = [entry, ...prev];
      try {
        localStorage.setItem('inviagem_driver_withdrawals', JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });

    if (canUseSupabase()) {
      const { data: row } = await supabase.from('drivers').select('wallet_balance').eq('id', userId).maybeSingle();
      if (row != null) {
        const base = row.wallet_balance != null ? Number(row.wallet_balance) : effective;
        const nb = Math.max(0, Math.round((base - amt) * 100) / 100);
        await supabase.from('drivers').update({ wallet_balance: nb }).eq('id', userId);
      }
    }
    return true;
  }, [drivers]);

  const updateDriverFleetVehicles = useCallback(
    async (userId: string, fleet: DriverFleetVehicle[], activeId: string | undefined) => {
      const sanitized = fleet.map((v) =>
        v.kind === 'MOTO' ? { ...v, acceptsPet: false as const } : v
      );
      const active = activeId || sanitized[0]?.id;
      setDrivers((prev) =>
        prev.map((d) =>
          String(d.id) === String(userId)
            ? { ...d, fleetVehicles: sanitized, activeFleetVehicleId: active }
            : d
        )
      );
      setCurrentUser((prev) =>
        prev?.role === 'DRIVER' && String(prev.id) === String(userId)
          ? { ...(prev as Driver), fleetVehicles: sanitized, activeFleetVehicleId: active }
          : prev
      );
      if (!canUseSupabase()) return;
      const payload = { list: sanitized, activeId: active };
      const { error } = await supabase.from('drivers').update({ fleet_json: payload }).eq('id', userId);
      if (error) {
        console.warn('[STORE] Atualização de frota (fleet_json):', error.message);
      }
    },
    []
  );

  const deleteDriverAccount = useCallback(async (userId: string) => {
    try {
      // 1. Delete vehicle first (foreign key dependency usually requires this)
      await supabase.from('vehicles').delete().eq('driver_id', userId);

      // 1.b Delete LGPD terms logs
      await supabase.from('lgpd_terms_logs').delete().eq('user_id', userId);

      // 2. Delete driver
      const { error } = await supabase.from('drivers').delete().eq('id', userId);

      if (error) throw error;

      // 3. Update local state
      setDrivers(prev => prev.filter(d => d.id !== userId));

      return true;
    } catch (err) {
      console.error("Erro ao excluir conta:", err);
      alert("Erro ao excluir: " + (err instanceof Error ? err.message : "Erro desconhecido"));
      return false;
    }
  }, []);

  const addSponsor = useCallback((sponsor: Omit<Sponsor, 'id'>) => {
    setSponsors(prev => [...prev, { ...sponsor, id: `s_${Date.now()}` }]);
  }, []);

  const addSponsoredLocation = useCallback((location: Omit<SponsoredLocation, 'id'>) => {
    setSponsoredLocations(prev => [...prev, { ...location, id: `l_${Date.now()}` }]);
  }, []);

  const toggleSponsorStatus = useCallback((id: string) => {
    setSponsors(prev => prev.map(s => s.id === id ? { ...s, active: !s.active } : s));
  }, []);

  const toggleLocationStatus = useCallback((id: string) => {
    setSponsoredLocations(prev => prev.map(l => l.id === id ? { ...l, active: !l.active } : l));
  }, []);

  const trackAdEvent = useCallback((locationId: string, event: 'impression' | 'click' | 'conversion') => {
    setSponsoredLocations(prev => prev.map(l => {
      if (l.id === locationId) {
        const stats = l.stats || { impressions: 0, clicks: 0, conversions: 0 };
        return {
          ...l,
          stats: {
            ...stats,
            [event + 's']: stats[event + 's' as keyof typeof stats] + 1
          }
        };
      }
      return l;
    }));
  }, []);

  const addChatMessage = useCallback((rideId: string, senderId: string, text: string) => {
    setRides(prev => prev.map(ride => {
      if (ride.id === rideId) {
        const newMessage: ChatMessage = {
          id: `msg_${Date.now()}`,
          senderId,
          text,
          timestamp: Date.now()
        };
        return {
          ...ride,
          messages: [...(ride.messages || []), newMessage]
        };
      }
      return ride;
    }));
  }, []);

  const addGlobalChatMessage = useCallback((text: string) => {
    if (!currentUser) return;
    const msg: GlobalChatMessage = {
      id: `gmsg_${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      text,
      timestamp: Date.now()
    };
    setGlobalChats(prev => [...prev, msg]);
    if (canUseSupabaseRealtime()) {
      supabase.channel('global_chat').send({
        type: 'broadcast',
        event: 'new_message',
        payload: msg
      });
    }
  }, [currentUser]);

  useEffect(() => {
    if (!canUseSupabaseRealtime()) return;

    const channel = supabase.channel('global_chat')
      .on('broadcast', { event: 'new_message' }, (payload) => {
        setGlobalChats(prev => {
          // Avoid duplicating optimistic message
          if (prev.some(m => m.id === payload.payload.id)) return prev;
          return [...prev, payload.payload as GlobalChatMessage];
        });
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Simulation Logic
  useEffect(() => {
    if (!isDemoMode) return;

    // REMOVED: Auto-assignment of driver. User wants to do this manually.

    const assignedRide = rides.find(r => r.status === 'DRIVER_ASSIGNED');
    if (assignedRide) {
      // Driver takes about 5-10 seconds to "arrive" at the origin in demo
      const timer = setTimeout(() => {
        updateRideStatus(assignedRide.id, 'DRIVER_ARRIVING');
      }, 8000);
      return () => clearTimeout(timer);
    }

    const arrivingRide = rides.find(r => r.status === 'DRIVER_ARRIVING');
    if (arrivingRide) {
      // Passenger takes about 4 seconds to "board" in demo
      const timer = setTimeout(() => {
        updateRideStatus(arrivingRide.id, 'IN_PROGRESS');
      }, 6000);
      return () => clearTimeout(timer);
    }

    const inProgressRide = rides.find(r => r.status === 'IN_PROGRESS');
    if (inProgressRide) {
      // Scale: 1 minute estimated = 2 seconds real time for demo purposes
      const duration = (inProgressRide.estimatedTime || 5) * 2000;
      const timer = setTimeout(() => {
        updateRideStatus(inProgressRide.id, 'COMPLETED');
        if (inProgressRide.driverId) updateDriverStatus(inProgressRide.driverId, 'ONLINE');
      }, duration);
      return () => clearTimeout(timer);
    }
  }, [rides, isDemoMode, updateRideStatus, updateDriverStatus]);

  return (
    <StoreContext.Provider
      value={{
        rides,
        drivers,
        passengers,
        admins,
        terminals,
        sponsors,
        sponsoredLocations,
        hotspots,
        currentUser,
        setCurrentUser,
        registerUser,
        loginUser,
        submitDriverDocs,
        createRide,
        updateRideStatus,
        confirmRidePayment,
        updateRidePrice,
        updateUserLocation,
        updateDriverStatus,
        addSponsor,
        addSponsoredLocation,
        toggleSponsorStatus,
        toggleLocationStatus,
        trackAdEvent,
        addChatMessage,
        addHotspot,
        removeHotspot,
        updateHotspot,
        updateDriverClearance,
        addWalletBalance,
        requestDriverWithdrawal,
        driverWithdrawals,
        updateDriverFleetVehicles,
        deleteDriverAccount,
        isDemoMode,
        setDemoMode,
        immuTaxCollected,
        violations,
        resolveViolation,
        addTerminal,
        updateTerminal,
        deleteTerminal,
        globalError,
        triggerError,
        globalChats,
        addGlobalChatMessage,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
