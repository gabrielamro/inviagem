-- Locais salvos do motorista (mesmo formato que passageiro: array JSON)
ALTER TABLE IF EXISTS public.drivers ADD COLUMN IF NOT EXISTS saved_places jsonb DEFAULT '[]'::jsonb;

COMMENT ON COLUMN public.drivers.saved_places IS 'Locais favoritos: [{ title, address, lat?, lng? }]';
