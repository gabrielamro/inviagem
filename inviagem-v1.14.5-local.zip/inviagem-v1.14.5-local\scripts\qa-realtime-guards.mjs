/**
 * Smoke estático: evita regressão onde `supabase.channel` roda sem cliente Realtime
 * (ex.: env Supabase vazio → stub sem `.channel` → crash na abertura).
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, '..');
const storePath = path.join(root, 'lib', 'store.tsx');
const clientPath = path.join(root, 'lib', 'supabaseClient.ts');

function read(p) {
  return fs.readFileSync(p, 'utf8');
}

let failed = false;

const store = read(storePath);
if (!store.includes('canUseSupabaseRealtime')) {
  console.error('[QA] lib/store.tsx deve importar e usar canUseSupabaseRealtime para Realtime.');
  failed = true;
}
if (!store.includes("if (!canUseSupabaseRealtime()) return")) {
  console.error('[QA] Falta guard no useEffect do global_chat (canUseSupabaseRealtime).');
  failed = true;
}
if (!store.includes('if (canUseSupabaseRealtime())')) {
  console.error('[QA] Falta guard em subscribe/broadcast (canUseSupabaseRealtime).');
  failed = true;
}

const client = read(clientPath);
if (!client.includes('export function canUseSupabaseRealtime')) {
  console.error('[QA] lib/supabaseClient.ts deve exportar canUseSupabaseRealtime().');
  failed = true;
}

if (failed) {
  process.exit(1);
}
console.log('[QA] Guards de Realtime Supabase OK.');
