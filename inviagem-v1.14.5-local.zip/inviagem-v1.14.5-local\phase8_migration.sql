DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='ride_type') THEN
        ALTER TABLE rides ADD COLUMN "ride_type" VARCHAR(50) DEFAULT 'NORMAL';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='is_terminal_ride') THEN
        ALTER TABLE rides ADD COLUMN "is_terminal_ride" BOOLEAN DEFAULT FALSE;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='terminal_origin_id') THEN
        ALTER TABLE rides ADD COLUMN "terminal_origin_id" VARCHAR(255);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='terminal_destination_id') THEN
        ALTER TABLE rides ADD COLUMN "terminal_destination_id" VARCHAR(255);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='original_price') THEN
        ALTER TABLE rides ADD COLUMN "original_price" NUMERIC;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='discount_applied') THEN
        ALTER TABLE rides ADD COLUMN "discount_applied" NUMERIC DEFAULT 0;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='final_price') THEN
        ALTER TABLE rides ADD COLUMN "final_price" NUMERIC;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='cashback_generated') THEN
        ALTER TABLE rides ADD COLUMN "cashback_generated" NUMERIC DEFAULT 0;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='cashback_blocked_reason') THEN
        ALTER TABLE rides ADD COLUMN "cashback_blocked_reason" VARCHAR(255);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='rides' AND column_name='payment_method') THEN
        ALTER TABLE rides ADD COLUMN "payment_method" VARCHAR(50);
    END IF;
END $$;
