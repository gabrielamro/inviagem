1:"$Sreact.fragment"
2:I[9466,["730","static/chunks/44530001-06db68a5a9898251.js","533","static/chunks/533-a69a9e067df4d591.js","466","static/chunks/466-be83b66241c8776d.js","177","static/chunks/app/layout-ff3b3541871dccf0.js"],"StoreProvider"]
3:I[9766,[],""]
4:I[9567,["39","static/chunks/app/error-b8466be1b1ee2fb1.js"],"default"]
5:I[8924,[],""]
6:I[1959,[],"ClientPageRoot"]
7:I[4084,["974","static/chunks/app/page-e5f3774445724f09.js"],"default"]
a:I[4431,[],"OutletBoundary"]
c:I[5278,[],"AsyncMetadataOutlet"]
e:I[4431,[],"ViewportBoundary"]
10:I[4431,[],"MetadataBoundary"]
11:"$Sreact.suspense"
13:I[8731,["219","static/chunks/app/global-error-7224df31dc7d0976.js"],"default"]
:HL["/_next/static/css/bc5ff8ee4ed45ad1.css","style"]
0:{"P":null,"b":"inviagem-1776031423204","p":"","c":["",""],"i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/bc5ff8ee4ed45ad1.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"pt-BR","className":"__variable_f367f3 __variable_3c557b dark","children":["$","body",null,{"className":"antialiased font-sans selection:bg-white/30","suppressHydrationWarning":true,"children":[["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$4","errorStyles":[],"errorScripts":[],"template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","div",null,{"className":"fixed bottom-1 right-1 z-[9999] max-w-[min(90vw,280px)] truncate text-[10px] text-emerald-500/70 font-mono pointer-events-none select-none text-right leading-tight","title":"Versão do app e carimbo de build","children":[["$","span",null,{"className":"font-semibold text-emerald-400/90","children":["v","1.14.5"]}],["$","span",null,{"className":"block text-[9px] text-white/25 mt-0.5","children":"2026-04-12T22:03:43.194Z"}]]}]]}]}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L6",null,{"Component":"$7","searchParams":{},"params":{},"promises":["$@8","$@9"]}],null,["$","$La",null,{"children":["$Lb",["$","$Lc",null,{"promise":"$@d"}]]}]]}],{},null,false]},null,false],["$","$1","h",{"children":[null,[["$","$Le",null,{"children":"$Lf"}],null],["$","$L10",null,{"children":["$","div",null,{"hidden":true,"children":["$","$11",null,{"fallback":null,"children":"$L12"}]}]}]]}],false]],"m":"$undefined","G":["$13",[]],"s":false,"S":true}
8:{}
9:"$0:f:0:1:2:children:1:props:children:0:props:params"
f:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
b:null
d:{"metadata":[["$","title","0",{"children":"Inviagem | Mobilidade Premium"}],["$","meta","1",{"name":"description","content":"Plataforma de transporte com aplicativos para Passageiro, Motorista e Administrador."}]],"error":null,"digest":"$undefined"}
12:"$d:metadata"
