'use client';

import React, { useState, useEffect, useLayoutEffect, useCallback, useRef, useMemo } from 'react';
import {
  useStore,
  Ride,
  Location,
  Passenger,
  PassengerSavedCard,
  SavedPlace,
  Driver,
} from '@/lib/store';
import { estimateRidePrice } from '@/lib/ridePricing';
import { sumDirectionsLegs } from '@/lib/routeMetrics';
import { passengerDisplayName } from '@/lib/passengerPrefill';
import { supabase } from '@/lib/supabaseClient';
import { MapPin, Navigation, CreditCard, MessageSquare, ShieldAlert, Star, Search, Car, CheckCircle2, User as UserIcon, ArrowRight, ArrowLeft, Menu, X, Volume2, VolumeX, Play, Timer, ShieldCheck, Info, Check, DollarSign, Share2, Wind, Clock, Calendar, Map, AlertOctagon, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useRouter } from 'next/navigation';
import { GoogleMap, useLoadScript, Marker, DirectionsRenderer, Autocomplete, Polyline, TrafficLayerF, OverlayViewF } from '@react-google-maps/api';

const mapContainerStyle = {
  width: '100%',
  height: '100%',
};

const defaultCenter = {
  lat: -3.119027, // Manaus
  lng: -60.021731,
};

// Haversine formula for distance fallback (Returns KM)
function getDistanceKM(lat1: number, lon1: number, lat2: number, lon2: number) {
  const p = 0.017453292519943295; // Math.PI / 180
  const c = Math.cos;
  const a = 0.5 - c((lat2 - lat1) * p)/2 + 
          c(lat1 * p) * c(lat2 * p) * 
          (1 - c((lon2 - lon1) * p))/2;
  return 12742 * Math.asin(Math.sqrt(a)); // 2 * R; R = 6371 km
}

/** Região metropolitana de Manaus (aprox.) — validação de locais salvos e geocoding. */
function isInManausMetropolitanArea(lat: number, lng: number) {
  return getDistanceKM(lat, lng, defaultCenter.lat, defaultCenter.lng) <= 85;
}

const libraries: ("places" | "geometry" | "visualization")[] = ["places", "geometry", "visualization"];

export default function PassengerApp() {
  const router = useRouter();
  const { isDemoMode, setDemoMode, createRide, currentUser, setCurrentUser, registerUser, loginUser, updateRideStatus, sponsoredLocations, trackAdEvent, drivers, passengers, rides, addChatMessage, terminals, globalError, triggerError, confirmRidePayment } = useStore();
  const [activeTab, setActiveTab] = useState<'home' | 'ride' | 'settings' | 'ai' | 'history' | 'profile'>('home');

  // Auth & Docs state
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  /** Fluxo de cadastro: escolha de persona antes do formulário de passageiro. */
  const [passengerRegPersona, setPassengerRegPersona] = useState<'choose' | 'passenger' | null>(null);
  const [authName, setAuthName] = useState('');
  const [authCpf, setAuthCpf] = useState('');
  const [authEmail, setAuthEmail] = useState('');
  const [authPhone, setAuthPhone] = useState('');
  const [authError, setAuthError] = useState('');
  const [showMenu, setShowMenu] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [hasAcceptedTerms, setHasAcceptedTerms] = useState(false);
  const [termsName, setTermsName] = useState('');
  const [termsCpf, setTermsCpf] = useState('');
  const [termsEmail, setTermsEmail] = useState('');
  const [termsPhone, setTermsPhone] = useState('');
  const [termsError, setTermsError] = useState('');
  const [profileEmail, setProfileEmail] = useState('');
  const [profilePhone, setProfilePhone] = useState('');

  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [originObj, setOriginObj] = useState<Location | null>(null);
  const [destObj, setDestObj] = useState<Location | null>(null);
  const [extraStops, setExtraStops] = useState<{ id: string, address: string, obj: Location | null }[]>([]);
  const extraStopsRef = useRef(extraStops);
  extraStopsRef.current = extraStops;
  const stopAutocompleteRefs = useRef<Record<string, google.maps.places.Autocomplete | null>>({});

  const [category, setCategory] = useState<'X' | 'Comfort' | 'Black' | 'Moto Entrega' | 'Carro Entrega' | 'Corrida Moto'>('X');
  const [showVehicleOptions, setShowVehicleOptions] = useState(false);
  const [rideType, setRideType] = useState<'NORMAL' | 'WOMEN_ONLY' | 'PET'>('NORMAL');
  const [customPrice, setCustomPrice] = useState<number>(0);
  const [isCustomOfferEnabled, setIsCustomOfferEnabled] = useState(false);
  const [mapCenter, setMapCenter] = useState(defaultCenter);
  const [isEditingPlaces, setIsEditingPlaces] = useState(false);
  /** Formulário "Locais salvos": nome amigável + endereço confirmado no Google. */
  const [newSavedPlaceTitle, setNewSavedPlaceTitle] = useState('');
  const [newSavedPlaceAddress, setNewSavedPlaceAddress] = useState('');
  const [newSavedPlaceObj, setNewSavedPlaceObj] = useState<Location | null>(null);
  const savedPlaceAddressAutocompleteRef = useRef<google.maps.places.Autocomplete | null>(null);
  /** Pagamento do valor restante após abatimento de cashback (corrida normal). */
  const [remainderPaymentMethod, setRemainderPaymentMethod] = useState<'Pix' | 'Crédito' | 'Débito' | 'Dinheiro'>('Pix');
  const [applyWalletCashback, setApplyWalletCashback] = useState(true);
  const [isEditingEmergencyContacts, setIsEditingEmergencyContacts] = useState(false);
  const [newEmergencyContactName, setNewEmergencyContactName] = useState('');
  const [newEmergencyContactPhone, setNewEmergencyContactPhone] = useState('');

  const [prefSilent, setPrefSilent] = useState(false);
  const [prefAC, setPrefAC] = useState(true);
  const [scheduledRide, setScheduledRide] = useState(false);
  const [notification, setNotification] = useState<{ title: string, body: string } | null>(null);
  const [authGender, setAuthGender] = useState<'MALE' | 'FEMALE' | ''>('');
  const [regFacialFile, setRegFacialFile] = useState<File | null>(null);
  const [regFacialPreview, setRegFacialPreview] = useState<string | null>(null);
  const [isProfileInfoOpen, setIsProfileInfoOpen] = useState(false);
  const [isPaymentMethodsOpen, setIsPaymentMethodsOpen] = useState(false);
  const [newCardNumber, setNewCardNumber] = useState('');
  const [newCardCvv, setNewCardCvv] = useState('');
  const [newCardExpiry, setNewCardExpiry] = useState('');
  const [newCardModality, setNewCardModality] = useState<'DEBIT' | 'CREDIT'>('CREDIT');
  const [newCardHolder, setNewCardHolder] = useState('');
  const [newCardNickname, setNewCardNickname] = useState('');

  const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: apiKey || '',
    libraries,
  });

  const [directionsResponse, setDirectionsResponse] = useState<google.maps.DirectionsResult | null>(null);
  const [originAutocomplete, setOriginAutocomplete] = useState<google.maps.places.Autocomplete | null>(null);
  const [destAutocomplete, setDestAutocomplete] = useState<google.maps.places.Autocomplete | null>(null);
  const [mapRef, setMapRef] = useState<google.maps.Map | null>(null);
  const routePolylineRef = useRef<google.maps.Polyline | null>(null);
  const [carAnimPosition, setCarAnimPosition] = useState<google.maps.LatLngLiteral | null>(null);
  const [carHeading, setCarHeading] = useState(0);
  /** Direção do dispositivo / mapa para seta do passageiro (graus, 0 = Norte). */
  const [userHeading, setUserHeading] = useState(0);
  const [isAutoCenter, setIsAutoCenter] = useState(true);
  const originInitializedRef = useRef(false);
  const [isReady, setIsReady] = useState(false);
  /** Após cada novo build, ignora corridas antigas em WAITING_PAYMENT (fantasma na primeira tela). */
  const [hideWaitingPaymentAfterDeploy, setHideWaitingPaymentAfterDeploy] = useState(false);

  useLayoutEffect(() => {
    try {
      const stamp = process.env.NEXT_PUBLIC_BUILD_STAMP ?? '';
      if (!stamp || typeof window === 'undefined') return;
      const key = 'inviagem_passenger_last_build';
      const last = localStorage.getItem(key);
      if (last !== stamp) {
        localStorage.setItem(key, stamp);
        sessionStorage.setItem('inviagem_hide_wp_after_deploy', '1');
        setHideWaitingPaymentAfterDeploy(true);
      } else if (sessionStorage.getItem('inviagem_hide_wp_after_deploy') === '1') {
        setHideWaitingPaymentAfterDeploy(true);
      }
    } catch (_) {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!currentUser || hasAcceptedTerms) return;
    const cpf = currentUser.cpf ?? '';
    setTermsCpf(cpf);
    setTermsName(passengerDisplayName(currentUser.name, cpf));
    const p = currentUser as Passenger;
    setTermsEmail(p.email || '');
    setTermsPhone(p.phone || '');
    setTermsError('');
  }, [currentUser, hasAcceptedTerms]);

  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.location.search.includes('register=1')) {
        setAuthMode('register');
        setPassengerRegPersona('choose');
      }
    } catch {
      /* ignore */
    }
  }, []);

  /** Anexo de cadastro é só estado local: ao voltar para login, não manter arquivo/prévia. */
  useEffect(() => {
    if (currentUser || authMode !== 'login') return;
    setRegFacialFile(null);
    setRegFacialPreview((prev) => {
      if (prev) {
        try {
          URL.revokeObjectURL(prev);
        } catch {
          /* ignore */
        }
      }
      return null;
    });
  }, [currentUser, authMode]);

  useEffect(() => {
    if (activeTab === 'profile' && currentUser?.role === 'PASSENGER') {
      const p = currentUser as Passenger;
      setProfileEmail(p.email || '');
      setProfilePhone(p.phone || '');
    }
  }, [activeTab, currentUser]);

  const savedPlacesGeocodeAttempted = useRef('');

  useEffect(() => {
    if (!isLoaded || !window.google || currentUser?.role !== 'PASSENGER') return;
    const pass = currentUser as Passenger;
    const places = [...(pass.savedPlaces || [])];
    const addrOnlySig = `${pass.id}:${places.map((p) => `${p.title}|${p.address}`).join('||')}`;
    const needsGeocode = places.some(
      (p) =>
        !!p.address &&
        (p.lat == null || p.lng == null || !Number.isFinite(p.lat) || !Number.isFinite(p.lng))
    );
    if (!needsGeocode) return;
    if (savedPlacesGeocodeAttempted.current === addrOnlySig) return;

    let cancelled = false;
    const geocoder = new window.google.maps.Geocoder();
    void (async () => {
      for (let i = 0; i < places.length; i++) {
        if (cancelled) return;
        if (places[i].lat != null && places[i].lng != null && Number.isFinite(places[i].lat) && Number.isFinite(places[i].lng)) {
          continue;
        }
        if (!places[i].address) continue;
        await new Promise<void>((resolve) => {
          geocoder.geocode({ address: places[i].address }, (results, status) => {
            if (!cancelled && status === 'OK' && results?.[0]?.geometry?.location) {
              places[i] = {
                ...places[i],
                lat: results[0].geometry.location.lat(),
                lng: results[0].geometry.location.lng(),
              };
            }
            resolve();
          });
        });
      }
      savedPlacesGeocodeAttempted.current = addrOnlySig;
      if (cancelled) return;
      setCurrentUser({ ...pass, savedPlaces: places });
      void supabase.from('passengers').update({ saved_places: places }).eq('id', pass.id);
    })();
    return () => {
      cancelled = true;
    };
  }, [isLoaded, currentUser, setCurrentUser]);

  // Get current location and watch for changes
  useEffect(() => {
    if (navigator.geolocation && isLoaded) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          const pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          const h = position.coords.heading;
          if (h != null && !Number.isNaN(h)) {
            setUserHeading(h);
          }
          setMapCenter(pos);

          // Only set origin automatically on the first load
          if (!originInitializedRef.current) {
            originInitializedRef.current = true;
            // Try to geocode the address
            if (window.google) {
              const geocoder = new window.google.maps.Geocoder();
              geocoder.geocode({ location: pos }, (results, status) => {
                if (status === 'OK' && results?.[0]) {
                  const address = results[0].formatted_address;
                  setOriginObj({ ...pos, address });
                  setOrigin(address);
                } else {
                  setOriginObj({ ...pos, address: 'Sua localização atual' });
                  setOrigin('Sua localização atual');
                }
              });
            } else {
              setOriginObj({ ...pos, address: 'Sua localização atual' });
              setOrigin('Sua localização atual');
            }
          }
        },
        (error) => {
          console.error("Error: The Geolocation service failed.", error);
        },
        { enableHighAccuracy: true, maximumAge: 0 }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, [isLoaded]);

  // Fit bounds when directions change
  useEffect(() => {
    if (directionsResponse && mapRef) {
      const bounds = directionsResponse.routes[0].bounds;
      if (bounds) {
        // Use a small timeout to ensure the map has processed the renderer
        setTimeout(() => {
          mapRef.fitBounds(bounds, { bottom: 400, left: 50, right: 50, top: 120 });
        }, 50);
      }
    }
  }, [directionsResponse, mapRef]);

  // Removido para permitir o login real via CPF
  /*
  useEffect(() => {
    if (!currentUser || currentUser.role !== 'PASSENGER') {
      const passenger = users.find(u => u.role === 'PASSENGER');
      if (passenger) setCurrentUser(passenger);
    }
  }, [users, currentUser, setCurrentUser]);
  */

  const activeRide = useMemo(() => {
    return rides.find(r => {
      if (r.passengerId !== currentUser?.id) return false;
      if (['COMPLETED', 'PAID', 'CANCELLED', 'NO_DRIVER'].includes(r.status)) return false;
      const ageMs = Date.now() - new Date(r.createdAt).getTime();
      const ageHrs = ageMs / (1000 * 60 * 60);
      if (ageHrs > 2) return false;
      if (r.status === 'WAITING_PAYMENT' && ageMs > 90 * 60 * 1000) return false;
      if (hideWaitingPaymentAfterDeploy && r.status === 'WAITING_PAYMENT') return false;
      return true;
    });
  }, [rides, currentUser?.id, hideWaitingPaymentAfterDeploy]);

  useEffect(() => {
    if (activeRide?.status === 'WAITING_PAYMENT') setShowVehicleOptions(false);
  }, [activeRide?.status, activeRide?.id]);

  // Phase 3: Push Notification for Chat (Mock)
  useEffect(() => {
    if (activeRide?.messages && activeRide.messages.length > 0) {
      const lastMsg = activeRide.messages[activeRide.messages.length - 1];
      if (lastMsg.senderId !== currentUser?.id && !showChat) {
        setNotification({ title: 'Mensagem do Motorista', body: lastMsg.text });
        const timer = setTimeout(() => setNotification(null), 5000);
        return () => clearTimeout(timer);
      }
    }
  }, [activeRide?.messages, showChat, currentUser?.id]);

  // Recalculate route if active ride exists but no directions (e.g. on refresh)
  useEffect(() => {
    if (activeRide && !directionsResponse && isLoaded && window.google) {
      const directionsService = new window.google.maps.DirectionsService();
      directionsService.route({
        origin: activeRide.origin.address,
        destination: activeRide.destination.address,
        travelMode: window.google.maps.TravelMode.DRIVING,
      }).then(result => {
        setDirectionsResponse(result);
      }).catch(err => console.error("Error recalculating route:", err));
    }
  }, [activeRide, directionsResponse, isLoaded]);

  // Car Animation Logic
  useEffect(() => {
    if (activeRide?.status === 'IN_PROGRESS' && directionsResponse && activeRide.startTime && window.google) {
      const path = directionsResponse.routes[0].overview_path;
      const totalDuration = (activeRide.estimatedTime || 5) * 2000; // 1 min = 2 sec for demo

      let animId: number;
      const animate = () => {
        const elapsed = Date.now() - (activeRide.startTime || 0);
        const progress = Math.min(elapsed / totalDuration, 1);

        if (path.length > 1) {
          const totalPoints = path.length;
          const floatIndex = progress * (totalPoints - 1);
          const index = Math.floor(floatIndex);
          const nextIndex = Math.min(index + 1, totalPoints - 1);
          const segmentProgress = floatIndex - index;

          const currentPoint = path[index];
          const nextPoint = path[nextIndex];

          const lat = currentPoint.lat() + (nextPoint.lat() - currentPoint.lat()) * segmentProgress;
          const lng = currentPoint.lng() + (nextPoint.lng() - currentPoint.lng()) * segmentProgress;

          // Calculate heading for rotation
          if (index < totalPoints - 1) {
            const heading = window.google.maps.geometry.spherical.computeHeading(currentPoint, nextPoint);
            setCarHeading(heading);
          }

          const newPos = { lat, lng };
          setCarAnimPosition(newPos);

          // Update route polyline to erase traveled path
          if (routePolylineRef.current) {
            const remainingPath = [newPos, ...path.slice(nextIndex)];
            routePolylineRef.current.setPath(remainingPath);
          }

          if (isAutoCenter && mapRef) {
            mapRef.panTo(newPos);
            if (isAutoCenter) {
              setMapCenter(newPos);
            }
          }
        }

        if (progress < 1) {
          animId = requestAnimationFrame(animate);
        }
      };

      animId = requestAnimationFrame(animate);
      return () => cancelAnimationFrame(animId);
    } else if (carAnimPosition !== null && activeRide?.status !== 'IN_PROGRESS') {
      setTimeout(() => setCarAnimPosition(null), 0);
    }
  }, [activeRide?.status, activeRide?.startTime, activeRide?.estimatedTime, directionsResponse, carAnimPosition, mapRef, isAutoCenter]);

  const handleSendChat = (text: string = chatMessage) => {
    if (!text.trim() || !activeRide || !currentUser) return;

    // Simulate AI Moderation (Phase 3)
    const lowerText = text.toLowerCase();
    if (lowerText.includes('palavrão') || lowerText.includes('ofensa') || lowerText.includes('idiota') || lowerText.includes('burro')) {
      alert("🤖 Inviagem AI: Sua mensagem violou as diretrizes de comunidade e foi bloqueada.");
      return;
    }

    addChatMessage(activeRide.id, currentUser.id, text);
    if (text === chatMessage) setChatMessage('');
  };

  const handleSelectLocationFromAI = (locAddress: string) => {
    setDestination(locAddress);
    setActiveTab('home');

    if (window.google && originObj) {
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ address: locAddress }, async (results, status) => {
        if (status === 'OK' && results?.[0]?.geometry?.location) {
          const newDest = {
            lat: results[0].geometry.location.lat(),
            lng: results[0].geometry.location.lng(),
            address: results[0].formatted_address || locAddress
          };
          setDestObj(newDest);
          await calculateRoute(originObj, newDest);
          setShowVehicleOptions(true);
        } else {
          // Fallback if geocoding fails
          console.warn("Geocoding failed for:", locAddress);
        }
      });
    }
  };

  const calculateRoute = async (originLoc: Location, destLoc: Location, stops: any[] = extraStops) => {
    if (!window.google) {
      setCustomPrice(getEstimatedPrice(category));
      setShowVehicleOptions(true);
      return;
    }
    const directionsService = new window.google.maps.DirectionsService();

    /** Só envia paradas com coordenadas reais (evita texto solto que o Directions resolve errado). */
    const waypoints = (stops || [])
      .filter((s) => {
        const o = s?.obj;
        return o && Number.isFinite(o.lat) && Number.isFinite(o.lng);
      })
      .map((s) => ({
        location: { lat: s.obj.lat, lng: s.obj.lng },
        stopover: true as const,
      }));

    try {
      const originParam = (originLoc.lat && originLoc.lng) ? { lat: originLoc.lat, lng: originLoc.lng } : originLoc.address;
      const destParam = (destLoc.lat && destLoc.lng) ? { lat: destLoc.lat, lng: destLoc.lng } : destLoc.address;

      const results = await directionsService.route({
        origin: originParam,
        destination: destParam,
        ...(waypoints.length > 0 ? { waypoints } : {}),
        travelMode: window.google.maps.TravelMode.DRIVING,
      });
      setDirectionsResponse(results);
      const initialPrice = getEstimatedPrice(category, results);
      setCustomPrice(initialPrice);
    } catch (error) {
      console.error("Error calculating route:", error);
      triggerError?.("Não foi possível traçar a rota. Erro de geolocalização: DIRECTIONS_ROUTE_NOT_FOUND");
      setDirectionsResponse(null);
    }
  };

  const getEstimatedPrice = useCallback((cat: string, routeOverride?: google.maps.DirectionsResult | null) => {
    const route = routeOverride ?? directionsResponse;
    const { distanceKm, durationMin } = sumDirectionsLegs(route as Parameters<typeof sumDirectionsLegs>[0]);
    return estimateRidePrice({ category: cat, distanceKm, durationMin });
  }, [directionsResponse]);

  const autocompleteOptions = React.useMemo(() => {
    if (!isLoaded || !window.google) return undefined;

    // Create a bounds object roughly 50km around the current map center
    const offset = 0.5; // roughly 50km
    return {
      bounds: new window.google.maps.LatLngBounds(
        new window.google.maps.LatLng(mapCenter.lat - offset, mapCenter.lng - offset),
        new window.google.maps.LatLng(mapCenter.lat + offset, mapCenter.lng + offset)
      ),
      strictBounds: false, // bias towards the bounds, but don't restrict strictly
    };
  }, [isLoaded, mapCenter]);

  const applySavedPlaceToRide = (place: SavedPlace, role: 'origin' | 'destination') => {
    if (!place.address) return;
    const loc: Location = {
      lat: place.lat ?? mapCenter.lat,
      lng: place.lng ?? mapCenter.lng,
      address: place.address,
    };
    if (place.lat == null || place.lng == null || !Number.isFinite(place.lat) || !Number.isFinite(place.lng)) {
      if (!window.google) {
        if (role === 'destination') {
          setDestination(place.address);
          setDestObj(loc);
        } else {
          setOrigin(place.address);
          setOriginObj(loc);
        }
        return;
      }
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ address: place.address }, (results, status) => {
        if (status === 'OK' && results?.[0]?.geometry?.location) {
          const g = results[0].geometry.location;
          const fixed: Location = { lat: g.lat(), lng: g.lng(), address: place.address };
          if (role === 'destination') {
            setDestination(place.address);
            setDestObj(fixed);
            if (originObj) void calculateRoute(originObj, fixed);
          } else {
            setOrigin(place.address);
            setOriginObj(fixed);
            setMapCenter({ lat: fixed.lat, lng: fixed.lng });
            if (destObj) void calculateRoute(fixed, destObj);
          }
        }
      });
      return;
    }
    if (role === 'destination') {
      setDestination(place.address);
      setDestObj(loc);
      if (originObj) void calculateRoute(originObj, loc);
    } else {
      setOrigin(place.address);
      setOriginObj(loc);
      setMapCenter({ lat: loc.lat, lng: loc.lng });
      if (destObj) void calculateRoute(loc, destObj);
    }
  };

  const handleRequestRide = async () => {
    if (!originObj || !destObj || !currentUser) return;

    const stopIncomplete = extraStops.some(
      (s) =>
        Boolean(s.address?.trim()) &&
        (!s.obj || !Number.isFinite(s.obj.lat) || !Number.isFinite(s.obj.lng))
    );
    if (stopIncomplete) {
      triggerError('Confirme cada parada escolhendo um endereço na lista do mapa (ou aguarde a busca do endereço terminar).');
      return;
    }

    if (rideType === 'WOMEN_ONLY' && (currentUser as Passenger).gender !== 'FEMALE') {
      triggerError('Somente passageiras podem solicitar corrida só para mulheres.');
      return;
    }

    const { distanceKm: routeKm, durationMin: routeMin } = sumDirectionsLegs(
      directionsResponse as Parameters<typeof sumDirectionsLegs>[0]
    );
    const estimatedPrice = estimateRidePrice({ category, distanceKm: routeKm, durationMin: routeMin });
    const estimatedTime = routeMin;

    const waypointLocs: Location[] = extraStops
      .filter((s) => s.obj && Number.isFinite(s.obj.lat) && Number.isFinite(s.obj.lng) && s.address.trim())
      .map((s) => s.obj!);

    let isTerminal = false;
    let tOriginId = undefined;
    let tDestId = undefined;

    if (terminals && terminals.length > 0) {
      terminals.forEach(t => {
        if (getDistanceKM(t.lat, t.lng, originObj.lat, originObj.lng) < 0.3) {
          isTerminal = true;
          tOriginId = t.id;
        }
        if (getDistanceKM(t.lat, t.lng, destObj.lat, destObj.lng) < 0.3) {
          isTerminal = true;
          tDestId = t.id;
        }
      });
    }

    const discountApplied = isTerminal ? estimatedPrice * 0.15 : 0;
    const finalPrice = estimatedPrice - discountApplied;
    const cashbackEligibleCategory = ['X', 'Comfort', 'Black', 'Corrida Moto'].includes(category);
    const cashbackGenerated = !isTerminal && cashbackEligibleCategory ? finalPrice * 0.08 : 0;
    const cashbackBlockedReason = isTerminal
      ? 'Desconto de Terminal 15% aplicado'
      : !cashbackEligibleCategory
        ? 'Modalidade entrega — sem cashback'
        : undefined;
    const offerPriceToUse = isCustomOfferEnabled ? customPrice : finalPrice;

    const ride = await createRide({
      passengerId: currentUser.id,
      origin: originObj,
      destination: destObj,
      waypoints: waypointLocs.length > 0 ? waypointLocs : undefined,
      category,
      estimatedPrice,
      offeredPrice: offerPriceToUse,
      lastOfferBy: 'PASSENGER',
      estimatedTime,
      rideType,
      isTerminalRide: isTerminal,
      terminalOriginId: tOriginId,
      terminalDestinationId: tDestId,
      originalPrice: estimatedPrice,
      discountApplied,
      finalPrice,
      cashbackGenerated,
      cashbackBlockedReason,
    });

    if (ride) {
      try {
        sessionStorage.removeItem('inviagem_hide_wp_after_deploy');
        setHideWaitingPaymentAfterDeploy(false);
      } catch (_) {
        /* ignore */
      }
      setShowVehicleOptions(false);
      setActiveTab('ride');
    } else {
      triggerError("Falha ao registrar a viagem. Tente novamente.");
    }
  };

  const handleCancelRide = () => {
    if (activeRide) {
      updateRideStatus(activeRide.id, 'CANCELLED');
      setActiveTab('home');
      setDirectionsResponse(null);
      setOrigin('');
      setDestination('');
      setOriginObj(null);
      setDestObj(null);
    }
  };

  const handlePay = () => {
    if (activeRide) {
      // Check for conversion
      const sponsoredLoc = sponsoredLocations.find(l => l.address === activeRide.destination.address);
      if (sponsoredLoc) {
        trackAdEvent(sponsoredLoc.id, 'conversion');
      }

      updateRideStatus(activeRide.id, 'PAID');
      setActiveTab('home');
      setDirectionsResponse(null);
      setOrigin('');
      setDestination('');
      setOriginObj(null);
      setDestObj(null);
    }
  };

  const handleRegisterPassenger = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!authGender) {
      setAuthError('Selecione o gênero (obrigatório para corridas exclusivas e segurança).');
      return;
    }
    if (!regFacialFile) {
      setAuthError('Envie uma foto do rosto para validação cadastral (reconhecimento facial).');
      return;
    }
    const res = await registerUser({
      name: authName,
      role: 'PASSENGER',
      cpf: authCpf,
      email: authEmail.trim() || undefined,
      phone: authPhone.replace(/\D/g, '') || undefined,
      walletBalance: 0,
      gender: authGender,
      facialPhoto: regFacialFile,
    });
    if (res.ok) {
      setCurrentUser(res.user);
      setRegFacialFile(null);
      if (regFacialPreview) {
        try {
          URL.revokeObjectURL(regFacialPreview);
        } catch {
          /* ignore */
        }
        setRegFacialPreview(null);
      }
    } else {
      setAuthError(res.message);
    }
  };

  const handleLoginPassenger = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!authCpf) return setAuthError("Por favor, digite seu CPF.");

    const foundUser = await loginUser(authCpf, 'PASSENGER');
    if (foundUser) {
      setCurrentUser(foundUser);
    } else {
      console.log("Falha no login para CPF:", authCpf);
      setAuthError("Passageiro não encontrado com este CPF.");
    }
  };

  if (!currentUser) {
    return (
      <div className="flex flex-col h-[100dvh] min-h-0 bg-[#050505] text-white max-w-md mx-auto relative overflow-hidden font-sans">
        <div className="absolute top-[-10%] right-[-10%] w-[300px] h-[300px] bg-emerald-500/10 rounded-full blur-[80px] pointer-events-none"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[300px] h-[300px] bg-blue-500/10 rounded-full blur-[80px] pointer-events-none"></div>

        <div className="relative z-10 flex flex-1 flex-col min-h-0 overflow-y-auto overscroll-y-contain px-8 py-6">
        <div className="relative z-10 text-center mb-8 shrink-0">
          <div className="text-3xl font-bold tracking-tighter mb-4">INVIAGEM<span className="text-emerald-500">.</span></div>
          <h1 className="text-2xl font-light tracking-tight">{authMode === 'login' ? 'Bem-vindo de volta' : 'Faça seu cadastro'}</h1>
          <p className="text-white/50 text-sm mt-3 font-light">
            {authMode === 'login' ? 'Faça login para pedir uma corrida.' : 'Junte-se ao app de mobilidade regional.'}
          </p>
          {authError && (
            <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 text-red-500 text-xs rounded-xl">
              {authError}
            </div>
          )}
        </div>

        {authMode === 'login' ? (
          <form className="relative z-10 space-y-4" onSubmit={handleLoginPassenger}>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">CPF (Acesso)</label>
              <input type="text" name="cpf" autoComplete="username" inputMode="numeric" value={authCpf} onChange={(e) => setAuthCpf(e.target.value)} required className="w-full bg-transparent text-white outline-none font-medium text-sm" placeholder="000.000.000-00" />
            </div>

            <button type="submit" className="w-full py-4 mt-8 bg-emerald-600 rounded-full font-bold uppercase tracking-widest text-sm hover:bg-emerald-500 transition-colors shadow-[0_0_20px_rgba(16,185,129,0.2)]">
              Entrar na Conta
            </button>
            <div onClick={(e) => { e.preventDefault(); setAuthName(''); setAuthEmail(''); setAuthPhone(''); setAuthError(''); setAuthMode('register'); setPassengerRegPersona('choose'); }} className="w-full py-4 text-center text-xs font-bold uppercase tracking-widest text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer">
              Não tem conta? Cadastre-se
            </div>
          </form>
        ) : passengerRegPersona !== 'passenger' ? (
          <div className="relative z-10 space-y-4">
            <p className="text-center text-xs text-white/50">Como deseja usar o Inviagem?</p>
            <button
              type="button"
              onClick={() => setPassengerRegPersona('passenger')}
              className="w-full py-4 bg-emerald-600 rounded-2xl font-bold uppercase tracking-widest text-sm hover:bg-emerald-500 transition-colors shadow-[0_0_20px_rgba(16,185,129,0.2)]"
            >
              Sou Passageiro
            </button>
            <button
              type="button"
              onClick={() => router.push('/driver?register=1')}
              className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl font-bold uppercase tracking-widest text-sm hover:bg-white/10 transition-colors text-white/90"
            >
              Sou Motorista
            </button>
            <div onClick={(e) => { e.preventDefault(); setAuthName(''); setAuthEmail(''); setAuthPhone(''); setAuthError(''); setAuthMode('login'); setPassengerRegPersona(null); }} className="w-full py-4 text-center text-xs font-bold uppercase tracking-widest text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer">
              Já tem conta? Fazer Login
            </div>
          </div>
        ) : (
          <form className="relative z-10 space-y-4" onSubmit={handleRegisterPassenger}>
            <button
              type="button"
              onClick={() => { setPassengerRegPersona('choose'); setAuthError(''); }}
              className="text-xs text-white/50 hover:text-white mb-2"
            >
              ← Voltar
            </button>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">Nome Completo</label>
              <input type="text" name="name" autoComplete="name" value={authName} onChange={(e) => setAuthName(e.target.value)} required className="w-full bg-transparent text-white outline-none font-medium text-sm" placeholder="Como quer ser chamado?" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">CPF</label>
              <input type="text" name="cpf-register" autoComplete="off" inputMode="numeric" value={authCpf} onChange={(e) => setAuthCpf(e.target.value)} required className="w-full bg-transparent text-white outline-none font-mono text-sm tracking-wider" placeholder="000.000.000-00" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">E-mail</label>
              <input type="email" name="email-register" autoComplete="email" value={authEmail} onChange={(e) => setAuthEmail(e.target.value)} className="w-full bg-transparent text-white outline-none font-medium text-sm" placeholder="seu@email.com" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">Telefone</label>
              <input type="tel" name="phone-register" autoComplete="tel" value={authPhone} onChange={(e) => setAuthPhone(e.target.value)} className="w-full bg-transparent text-white outline-none font-medium text-sm" placeholder="(92) 90000-0000" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-2">Gênero</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setAuthGender('FEMALE')}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold uppercase border transition ${authGender === 'FEMALE' ? 'bg-pink-500/20 border-pink-500/40 text-pink-300' : 'bg-white/5 border-white/10 text-white/50'}`}
                >
                  Feminino
                </button>
                <button
                  type="button"
                  onClick={() => setAuthGender('MALE')}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-bold uppercase border transition ${authGender === 'MALE' ? 'bg-blue-500/20 border-blue-500/40 text-blue-300' : 'bg-white/5 border-white/10 text-white/50'}`}
                >
                  Masculino
                </button>
              </div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2">
              <label className="text-[10px] uppercase tracking-widest text-white/40 block">Reconhecimento facial</label>
              <p className="text-[10px] text-white/45 leading-relaxed">Tire uma selfie nítida (rosto centralizado). Usamos só para reduzir fraude em corridas exclusivas.</p>
              <input
                type="file"
                accept="image/*"
                capture="user"
                className="text-xs text-white/70 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-emerald-600 file:text-black file:text-[10px] file:font-bold"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  setRegFacialFile(f);
                  setRegFacialPreview((prev) => {
                    if (prev) try { URL.revokeObjectURL(prev); } catch { /* ignore */ }
                    return URL.createObjectURL(f);
                  });
                }}
              />
              {regFacialPreview && (
                <div className="flex flex-col items-center gap-2">
                  <img src={regFacialPreview} alt="Prévia" className="w-24 h-24 rounded-full object-cover border border-emerald-500/40" />
                  <button
                    type="button"
                    onClick={() => {
                      setRegFacialFile(null);
                      setRegFacialPreview((prev) => {
                        if (prev) try { URL.revokeObjectURL(prev); } catch { /* ignore */ }
                        return null;
                      });
                    }}
                    className="text-[10px] uppercase font-bold text-red-400 hover:text-red-300"
                  >
                    Remover foto
                  </button>
                </div>
              )}
            </div>

            <button type="submit" className="w-full py-4 mt-8 bg-emerald-600 rounded-full font-bold uppercase tracking-widest text-sm hover:bg-emerald-500 transition-colors shadow-[0_0_20px_rgba(16,185,129,0.2)]">
              Criar Conta Pessoal
            </button>
            <div onClick={(e) => { e.preventDefault(); setAuthName(''); setAuthEmail(''); setAuthPhone(''); setAuthError(''); setAuthMode('login'); setPassengerRegPersona(null); }} className="w-full py-4 text-center text-xs font-bold uppercase tracking-widest text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer">
              Já tem conta? Fazer Login
            </div>
          </form>
        )}
        </div>
      </div>
    );
  }

  // Fase 1: Onboarding do Passageiro (Termos de Uso e Dados Básicos)
  if (!hasAcceptedTerms) {
    return (
      <div className="flex flex-col h-[100dvh] min-h-0 bg-[#050505] text-white w-full max-w-md mx-auto relative overflow-hidden font-sans">
        <div className="absolute top-[-10%] right-[-10%] w-[300px] h-[300px] bg-emerald-500/10 rounded-full blur-[80px] pointer-events-none"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[300px] h-[300px] bg-blue-500/10 rounded-full blur-[80px] pointer-events-none"></div>

        <div className="relative z-10 flex flex-1 flex-col min-h-0 overflow-y-auto overscroll-y-contain p-8">
        <div className="relative z-10 text-center mb-10 shrink-0">
          <div className="text-3xl font-bold tracking-tighter mb-4">INVIAGEM<span className="text-emerald-500">.</span></div>
          <h1 className="text-2xl font-light tracking-tight">O seu app de mobilidade regional.</h1>
          <p className="text-white/50 text-sm mt-3 font-light">Para sua segurança e cumprimento da legislação local, precisamos de algumas informações.</p>
        </div>

        <form
          className="relative z-10 space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            setTermsError('');
            const name = termsName.trim();
            const cpfDigits = termsCpf.replace(/\D/g, '');
            if (!name) {
              setTermsError('Informe seu nome completo.');
              return;
            }
            if (cpfDigits.length < 11) {
              setTermsError('CPF inválido.');
              return;
            }
            const emailT = termsEmail.trim();
            const phoneT = termsPhone.replace(/\D/g, '');
            const updated: Passenger = {
              ...(currentUser as Passenger),
              name,
              cpf: termsCpf.trim(),
              ...(emailT ? { email: emailT } : {}),
              ...(phoneT ? { phone: phoneT } : {}),
            };
            setCurrentUser(updated);
            const payload: Record<string, unknown> = { name, cpf: termsCpf.trim() };
            if (emailT) payload.email = emailT;
            if (phoneT) payload.phone = phoneT;
            void supabase.from('passengers').update(payload).eq('id', currentUser.id);
            setHasAcceptedTerms(true);
          }}
        >
          {termsError ? (
            <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs rounded-xl">{termsError}</div>
          ) : null}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
            <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">Nome Completo</label>
            <input
              type="text"
              name="passenger-fullname"
              autoComplete="name"
              value={termsName}
              onChange={(e) => setTermsName(e.target.value)}
              required
              className="w-full bg-transparent text-white outline-none font-medium"
              placeholder="Seu nome como no documento"
            />
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
            <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">CPF (Obrigatório Lei Munic. 2.468)</label>
            <input
              type="text"
              name="passenger-cpf"
              autoComplete="off"
              inputMode="numeric"
              placeholder="000.000.000-00"
              value={termsCpf}
              onChange={(e) => setTermsCpf(e.target.value)}
              required
              className="w-full bg-transparent text-white outline-none font-mono tracking-wider"
            />
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
            <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">E-mail</label>
            <input
              type="email"
              name="passenger-email"
              autoComplete="email"
              value={termsEmail}
              onChange={(e) => setTermsEmail(e.target.value)}
              className="w-full bg-transparent text-white outline-none font-medium text-sm"
              placeholder="opcional@email.com"
            />
          </div>
          <div className="bg-white/5 border border-white/10 rounded-2xl p-4 focus-within:border-emerald-500/50 transition-colors">
            <label className="text-[10px] uppercase tracking-widest text-white/40 block mb-1">Telefone</label>
            <input
              type="tel"
              name="passenger-phone"
              autoComplete="tel"
              value={termsPhone}
              onChange={(e) => setTermsPhone(e.target.value)}
              className="w-full bg-transparent text-white outline-none font-medium text-sm"
              placeholder="(92) 90000-0000"
            />
          </div>

          <div className="flex items-start gap-3 mt-6 p-4 bg-emerald-500/5 rounded-2xl border border-emerald-500/10">
            <input type="checkbox" id="terms" required className="mt-1 flex-shrink-0 w-4 h-4 rounded appearance-none border border-emerald-500/50 checked:bg-emerald-500 checked:before:content-['✓'] checked:before:text-black checked:before:flex checked:before:justify-center checked:before:items-center checked:before:text-xs" />
            <label htmlFor="terms" className="text-xs text-white/70 font-light leading-relaxed">
              Li e concordo com os Termos de Uso e Políticas de Privacidade. Autorizo o compartilhamento de dados com o IMMU para fins de fiscalização.
            </label>
          </div>

          <button type="submit" className="w-full py-4 mt-8 bg-emerald-600 rounded-full font-bold uppercase tracking-widest text-sm hover:bg-emerald-500 transition-colors shadow-[0_0_20px_rgba(16,185,129,0.2)]">
            Avançar
          </button>
        </form>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full max-w-md mx-auto relative bg-[#050505] overflow-hidden font-sans text-white">
      {/* GLOBAL ERROR MODAL */}
      <AnimatePresence>
        {globalError && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="absolute top-4 left-4 right-4 z-50 bg-red-500/90 border border-red-500 rounded-2xl p-4 shadow-lg backdrop-blur-md"
          >
            <div className="flex items-center gap-3">
              <AlertOctagon size={20} className="text-white shrink-0" />
              <p className="text-sm font-semibold text-white">{globalError.message}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Map Background */}
      <div className="absolute inset-0 z-0">
        {(!apiKey || loadError) ? (
          <div className="w-full h-full bg-[#1a1a1a] relative overflow-hidden">
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
            <div className="absolute inset-0 flex flex-col items-center justify-center text-white/30 p-6 text-center z-10">
              <MapPin size={48} className="mb-4 text-white/20" />
              <p className="font-medium text-white/50">{!apiKey ? 'Mapa em Modo Simulado (Sem API)' : 'Erro no Google Maps'}</p>
            </div>
          </div>
        ) : isLoaded ? (
          <GoogleMap
            mapContainerStyle={mapContainerStyle}
            center={mapCenter}
            zoom={14}
            onLoad={(map) => setMapRef(map)}
            options={{
              disableDefaultUI: true,
              zoomControl: false,
              styles: [
                { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
                { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
                { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
                { featureType: "administrative.locality", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
                { featureType: "poi", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
                { featureType: "poi.park", elementType: "geometry", stylers: [{ color: "#263c3f" }] },
                { featureType: "poi.park", elementType: "labels.text.fill", stylers: [{ color: "#6b9a76" }] },
                { featureType: "road", elementType: "geometry", stylers: [{ color: "#38414e" }] },
                { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#212a37" }] },
                { featureType: "road", elementType: "labels.text.fill", stylers: [{ color: "#9ca5b3" }] },
                { featureType: "road.highway", elementType: "geometry", stylers: [{ color: "#746855" }] },
                { featureType: "road.highway", elementType: "geometry.stroke", stylers: [{ color: "#1f2835" }] },
                { featureType: "road.highway", elementType: "labels.text.fill", stylers: [{ color: "#f3d19c" }] },
                { featureType: "transit", elementType: "geometry", stylers: [{ color: "#2f3948" }] },
                { featureType: "transit.station", elementType: "labels.text.fill", stylers: [{ color: "#d59563" }] },
                { featureType: "water", elementType: "geometry", stylers: [{ color: "#17263c" }] },
                { featureType: "water", elementType: "labels.text.fill", stylers: [{ color: "#515c6d" }] },
                { featureType: "water", elementType: "labels.text.stroke", stylers: [{ color: "#17263c" }] },
              ],
            }}
          >
            {directionsResponse && (
              <>
                <DirectionsRenderer
                  directions={directionsResponse}
                  options={{
                    suppressMarkers: true,
                    suppressPolylines: true, // Explicitly suppress default polyline to hide traffic colors
                    preserveViewport: true,
                  }}
                />
                {/* Início: Pin Redondo */}
                <Marker
                  position={directionsResponse.routes[0].legs[0].start_location}
                  zIndex={50}
                  icon={{
                    path: window.google.maps.SymbolPath.CIRCLE,
                    scale: 8,
                    fillColor: "#3b82f6",
                    fillOpacity: 1,
                    strokeWeight: 3,
                    strokeColor: "#ffffff",
                  }}
                />
                {/* Paradas: fim de cada perna exceto a última (destino final) */}
                {directionsResponse.routes[0].legs.length > 1 &&
                  directionsResponse.routes[0].legs.slice(0, -1).map((leg, i) => (
                    <Marker
                      key={`stop-${i}`}
                      position={leg.end_location}
                      label={{ text: String(i + 1), color: 'white', fontSize: '10px' }}
                      icon={{
                        path: window.google.maps.SymbolPath.CIRCLE,
                        scale: 7,
                        fillColor: '#f59e0b',
                        fillOpacity: 1,
                        strokeWeight: 2,
                        strokeColor: '#ffffff',
                      }}
                    />
                  ))}
                {/* Fim: Ponto Quadrado */}
                <Marker
                  position={directionsResponse.routes[0].legs[directionsResponse.routes[0].legs.length - 1].end_location}
                  zIndex={50}
                  icon={{
                    path: "M -6,-6 L 6,-6 L 6,6 L -6,6 Z",
                    scale: 1,
                    fillColor: "#ffffff",
                    fillOpacity: 1,
                    strokeWeight: 3,
                    strokeColor: "#3b82f6",
                  }}
                />
                {/* Dynamic Route Polyline */}
                <Polyline
                  key={activeRide?.id} // Force re-mount on new ride
                  path={directionsResponse.routes[0].overview_path}
                  onLoad={(polyline) => {
                    routePolylineRef.current = polyline;
                  }}
                  options={{
                    strokeColor: "#3b82f6",
                    strokeWeight: 5,
                    strokeOpacity: 1,
                    zIndex: 10
                  }}
                />

                {/* Real Traffic Layer from Google Maps API */}
                <TrafficLayerF />
              </>
            )}

            {originObj && !directionsResponse && (
              <Marker
                position={{ lat: originObj.lat, lng: originObj.lng }}
                draggable={true}
                onDragEnd={(e) => {
                  if (e.latLng && window.google) {
                    const newLat = e.latLng.lat();
                    const newLng = e.latLng.lng();
                    const geocoder = new window.google.maps.Geocoder();
                    geocoder.geocode({ location: { lat: newLat, lng: newLng } }, (results, status) => {
                      if (status === 'OK' && results?.[0]) {
                        const address = results[0].formatted_address;
                        const newOrigin = { lat: newLat, lng: newLng, address };
                        setOriginObj(newOrigin);
                        setOrigin(address);
                      }
                    });
                  }
                }}
                icon={{
                  path: window.google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                  scale: 5,
                  fillColor: '#3b82f6',
                  fillOpacity: 1,
                  strokeColor: '#ffffff',
                  strokeWeight: 1.5,
                  rotation: userHeading,
                  anchor: new window.google.maps.Point(0, 2),
                }}
              />
            )}

            {!directionsResponse &&
              currentUser?.role === 'PASSENGER' &&
              ((currentUser as Passenger).savedPlaces || [])
                .filter(
                  (p) =>
                    p.lat != null &&
                    p.lng != null &&
                    Number.isFinite(p.lat) &&
                    Number.isFinite(p.lng)
                )
                .map((p, idx) => (
                  <Marker
                    key={`saved-place-${idx}-${p.title}`}
                    position={{ lat: p.lat as number, lng: p.lng as number }}
                    title={p.title}
                    onClick={() => {
                      applySavedPlaceToRide(p, 'destination');
                    }}
                    icon={{ url: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png' }}
                  />
                ))}

            {activeRide && !directionsResponse && (
              <>
                <Marker
                  position={{ lat: activeRide.origin.lat, lng: activeRide.origin.lng }}
                  icon={{ url: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png' }}
                />
                <Marker
                  position={{ lat: activeRide.destination.lat, lng: activeRide.destination.lng }}
                  icon={{ url: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png' }}
                />
              </>
            )}

            {carAnimPosition && (
              <Marker
                position={carAnimPosition}
                zIndex={55}
                icon={{
                  path: window.google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                  scale: 6,
                  fillColor: '#3b82f6',
                  fillOpacity: 1,
                  strokeColor: '#ffffff',
                  strokeWeight: 1.5,
                  rotation: carHeading,
                  anchor: new window.google.maps.Point(0, 2),
                }}
              />
            )}

            {!directionsResponse &&
              drivers
                .filter(
                  (d: Driver) =>
                    d.status === 'ONLINE' &&
                    d.location &&
                    d.shareLocationOnSafetyRadar !== false
                )
                .map((driver) => (
              <Marker
                key={driver.id}
                position={{ lat: driver.location!.lat, lng: driver.location!.lng }}
                icon={{
                  path: "M20,10 C20,5 30,0 50,0 C70,0 80,5 80,10 V90 C80,95 70,100 50,100 C30,100 20,95 20,90 Z M25,20 C25,20 35,15 50,15 C65,15 75,20 75,20 V35 C75,35 65,38 50,38 C35,38 25,35 25,35 Z M25,45 H75 V75 C75,75 60,80 50,80 C40,80 25,75 25,75 Z M18,25 L12,26 C11,27 11,33 12,34 L18,33 V25 Z M82,25 L88,26 C89,27 89,33 88,34 L82,33 V25 Z",
                  scale: 0.3,
                  fillColor: "#00ff88",
                  fillOpacity: 1,
                  strokeWeight: 1.5,
                  strokeColor: "#065f46",
                  anchor: new window.google.maps.Point(50, 50)
                }}
              />
            ))}

            {!directionsResponse &&
              drivers
                .filter(
                  (d: Driver) =>
                    d.status === 'IN_RIDE' && d.location && d.shareLocationOnSafetyRadar !== false
                )
                .map((driver) => {
              const driversActiveRide = rides.find(r => r.driverId === driver.id && !['COMPLETED', 'PAID', 'CANCELLED'].includes(r.status));
              if (!driversActiveRide) return null;

              const distToDriver = originObj ? window.google.maps.geometry.spherical.computeDistanceBetween(
                new window.google.maps.LatLng(originObj.lat, originObj.lng),
                new window.google.maps.LatLng(driver.location!.lat, driver.location!.lng)
              ) : 0;

              if (distToDriver > 10000) return null; // Only show busy drivers within 10km

              return (
                <React.Fragment key={driver.id}>
                  {/* Current Position */}
                  <Marker
                    position={{ lat: driver.location!.lat, lng: driver.location!.lng }}
                    icon={{
                      path: "M20,10 C20,5 30,0 50,0 C70,0 80,5 80,10 V90 C80,95 70,100 50,100 C30,100 20,95 20,90 Z M25,20 C25,20 35,15 50,15 C65,15 75,20 75,20 V35 C75,35 65,38 50,38 C35,38 25,35 25,35 Z M25,45 H75 V75 C75,75 60,80 50,80 C40,80 25,75 25,75 Z M18,25 L12,26 C11,27 11,33 12,34 L18,33 V25 Z M82,25 L88,26 C89,27 89,33 88,34 L82,33 V25 Z",
                      scale: 0.3,
                      fillColor: "#ffeb3b",
                      fillOpacity: 0.7,
                      strokeWeight: 1.5,
                      strokeColor: "#b45309",
                      anchor: new window.google.maps.Point(50, 50)
                    }}
                  />
                  {/* End Position Pin */}
                  <Marker
                    position={{ lat: driversActiveRide.destination.lat, lng: driversActiveRide.destination.lng }}
                    icon={{
                      path: window.google.maps.SymbolPath.CIRCLE,
                      scale: 5,
                      fillColor: "#f59e0b",
                      fillOpacity: 1,
                      strokeWeight: 2,
                      strokeColor: "#ffffff",
                    }}
                  />
                  <OverlayViewF
                    position={{ lat: driversActiveRide.destination.lat, lng: driversActiveRide.destination.lng }}
                    mapPaneName="overlayMouseTarget"
                  >
                    <div className="bg-orange-500/90 backdrop-blur-md text-white text-[9px] px-2 py-1 rounded-lg shadow-lg border border-white/20 whitespace-nowrap -translate-x-1/2 -translate-y-8 animate-bounce">
                      Motorista em corrida (Fim aqui)
                    </div>
                  </OverlayViewF>
                </React.Fragment>
              );
            })}
          </GoogleMap>
        ) : (
          <div className="w-full h-full bg-[#1a1a1a] flex items-center justify-center text-white/50">Carregando Mapa...</div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-[#050505] pointer-events-none"></div>

        {/* Auto-Center Button */}
        {activeRide && !isAutoCenter && (
          <div className="absolute top-24 right-4 z-20 pointer-events-auto">
            <button
              onClick={() => {
                setIsAutoCenter(true);
                if (carAnimPosition) setMapCenter(carAnimPosition);
              }}
              className="w-12 h-12 rounded-full bg-black/60 backdrop-blur-md border border-blue-500/30 flex items-center justify-center text-blue-400 hover:bg-white/10 transition-colors shadow-[0_0_15px_rgba(59,130,246,0.2)]"
              title="Centralizar no Veículo"
            >
              <Navigation size={20} />
            </button>
          </div>
        )}
      </div>

      {/* Header */}
      <header className="absolute top-0 inset-x-0 p-6 z-30 flex justify-between items-center pointer-events-none">
        <div className="flex items-center gap-3 pointer-events-auto">
          <button
            onClick={() => setShowMenu(true)}
            className="w-10 h-10 rounded-full glass-panel flex items-center justify-center border border-white/10 hover:bg-white/10 transition-colors"
          >
            <Menu size={20} />
          </button>
          <div className="text-xl font-bold tracking-tighter drop-shadow-md">INVIAGEM<span className="text-blue-500">.</span></div>
        </div>
        <div className="w-10 h-10 rounded-full glass-panel flex items-center justify-center text-sm font-medium border border-white/10 pointer-events-auto">
          {currentUser.name.charAt(0)}
        </div>
      </header>

      {/* Side Menu / Drawer */}
      <AnimatePresence>
        {showMenu && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMenu(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm z-40"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="absolute inset-y-0 left-0 w-72 bg-[#0a0a0a] border-r border-white/10 z-50 p-6 flex flex-col"
            >
              <div className="flex justify-between items-center mb-10">
                <div className="text-xl font-bold tracking-tighter">INVIAGEM<span className="text-blue-500">.</span></div>
                <button onClick={() => setShowMenu(false)} className="text-white/40 hover:text-white">&times;</button>
              </div>

              <div className="space-y-1 flex-1">
                <p className="text-[10px] uppercase tracking-widest text-white/30 mb-4 ml-2">Modo de Uso</p>
                <button
                  onClick={() => { setShowMenu(false); router.push('/passenger'); }}
                  className="w-full flex items-center gap-4 p-4 rounded-2xl bg-blue-600/10 text-blue-400 border border-blue-500/20"
                >
                  <UserIcon size={20} />
                  <span className="font-medium">Passageiro</span>
                </button>
                <button
                  onClick={() => { setShowMenu(false); router.push('/driver'); }}
                  className="w-full flex items-center gap-4 p-4 rounded-2xl hover:bg-white/5 text-white/60 hover:text-white transition-colors"
                >
                  <Car size={20} />
                  <span className="font-medium">Motorista</span>
                </button>

                <div className="pt-4 mt-4 border-t border-white/5">
                  <p className="text-[10px] uppercase tracking-widest text-white/30 mb-4 ml-2">Configurações</p>
                  <button
                    onClick={() => setDemoMode(!isDemoMode)}
                    className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-colors ${isDemoMode ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-white/5 border-white/10 text-white/40'}`}
                  >
                    <div className="flex items-center gap-4">
                      <ShieldAlert size={20} />
                      <span className="font-medium text-sm">Modo Simulação</span>
                    </div>
                    <div className={`w-10 h-5 rounded-full relative transition-colors ${isDemoMode ? 'bg-emerald-500' : 'bg-white/20'}`}>
                      <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${isDemoMode ? 'right-1' : 'left-1'}`} />
                    </div>
                  </button>
                </div>
              </div>

              <div className="pt-6 border-t border-white/5">
                <div className="flex items-center gap-3 p-2">
                  <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center font-medium">
                    {currentUser.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-medium flex items-center gap-1">
                      {currentUser.name}
                      <ShieldCheck size={14} className="text-blue-400" />
                    </p>
                    <p className="text-[10px] text-white/40 uppercase tracking-tighter">Passageiro Verificado</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <main className="absolute inset-0 z-10 flex flex-col justify-end p-4 pb-28 pointer-events-none">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && !activeRide && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="space-y-4 pointer-events-auto"
            >
              {/* Quick Actions */}
              <AnimatePresence>
                {!directionsResponse && (
                  <motion.div
                    initial={{ opacity: 0, height: 0, y: 10 }}
                    animate={{ opacity: 1, height: 'auto', y: 0 }}
                    exit={{ opacity: 0, height: 0, y: 10 }}
                    className="space-y-2 mb-2 -mx-4 px-4"
                  >
                    <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-1 mask-fade-edges items-center">
                      <button type="button" onClick={() => setActiveTab('ai')} className="glass-panel shrink-0 px-4 py-2.5 rounded-full flex items-center gap-2 hover:bg-white/10 transition-colors">
                        <MessageSquare size={14} className="text-purple-400" />
                        <span className="text-xs font-medium">IA</span>
                      </button>
                    </div>
                    {((currentUser as Passenger)?.savedPlaces || []).length > 0 && (
                      <>
                        <p className="text-[10px] uppercase tracking-widest text-white/35 px-1">Destino rápido</p>
                        <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-1 mask-fade-edges">
                          {((currentUser as Passenger)?.savedPlaces || []).map((place, idx) => (
                            <button
                              key={`sd-${idx}-${place.title}`}
                              type="button"
                              onClick={() => applySavedPlaceToRide(place, 'destination')}
                              className="glass-panel shrink-0 px-4 py-2.5 rounded-full flex items-center gap-2 hover:bg-white/10 transition-colors border border-white/5"
                            >
                              <MapPin size={14} className="text-emerald-400 shrink-0" />
                              <span className="text-xs font-medium whitespace-nowrap max-w-[140px] truncate">{place.title}</span>
                            </button>
                          ))}
                        </div>
                        <p className="text-[10px] uppercase tracking-widest text-white/35 px-1">Partida rápida</p>
                        <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-1 mask-fade-edges">
                          {((currentUser as Passenger)?.savedPlaces || []).map((place, idx) => (
                            <button
                              key={`so-${idx}-${place.title}`}
                              type="button"
                              onClick={() => applySavedPlaceToRide(place, 'origin')}
                              className="glass-panel shrink-0 px-4 py-2.5 rounded-full flex items-center gap-2 hover:bg-white/10 transition-colors border border-white/5"
                            >
                              <Navigation size={14} className="text-blue-400 shrink-0" />
                              <span className="text-xs font-medium whitespace-nowrap max-w-[140px] truncate">{place.title}</span>
                            </button>
                          ))}
                        </div>
                      </>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Booking Form */}
              <div className="glass-panel p-6 rounded-[2rem] space-y-6">
                <AnimatePresence mode="wait">
                  {!directionsResponse ? (
                    <motion.div
                      key="inputs"
                      initial={{ opacity: 0, height: 0, y: 20 }}
                      animate={{ opacity: 1, height: 'auto', y: 0 }}
                      exit={{ opacity: 0, height: 0, y: 20 }}
                      className="space-y-4 relative"
                    >
                      <div className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5">
                        <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.8)]"></div>
                        <div className="flex-1">
                          {isLoaded ? (
                            <Autocomplete
                              options={autocompleteOptions}
                              onLoad={setOriginAutocomplete}
                              onPlaceChanged={() => {
                                if (originAutocomplete) {
                                  const place = originAutocomplete.getPlace();
                                  if (place.geometry?.location) {
                                    const newOrigin = {
                                      lat: place.geometry.location.lat(),
                                      lng: place.geometry.location.lng(),
                                      address: place.formatted_address || place.name || ''
                                    };
                                    setOrigin(newOrigin.address);
                                    setOriginObj(newOrigin);
                                    setMapCenter({ lat: newOrigin.lat, lng: newOrigin.lng });
                                    if (destObj) {
                                      calculateRoute(newOrigin, destObj);
                                    }
                                  }
                                }
                              }}
                            >
                              <div className="relative flex items-center">
                                <input
                                  type="text"
                                  placeholder="Local de partida"
                                  className="bg-transparent w-full outline-none text-sm placeholder:text-white/30 text-white pr-8"
                                  value={origin}
                                  onChange={(e) => setOrigin(e.target.value)}
                                />
                                {origin && (
                                  <button
                                    onClick={() => { setOrigin(''); setOriginObj(null); }}
                                    className="absolute right-0 text-white/30 hover:text-white transition-colors"
                                  >
                                    <X size={14} />
                                  </button>
                                )}
                              </div>
                            </Autocomplete>
                          ) : (
                            <div className="relative flex items-center">
                              <input
                                type="text"
                                placeholder="Local de partida"
                                className="bg-transparent w-full outline-none text-sm placeholder:text-white/30 text-white pr-8"
                                value={origin}
                                onChange={(e) => {
                                  setOrigin(e.target.value);
                                  if (e.target.value) {
                                    const newOrigin = { lat: -23.55, lng: -46.63, address: e.target.value };
                                    setOriginObj(newOrigin);
                                    if (destObj) calculateRoute(newOrigin, destObj);
                                  } else {
                                    setOriginObj(null);
                                  }
                                }}
                              />
                              {origin && (
                                <button
                                  onClick={() => { setOrigin(''); setOriginObj(null); }}
                                  className="absolute right-0 text-white/30 hover:text-white transition-colors"
                                >
                                  <X size={14} />
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                      {/* Fase 4: Dica de Embarque Seguro */}
                      {!directionsResponse && (
                        <div className="flex items-start gap-2 text-[10px] text-white/40 ml-10 mt-[-8px]">
                          <Info size={12} className="shrink-0 mt-0.5" />
                          <span>Sugestão: Aguarde em locais iluminados, evite pedir em vias expressas ou túneis.</span>
                        </div>
                      )}
                      <div className="absolute left-5 top-10 bottom-10 w-px bg-white/10"></div>

                      {/* Paradas Extras */}
                      {extraStops.map((stop, index) => (
                        <div key={stop.id} className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5 transition-all animate-in slide-in-from-left-2 duration-300">
                          <div className="w-2 h-2 rounded-full border-2 border-white/40 shadow-[0_0_8px_rgba(255,255,255,0.3)] shrink-0"></div>
                          <div className="flex-1 relative flex items-center min-w-0">
                            {isLoaded ? (
                              <Autocomplete
                                options={autocompleteOptions}
                                onLoad={(ac) => {
                                  stopAutocompleteRefs.current[stop.id] = ac;
                                }}
                                onPlaceChanged={() => {
                                  const ac = stopAutocompleteRefs.current[stop.id];
                                  if (!ac) return;
                                  const place = ac.getPlace();
                                  if (!place.geometry?.location) {
                                    triggerError?.('Selecione a parada na lista de sugestões do mapa para fixar o ponto.');
                                    return;
                                  }
                                  const loc: Location = {
                                    lat: place.geometry.location.lat(),
                                    lng: place.geometry.location.lng(),
                                    address: place.formatted_address || place.name || '',
                                  };
                                  setExtraStops((prev) => {
                                    const next = prev.map((s) =>
                                      s.id === stop.id ? { ...s, address: loc.address, obj: loc } : s
                                    );
                                    if (originObj && destObj) void calculateRoute(originObj, destObj, next);
                                    return next;
                                  });
                                }}
                              >
                                <div className="relative flex items-center w-full min-w-0">
                                  <input
                                    type="text"
                                    placeholder={`Parada ${index + 1} — busque e toque na sugestão`}
                                    className="bg-transparent w-full outline-none text-sm placeholder:text-white/30 text-white pr-8 min-w-0"
                                    value={stop.address}
                                    onChange={(e) => {
                                      const v = e.target.value;
                                      setExtraStops((prev) =>
                                        prev.map((s) => (s.id === stop.id ? { ...s, address: v, obj: null } : s))
                                      );
                                    }}
                                    onBlur={() => {
                                      const list = extraStopsRef.current;
                                      const addr = list[index]?.address?.trim();
                                      if (!addr || !originObj || !destObj || !window.google) {
                                        if (originObj && destObj) void calculateRoute(originObj, destObj, list);
                                        return;
                                      }
                                      const row = list[index];
                                      if (row?.obj && Number.isFinite(row.obj.lat) && Number.isFinite(row.obj.lng)) {
                                        if (originObj && destObj) void calculateRoute(originObj, destObj, list);
                                        return;
                                      }
                                      const geocoder = new window.google.maps.Geocoder();
                                      geocoder.geocode({ address: addr }, (results, status) => {
                                        setExtraStops((prev) => {
                                          const next = prev.map((s, i) => {
                                            if (i !== index) return s;
                                            if (status === 'OK' && results?.[0]?.geometry?.location) {
                                              const g = results[0].geometry.location;
                                              return {
                                                ...s,
                                                obj: {
                                                  lat: g.lat(),
                                                  lng: g.lng(),
                                                  address: results[0].formatted_address || addr,
                                                },
                                              };
                                            }
                                            return { ...s, obj: null };
                                          });
                                          if (originObj && destObj) void calculateRoute(originObj, destObj, next);
                                          return next;
                                        });
                                      });
                                    }}
                                  />
                                </div>
                              </Autocomplete>
                            ) : (
                              <input
                                type="text"
                                placeholder={`Parada ${index + 1}`}
                                className="bg-transparent w-full outline-none text-sm placeholder:text-white/30 text-white pr-8"
                                value={stop.address}
                                onChange={(e) => {
                                  const v = e.target.value;
                                  setExtraStops((prev) =>
                                    prev.map((s) => (s.id === stop.id ? { ...s, address: v, obj: null } : s))
                                  );
                                }}
                              />
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                delete stopAutocompleteRefs.current[stop.id];
                                const newStops = extraStops.filter((_, i) => i !== index);
                                setExtraStops(newStops);
                                if (originObj && destObj) void calculateRoute(originObj, destObj, newStops);
                              }}
                              className="absolute right-0 text-white/30 hover:text-white transition-colors"
                            >
                              <X size={14} />
                            </button>
                          </div>
                        </div>
                      ))}

                      <div className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5">
                        <div className="w-2 h-2 rounded-full bg-white shadow-[0_0_10px_rgba(255,255,255,0.8)]"></div>
                        <div className="flex-1">
                          {isLoaded ? (
                            <Autocomplete
                              options={autocompleteOptions}
                              onLoad={setDestAutocomplete}
                              onPlaceChanged={() => {
                                if (destAutocomplete) {
                                  const place = destAutocomplete.getPlace();
                                  if (place.geometry?.location) {
                                    const newDest = {
                                      lat: place.geometry.location.lat(),
                                      lng: place.geometry.location.lng(),
                                      address: place.formatted_address || place.name || ''
                                    };
                                    setDestination(newDest.address);
                                    setDestObj(newDest);
                                    if (originObj) {
                                      calculateRoute(originObj, newDest);
                                    }
                                  }
                                }
                              }}
                            >
                              <div className="relative flex items-center">
                                <input
                                  type="text"
                                  placeholder="Para onde vamos?"
                                  className="bg-transparent w-full outline-none text-sm placeholder:text-white/30 text-white pr-8"
                                  value={destination}
                                  onChange={(e) => setDestination(e.target.value)}
                                />
                                {destination && (
                                  <button
                                    onClick={() => { setDestination(''); setDestObj(null); setDirectionsResponse(null); }}
                                    className="absolute right-0 text-white/30 hover:text-white transition-colors"
                                  >
                                    <X size={14} />
                                  </button>
                                )}
                              </div>
                            </Autocomplete>
                          ) : (
                            <div className="relative flex items-center">
                              <input
                                type="text"
                                placeholder="Para onde vamos?"
                                className="bg-transparent w-full outline-none text-sm placeholder:text-white/30 text-white pr-8"
                                value={destination}
                                onChange={(e) => {
                                  setDestination(e.target.value);
                                  if (e.target.value) {
                                    const newDest = { lat: -23.56, lng: -46.64, address: e.target.value };
                                    setDestObj(newDest);
                                    if (originObj) calculateRoute(originObj, newDest);
                                  } else {
                                    setDestObj(null);
                                    setDirectionsResponse(null);
                                  }
                                }}
                              />
                              {destination && (
                                <button
                                  onClick={() => { setDestination(''); setDestObj(null); setDirectionsResponse(null); }}
                                  className="absolute right-0 text-white/30 hover:text-white transition-colors"
                                >
                                  <X size={14} />
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                      {/* Phase 4: Multiple Stops Button Mode */}
                      <button
                        onClick={() => {
                          if (extraStops.length < 3) {
                            setExtraStops([...extraStops, { id: Math.random().toString(), address: '', obj: null }]);
                          } else {
                            alert("Máximo de 3 paradas extras atingido.");
                          }
                        }}
                        className="text-[10px] text-blue-400 font-medium ml-12 flex items-center gap-1 mt-2 hover:text-blue-300 transition-colors"
                      >
                        <Map size={12} />
                        Adicionar parada extra
                      </button>

                    </motion.div>
                  ) : (
                    <motion.div
                      key="summary"
                      initial={{ opacity: 0, height: 0, y: -20 }}
                      animate={{ opacity: 1, height: 'auto', y: 0 }}
                      exit={{ opacity: 0, height: 0, y: -20 }}
                      className="flex items-center justify-between bg-white/5 p-4 rounded-2xl border border-white/5 cursor-pointer hover:bg-white/10 transition-colors overflow-hidden"
                      onClick={() => setDirectionsResponse(null)}
                    >
                      <div className="flex flex-col gap-2 overflow-hidden">
                        <div className="flex items-center gap-3 text-sm text-white/70 truncate">
                          <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)] shrink-0"></div>
                          <span className="truncate">{originObj?.address || origin}</span>
                        </div>
                        <div className="flex items-center gap-3 text-sm font-medium truncate">
                          <div className="w-2 h-2 rounded-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)] shrink-0"></div>
                          <span className="truncate">{destObj?.address || destination}</span>
                        </div>
                      </div>
                      <div className="text-xs text-blue-400 font-medium shrink-0 ml-4 bg-blue-500/10 px-3 py-1.5 rounded-full">Editar</div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Categories are now in the bottom sheet */}

                {/* Payment moved to post-request flow */}

                <button
                  onClick={() => setShowVehicleOptions(true)}
                  disabled={!originObj || !destObj}
                  className="w-full bg-blue-600 text-white py-4 rounded-2xl font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-500 transition-colors flex items-center justify-center gap-2"
                >
                  Solicitar
                  <ArrowRight size={18} />
                </button>
              </div>
            </motion.div>
          )}

          {(activeTab === 'ride' || activeRide) && activeTab !== 'ai' && (
            <motion.div
              key="ride"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="w-full pointer-events-auto relative z-[45]"
            >
              {/* Ride Status Overlay */}
              <div className="absolute top-24 inset-x-0 flex justify-center pointer-events-none">
                <div className="glass-panel px-6 py-3 rounded-full flex items-center gap-3">
                  <Navigation size={20} className="animate-pulse text-blue-400" />
                  <span className="font-medium text-sm tracking-wide uppercase">
                    {activeRide?.status === 'MATCHING' && 'Procurando Motorista'}
                    {activeRide?.status === 'NEGOTIATING' && 'Contraproposta Recebida'}
                    {activeRide?.status === 'DRIVER_ASSIGNED' && 'Motorista a Caminho'}
                    {activeRide?.status === 'DRIVER_ARRIVING' && 'Motorista Chegando'}
                    {activeRide?.status === 'IN_PROGRESS' && 'Em Viagem'}
                    {activeRide?.status === 'COMPLETED' && 'Chegou ao Destino'}
                  </span>
                </div>
              </div>

              {/* Ride Details Bottom Sheet */}
              <div className="glass-panel rounded-[2rem] p-6 space-y-6 border-t border-white/10 pointer-events-auto touch-manipulation">
                {activeRide?.status === 'WAITING_PAYMENT' ? (
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          if (!activeRide) return;
                          setShowVehicleOptions(false);
                          void updateRideStatus(activeRide.id, 'CANCELLED');
                          setActiveTab('home');
                          setDirectionsResponse(null);
                        }}
                        className="shrink-0 mt-0.5 flex items-center gap-2 px-3 py-2 rounded-xl border border-white/15 bg-white/5 text-sm text-white/90 hover:bg-white/10 transition-colors z-[1]"
                      >
                        <ArrowLeft size={18} />
                        Voltar
                      </button>
                      <div className="min-w-0 flex-1">
                        <h3 className="text-xl font-bold">1. Pagamento da corrida</h3>
                        <p className="text-xs text-white/70 mt-1">Sua solicitação foi salva. Confirme o pagamento para iniciarmos a busca por motorista.</p>
                      </div>
                    </div>
                    {(() => {
                      const totalDue = Number(activeRide.finalPrice ?? activeRide.offeredPrice ?? 0);
                      const walletBal = Number(currentUser?.walletBalance ?? 0);
                      const isTerminal = Boolean(activeRide.isTerminalRide);
                      const maxCashback = !isTerminal ? Math.min(walletBal, totalDue) : 0;
                      const cashbackApplied =
                        !isTerminal && applyWalletCashback ? maxCashback : 0;
                      const remainder = Math.round((totalDue - cashbackApplied) * 100) / 100;
                      const remainderMethods = ['Pix', 'Crédito', 'Débito', 'Dinheiro'] as const;

                      return (
                        <>
                          <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-2 text-sm">
                            <div className="flex justify-between text-white/80">
                              <span>Valor da corrida</span>
                              <span className="font-mono font-medium">
                                R$ {totalDue.toFixed(2).replace('.', ',')}
                              </span>
                            </div>
                            {!isTerminal && walletBal > 0 && (
                              <>
                                <label className="flex items-center gap-2 text-xs text-emerald-300/90 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={applyWalletCashback}
                                    onChange={(e) => setApplyWalletCashback(e.target.checked)}
                                    className="rounded border-emerald-500/50"
                                  />
                                  Abater cashback da carteira (até R$ {maxCashback.toFixed(2).replace('.', ',')})
                                </label>
                                {applyWalletCashback && (
                                  <div className="flex justify-between text-emerald-400 text-xs pt-1 border-t border-white/10">
                                    <span>Cashback abatido</span>
                                    <span className="font-mono">
                                      −R$ {cashbackApplied.toFixed(2).replace('.', ',')}
                                    </span>
                                  </div>
                                )}
                              </>
                            )}
                            {isTerminal && (
                              <p className="text-[10px] text-amber-400/90 pt-1 border-t border-white/10">
                                Corrida de terminal: desconto de 15% aplicado. Cashback não pode ser usado nesta viagem.
                              </p>
                            )}
                            <div className="flex justify-between font-bold text-white pt-1 border-t border-white/10">
                              <span>Restante a pagar</span>
                              <span className="font-mono text-emerald-400">
                                R$ {remainder.toFixed(2).replace('.', ',')}
                              </span>
                            </div>
                          </div>

                          {remainder > 0 && (
                            <div className="bg-white/5 border border-white/10 rounded-xl p-3">
                              <p className="text-[10px] uppercase tracking-widest text-white/40 mb-2">
                                Forma de pagamento do restante
                              </p>
                              <div className="grid grid-cols-2 gap-2">
                                {remainderMethods.map((method) => (
                                  <button
                                    key={method}
                                    type="button"
                                    onClick={() => setRemainderPaymentMethod(method)}
                                    className={`py-3 px-3 rounded-lg border text-sm font-medium transition-colors ${
                                      remainderPaymentMethod === method
                                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                                        : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
                                    }`}
                                  >
                                    {method}
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}

                          {remainder <= 0 && !isTerminal && cashbackApplied > 0 && (
                            <p className="text-xs text-center text-emerald-400/90">
                              Pagamento total coberto pelo seu cashback.
                            </p>
                          )}

                          <button
                            type="button"
                            onClick={async () => {
                              await confirmRidePayment(activeRide.id, {
                                cashbackApplied,
                                remainderMethod:
                                  remainder > 0 ? remainderPaymentMethod : 'Saldo',
                              });
                            }}
                            className="w-full py-4 rounded-xl shadow-lg shadow-emerald-500/20 bg-emerald-600 font-bold text-white hover:bg-emerald-500 transition-all uppercase tracking-wider text-sm"
                          >
                            Confirmar e Localizar Motorista
                          </button>
                        </>
                      );
                    })()}
                  </div>
                ) : activeRide?.status === 'NEGOTIATING' && activeRide.lastOfferBy === 'DRIVER' ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 text-yellow-400 mb-2">
                      <ShieldAlert size={24} />
                      <h3 className="text-xl font-bold">Contraproposta</h3>
                    </div>
                    <p className="text-sm text-white/70">Um motorista propôs um novo valor para a corrida.</p>
                    <div className="text-4xl font-bold my-4">R$ {activeRide.offeredPrice.toFixed(2).replace('.', ',')}</div>
                    <div className="flex gap-3">
                      <button onClick={handleCancelRide} className="flex-1 py-4 rounded-2xl bg-white/10 font-medium hover:bg-white/20 transition-colors">Recusar</button>
                      <button onClick={() => updateRideStatus(activeRide.id, 'DRIVER_ASSIGNED')} className="flex-1 py-4 rounded-2xl bg-blue-600 font-medium hover:bg-blue-500 transition-colors">Aceitar</button>
                    </div>
                  </div>
                ) : activeRide?.status === 'DRIVER_ARRIVING' ? (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        {(() => {
                           const assignedDriver = activeRide.driverId ? drivers.find(d => d.id === activeRide.driverId) : null;
                           const dName = assignedDriver?.name || 'Motorista';
                           const dCar = assignedDriver?.vehicle ? `${assignedDriver.vehicle.model} ${assignedDriver.vehicle.color}` : 'Em processamento';
                           const dPlate = assignedDriver?.vehicle?.plate || 'AGUARDE';
                           const dRating = '4.9 ★'; // Mocked rating
                           return (
                             <>
                               <h3 className="text-xl font-light tracking-tight">{dName} ({dCar})</h3>
                               <p className="text-xs text-white/50 font-mono mt-1 uppercase tracking-widest">{dPlate} • {dRating}</p>
                             </>
                           );
                        })()}
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-medium">R$ {activeRide?.offeredPrice?.toFixed(2) || activeRide?.estimatedPrice.toFixed(2)}</div>
                      </div>
                    </div>

                    {/* Fase 2: Verificação de Segurança */}
                    <div className="bg-blue-500/10 border border-blue-500/30 p-4 rounded-2xl flex flex-col items-center gap-3">
                      <div className="flex items-center gap-2 text-blue-400 mb-1">
                        <ShieldCheck size={20} />
                        <span className="font-semibold text-sm">Verifique o Veículo</span>
                      </div>
                      <p className="text-xs text-white/70 text-center">
                        Antes de entrar, certifique-se da identidade do motorista.
                      </p>
                    </div>

                    {/* Botão Estou Pronto */}
                    <div className="bg-orange-500/10 border border-orange-500/30 p-4 rounded-2xl flex flex-col items-center gap-3">
                      <div className="flex items-center gap-2 text-orange-400">
                        <Timer size={20} className="animate-pulse" />
                        <span className="font-mono text-xl font-bold">03:00</span>
                      </div>
                      <p className="text-xs text-white/50 text-center">O motorista chegou. O tempo de tolerância é de 3 minutos antes da taxa extra.</p>
                      <button
                        onClick={() => setIsReady(true)}
                        disabled={isReady}
                        className={`w-full py-3 rounded-xl font-medium transition-colors ${isReady ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-orange-500 text-black hover:bg-orange-400'}`}
                      >
                        {isReady ? 'Motorista Notificado' : 'Estou Pronto e Visível'}
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex justify-between items-center">
                      <div>
                        {(() => {
                          const assignedDriver = activeRide?.driverId ? drivers.find(d => d.id === activeRide.driverId) : null;
                          if (!assignedDriver || activeRide?.status === 'MATCHING') {
                            return (
                              <>
                                <h3 className="text-xl font-light tracking-tight">Buscando motorista...</h3>
                                <p className="text-xs text-white/50 font-mono mt-1 uppercase tracking-widest">Aguarde um instante</p>
                              </>
                            );
                          }
                          const dName = assignedDriver.name;
                          const dCar = assignedDriver.vehicle ? `${assignedDriver.vehicle.model} ${assignedDriver.vehicle.color}` : '';
                          const dPlate = assignedDriver.vehicle?.plate || '';
                          return (
                            <>
                              <h3 className="text-xl font-light tracking-tight">{dName} {dCar ? `(${dCar})` : ''}</h3>
                              <p className="text-xs text-white/50 font-mono mt-1 uppercase tracking-widest">{dPlate} • 4.9 ★</p>
                            </>
                          );
                        })()}
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-medium">R$ {activeRide?.offeredPrice?.toFixed(2) || activeRide?.estimatedPrice?.toFixed(2)}</div>
                        <div className="text-xs text-white/50 font-mono mt-1 text-emerald-400 font-bold">
                          {(() => {
                            if (!activeRide) return null;
                            if (activeRide.status === 'MATCHING') return `~${activeRide.estimatedTime} MIN PRO DESTINO`;
                            const assignedDriver = activeRide.driverId ? drivers.find(d => d.id === activeRide.driverId) : null;
                            if (!assignedDriver || !assignedDriver.location) return 'ETA INDISPONÍVEL';
                            
                            // Fase 5 ETA UX
                            let dist = getDistanceKM(assignedDriver.location.lat, assignedDriver.location.lng, activeRide.origin.lat, activeRide.origin.lng);
                            if (['IN_PROGRESS'].includes(activeRide.status)) {
                              dist = getDistanceKM(assignedDriver.location.lat, assignedDriver.location.lng, activeRide.destination.lat, activeRide.destination.lng);
                            }
                            
                            let timeObjMin = Math.max(1, Math.ceil((dist / 30) * 60)); // Assumes 30 KMH
                            return `ETA: ${timeObjMin} MIN`;
                          })()}
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2 sm:gap-3">
                      {['IN_PROGRESS'].includes(activeRide?.status || '') && (
                        <button
                          onClick={() => {
                            alert("🚨 EMERGÊNCIA INVIAGEM: Alerta enviado para Polícia e Contatos. Sua localização em TEMPO REAL (Manaus) está sendo transmitida.");
                          }}
                          className="w-9 h-9 sm:w-10 sm:h-10 bg-red-600/20 border border-red-500 text-red-500 rounded-xl flex items-center justify-center hover:bg-red-600/30 transition-colors animate-pulse relative shrink-0"
                        >
                          <AlertOctagon size={18} />
                        </button>
                      )}

                      <button
                        onClick={() => setShowChat(true)}
                        className="w-12 h-12 sm:w-14 sm:h-14 bg-white/5 border border-white/10 text-white/80 rounded-2xl flex items-center justify-center hover:bg-white/10 transition-colors relative shrink-0"
                      >
                        <MessageSquare size={20} />
                        {activeRide?.messages && activeRide.messages.length > 0 && activeRide.messages[activeRide.messages.length - 1].senderId !== currentUser?.id && (
                          <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse border-2 border-[#1a1a1a]"></span>
                        )}
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm("ACIONAR EMERGÊNCIA: Isso ativará a central de segurança. Deseja continuar?")) {
                            alert("Emergência acionada. Redirecionando para as autoridades e gravando áudio do veículo.");
                          }
                        }}
                        className="w-9 h-9 sm:w-10 sm:h-10 bg-red-500/10 border border-red-500/30 text-red-500 rounded-xl flex items-center justify-center hover:bg-red-500/20 transition-colors shrink-0"
                        title="Acionar Pânico / Emergência"
                      >
                        <ShieldAlert size={16} />
                      </button>
                      <button
                        onClick={() => alert("Link de acompanhamento gerado! (Simulação: Link copiado)")}
                        className="w-12 h-12 sm:w-14 sm:h-14 bg-blue-500/10 border border-blue-500/30 text-blue-400 rounded-2xl flex items-center justify-center hover:bg-blue-500/20 transition-colors shrink-0"
                        title="Compartilhar Rota"
                      >
                        <Share2 size={20} />
                      </button>
                      {activeRide?.status === 'COMPLETED' ? (
                        <button onClick={handlePay} className="flex-1 bg-white text-black py-0 rounded-2xl font-medium flex items-center justify-center gap-2 hover:bg-neutral-200 transition-colors text-sm sm:text-base">
                          <CreditCard size={18} />
                          Pagar
                        </button>
                      ) : (
                        <button onClick={handleCancelRide} className="flex-1 bg-white/5 border border-white/10 text-white/80 hover:text-white py-0 rounded-2xl font-medium hover:bg-white/10 transition-colors text-sm sm:text-base">
                          Cancelar
                        </button>
                      )}
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="glass-panel rounded-[2rem] h-[65vh] flex flex-col pointer-events-auto border border-white/10 overflow-hidden"
            >
              <div className="p-6 border-b border-white/10 flex items-center justify-between">
                <h2 className="text-xl font-bold font-sans">Últimas Viagens</h2>
                <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-white/50">
                  <Clock size={16} />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-4">
                {/* Historico Exemplo 1 */}
                <div className="bg-white/5 rounded-2xl p-4 border border-white/10 hover:bg-white/10 transition-colors">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                        <CheckCircle2 size={14} />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-white">Finalizada</div>
                        <div className="text-[10px] text-white/50">Hoje, 14:30</div>
                      </div>
                    </div>
                    <div className="text-sm font-bold text-white">R$ 35,40</div>
                  </div>
                  <div className="space-y-2 relative ml-3 border-l-2 border-white/10 pl-4 py-1">
                    <div className="absolute -left-[5px] top-1.5 w-2 h-2 rounded-full bg-white"></div>
                    <div className="absolute -left-[5px] bottom-1.5 w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]"></div>
                    <div className="text-xs text-white/70 truncate">Casa</div>
                    <div className="text-xs font-medium text-white truncate">Shopping Paulista</div>
                  </div>
                  <button onClick={() => {
                    setActiveTab('home');
                    const newDest = { lat: -23.56, lng: -46.65, address: 'Shopping Paulista' };
                    setDestination('Shopping Paulista'); setDestObj(newDest);
                    if (originObj) calculateRoute(originObj, newDest);
                  }} className="w-full mt-4 py-2 rounded-xl bg-white/5 text-[11px] font-bold uppercase tracking-wider text-white hover:bg-white/10 transition-colors">
                    Pedir Novamente
                  </button>
                </div>

                {/* Historico Exemplo 2 */}
                <div className="bg-white/5 rounded-2xl p-4 border border-white/10 hover:bg-white/10 transition-colors">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                        <CheckCircle2 size={14} />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-white">Finalizada</div>
                        <div className="text-[10px] text-white/50">Ontem, 09:15</div>
                      </div>
                    </div>
                    <div className="text-sm font-bold text-white">R$ 42,90</div>
                  </div>
                  <div className="space-y-2 relative ml-3 border-l-2 border-white/10 pl-4 py-1">
                    <div className="absolute -left-[5px] top-1.5 w-2 h-2 rounded-full bg-white"></div>
                    <div className="absolute -left-[5px] bottom-1.5 w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]"></div>
                    <div className="text-xs text-white/70 truncate">Trabalho</div>
                    <div className="text-xs font-medium text-white truncate">Aeroporto de Congonhas</div>
                  </div>
                  <button onClick={() => {
                    setActiveTab('home');
                    const newDest = { lat: -23.58, lng: -46.68, address: 'Aeroporto de Congonhas' };
                    setDestination('Aeroporto de Congonhas'); setDestObj(newDest);
                    if (originObj) calculateRoute(originObj, newDest);
                  }} className="w-full mt-4 py-2 rounded-xl bg-white/5 text-[11px] font-bold uppercase tracking-wider text-white hover:bg-white/10 transition-colors">
                    Pedir Novamente
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'ai' && (
            <motion.div
              key="ai"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-panel rounded-[2rem] h-[70vh] flex flex-col overflow-hidden border border-purple-500/20 pointer-events-auto"
            >
              <div className="p-5 border-b border-white/10 flex items-center justify-between bg-purple-500/5">
                <div className="flex items-center gap-4">
                  <button onClick={() => setActiveTab('home')} className="text-white/50 hover:text-white transition-colors">←</button>
                  <h2 className="font-medium tracking-wide">Inviagem Concierge</h2>
                </div>
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              </div>

              <AIConciergeContent onSelectLocation={handleSelectLocationFromAI} userLocation={originObj} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Passenger Profile UI */}
      {activeTab === 'profile' && !activeRide && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="absolute inset-x-6 top-16 bottom-24 z-20 pointer-events-auto"
        >
          <div className="bg-[#111] border border-white/10 rounded-[2rem] p-6 shadow-2xl h-full flex flex-col overflow-y-auto custom-scrollbar">
            <h2 className="text-xl font-bold mb-4 shrink-0">Meu Perfil</h2>
            
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center border border-emerald-500/50 text-2xl font-bold text-emerald-400 shrink-0">
                {currentUser?.name?.charAt(0) || 'P'}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg">{currentUser?.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <Star size={14} className="text-yellow-400 fill-yellow-400" />
                  <span className="text-sm font-bold">4.92</span>
                  <span className="text-xs text-white/50">(128 avaliações)</span>
                </div>
              </div>
            </div>

            <div className="glass-panel p-5 rounded-2xl flex flex-col gap-2 border border-white/5 mb-4 shrink-0">
              <button
                type="button"
                className="flex items-center justify-between w-full text-left hover:bg-white/5 rounded-xl -m-1 p-1"
                onClick={() => setIsProfileInfoOpen(!isProfileInfoOpen)}
              >
                <div className="flex items-center gap-4">
                  <UserIcon size={20} className="text-emerald-400" />
                  <div>
                    <p className="font-medium text-sm">Informações</p>
                    <p className="text-xs text-white/40 mt-1">Dados cadastrais</p>
                  </div>
                </div>
                {isProfileInfoOpen ? <ChevronUp size={16} className="text-white/30" /> : <ChevronDown size={16} className="text-white/30" />}
              </button>
              {isProfileInfoOpen && (
                <div className="mt-2 pt-4 border-t border-white/10 space-y-3 text-sm">
                  <div className="bg-black/20 p-3 rounded-xl border border-white/5">
                    <div className="text-[10px] text-white/40 uppercase tracking-widest mb-1">Nome completo</div>
                    <div className="font-medium">{(currentUser as Passenger)?.name}</div>
                  </div>
                  <div className="bg-black/20 p-3 rounded-xl border border-white/5">
                    <div className="text-[10px] text-white/40 uppercase tracking-widest mb-1">CPF</div>
                    <div className="font-mono text-white/90">{(currentUser as Passenger)?.cpf || '—'}</div>
                  </div>
                  <div className="bg-black/20 p-3 rounded-xl border border-white/5">
                    <div className="text-[10px] text-white/40 uppercase tracking-widest mb-1">Gênero</div>
                    <div className="font-medium">
                      {(currentUser as Passenger)?.gender === 'FEMALE'
                        ? 'Feminino'
                        : (currentUser as Passenger)?.gender === 'MALE'
                          ? 'Masculino'
                          : (currentUser as Passenger)?.gender === 'OTHER'
                            ? 'Outro'
                            : '—'}
                    </div>
                  </div>
                  <div className="bg-black/20 p-3 rounded-xl border border-white/5">
                    <label className="text-[10px] text-white/40 uppercase tracking-widest mb-1 block">E-mail</label>
                    <input
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      type="email"
                      className="w-full bg-transparent outline-none font-medium text-white placeholder:text-white/30"
                      placeholder="seu@email.com"
                    />
                  </div>
                  <div className="bg-black/20 p-3 rounded-xl border border-white/5">
                    <label className="text-[10px] text-white/40 uppercase tracking-widest mb-1 block">Telefone</label>
                    <input
                      value={profilePhone}
                      onChange={(e) => setProfilePhone(e.target.value)}
                      type="tel"
                      className="w-full bg-transparent outline-none font-medium text-white placeholder:text-white/30"
                      placeholder="(92) 90000-0000"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const pass = currentUser as Passenger;
                      const email = profileEmail.trim();
                      const phone = profilePhone.replace(/\D/g, '');
                      setCurrentUser({ ...pass, email: email || undefined, phone: phone || undefined });
                      void supabase
                        .from('passengers')
                        .update({ email: email || null, phone: phone || null })
                        .eq('id', pass.id);
                    }}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 rounded-xl text-xs font-bold uppercase tracking-widest text-white transition-colors"
                  >
                    Salvar e-mail e telefone
                  </button>
                </div>
              )}
            </div>

            <div className="glass-panel p-5 rounded-2xl flex items-center gap-4 border border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20 transition-colors cursor-pointer mb-4">
              <div className="bg-emerald-500/20 p-3 rounded-full text-emerald-400">
                <DollarSign size={24} />
              </div>
              <div className="flex-1">
                <p className="font-medium text-sm text-emerald-100">Saldo de Cashback</p>
                <div className="flex items-end gap-2">
                  <p className="text-2xl font-bold text-emerald-400">
                    R$ {(currentUser.walletBalance || 0).toFixed(2).replace('.', ',')}
                  </p>
                </div>
                {(() => {
                   const lastRb = rides.filter(r => r.passengerId === currentUser?.id && r.status === 'PAID' && (r.cashbackGenerated || 0) > 0).sort((a,b) => b.updatedAt.getTime() - a.updatedAt.getTime())[0];
                   if (lastRb && lastRb.cashbackGenerated) {
                     return <p className="text-[10px] text-emerald-500/80 mt-1 uppercase tracking-widest font-bold">+R$ {lastRb.cashbackGenerated.toFixed(2).replace('.',',')} na última viagem</p>
                   }
                   return null;
                })()}
              </div>
            </div>

            <div className="space-y-4">
              <div className="glass-panel p-5 rounded-2xl flex flex-col gap-2 border border-white/5">
                <button
                  type="button"
                  className="flex items-center justify-between w-full text-left hover:bg-white/5 rounded-xl -m-1 p-1"
                  onClick={() => setIsPaymentMethodsOpen(!isPaymentMethodsOpen)}
                >
                  <div className="flex items-center gap-4">
                    <CreditCard size={20} className="text-blue-400" />
                    <div className="flex-1">
                      <p className="font-medium text-sm">Métodos de Pagamento</p>
                      <p className="text-xs text-white/40 mt-1">
                        {((currentUser as Passenger)?.savedPaymentMethods || []).length > 0
                          ? `${((currentUser as Passenger)?.savedPaymentMethods || []).length} cartão(ões)`
                          : 'Cadastre cartão débito ou crédito'}
                      </p>
                    </div>
                  </div>
                  {isPaymentMethodsOpen ? <ChevronUp size={16} className="text-white/30" /> : <ChevronDown size={16} className="text-white/30" />}
                </button>
                {isPaymentMethodsOpen && (
                  <div className="mt-2 pt-4 border-t border-white/10 space-y-3" onClick={(e) => e.stopPropagation()}>
                    {((currentUser as Passenger)?.savedPaymentMethods || []).map((c) => (
                      <div
                        key={c.id}
                        className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm"
                      >
                        <div>
                          <div className="text-blue-400 font-bold text-xs uppercase">
                            {c.modality === 'DEBIT' ? 'Débito' : 'Crédito'} ·••• {c.last4}
                            {c.expiry ? <span className="text-white/50 font-mono normal-case"> · val. {c.expiry}</span> : null}
                          </div>
                          {(c.cardNickname || c.holderLabel) && (
                            <div className="text-[10px] text-white/45 mt-0.5">{c.cardNickname || c.holderLabel}</div>
                          )}
                          {c.isDefault && (
                            <span className="text-[10px] text-emerald-400/90 uppercase tracking-widest">Principal</span>
                          )}
                        </div>
                        <button
                          type="button"
                          className="text-[10px] text-white/50 hover:text-white uppercase font-bold"
                          onClick={() => {
                            const pass = currentUser as Passenger;
                            const list = (pass.savedPaymentMethods || []).map((x) => ({
                              ...x,
                              isDefault: x.id === c.id,
                            }));
                            setCurrentUser({ ...pass, savedPaymentMethods: list });
                            void supabase.from('passengers').update({ saved_payment_methods: list }).eq('id', pass.id);
                          }}
                        >
                          Principal
                        </button>
                      </div>
                    ))}
                    <div className="space-y-2">
                      <p className="text-[10px] text-white/40 uppercase tracking-widest">Novo cartão</p>
                      <p className="text-[9px] text-white/35 leading-relaxed">
                        Digite os 16 dígitos. Por segurança (PCI), só os últimos 4 e a validade ficam salvos; o CVV não é armazenado.
                      </p>
                      <input
                        value={newCardNickname}
                        onChange={(e) => setNewCardNickname(e.target.value)}
                        placeholder="Apelido do cartão (ex.: Nubank trabalho)"
                        className="w-full text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder:text-white/30"
                      />
                      <input
                        value={newCardHolder}
                        onChange={(e) => setNewCardHolder(e.target.value)}
                        placeholder="Nome impresso no cartão"
                        className="w-full text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder:text-white/30"
                      />
                      <input
                        value={newCardNumber}
                        onChange={(e) => setNewCardNumber(e.target.value.replace(/\D/g, '').slice(0, 16))}
                        placeholder="Número do cartão (16 dígitos)"
                        inputMode="numeric"
                        autoComplete="cc-number"
                        className="w-full text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder:text-white/30 font-mono tracking-wider"
                      />
                      <div className="flex gap-2">
                        <input
                          value={newCardExpiry}
                          onChange={(e) => {
                            const d = e.target.value.replace(/\D/g, '').slice(0, 4);
                            setNewCardExpiry(d.length >= 3 ? `${d.slice(0, 2)}/${d.slice(2)}` : d);
                          }}
                          placeholder="MM/AA"
                          inputMode="numeric"
                          className="flex-1 text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder:text-white/30 font-mono"
                        />
                        <input
                          value={newCardCvv}
                          onChange={(e) => setNewCardCvv(e.target.value.replace(/\D/g, '').slice(0, 4))}
                          placeholder="CVV"
                          inputMode="numeric"
                          autoComplete="cc-csc"
                          className="w-24 text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder:text-white/30 font-mono"
                        />
                      </div>
                      <select
                        value={newCardModality}
                        onChange={(e) => setNewCardModality(e.target.value as 'DEBIT' | 'CREDIT')}
                        className="w-full text-xs bg-zinc-800 text-white border border-white/10 rounded-xl px-3 py-2.5"
                      >
                        <option value="CREDIT">Crédito</option>
                        <option value="DEBIT">Débito</option>
                      </select>
                      <button
                        type="button"
                        className="w-full py-2.5 bg-blue-600 rounded-xl text-xs font-bold uppercase text-white hover:bg-blue-500"
                        onClick={() => {
                          const digits = newCardNumber.replace(/\D/g, '');
                          if (digits.length !== 16) {
                            alert('Informe os 16 dígitos do número do cartão.');
                            return;
                          }
                          const exp = newCardExpiry.replace(/\D/g, '');
                          if (exp.length !== 4) {
                            alert('Informe a validade no formato MM/AA.');
                            return;
                          }
                          const cvv = newCardCvv.replace(/\D/g, '');
                          if (cvv.length < 3) {
                            alert('Informe o CVV (3 ou 4 dígitos) para validar; ele não será salvo.');
                            return;
                          }
                          const pass = currentUser as Passenger;
                          const prev = pass.savedPaymentMethods || [];
                          const id = `pm_${Date.now()}`;
                          const last4 = digits.slice(-4);
                          const next: PassengerSavedCard[] = [
                            ...prev.map((x) => ({ ...x, isDefault: false })),
                            {
                              id,
                              last4,
                              holderLabel: newCardHolder.trim() || undefined,
                              cardNickname: newCardNickname.trim() || undefined,
                              expiry: newCardExpiry.trim(),
                              modality: newCardModality,
                              isDefault: prev.length === 0,
                            },
                          ];
                          setCurrentUser({ ...pass, savedPaymentMethods: next });
                          setNewCardNumber('');
                          setNewCardCvv('');
                          setNewCardExpiry('');
                          setNewCardHolder('');
                          setNewCardNickname('');
                          void supabase.from('passengers').update({ saved_payment_methods: next }).eq('id', pass.id);
                        }}
                      >
                        Adicionar cartão
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <div className="glass-panel p-5 rounded-2xl flex flex-col gap-3 border border-white/5 transition-colors cursor-pointer" onClick={() => setIsEditingPlaces(!isEditingPlaces)}>
                <div className="flex items-center justify-between hover:bg-white/5">
                  <div className="flex items-center gap-4">
                    <MapPin size={20} className="text-emerald-400" />
                    <div className="flex-1">
                      <p className="font-medium text-sm">Locais Salvos</p>
                      <p className="text-xs text-white/40 mt-1">{((currentUser as Passenger)?.savedPlaces || []).length > 0 ? ((currentUser as Passenger)?.savedPlaces || []).map(p => p.title).join(', ') : 'Ex: Casa, Trabalho'}</p>
                    </div>
                  </div>
                  {isEditingPlaces ? <ChevronUp size={16} className="text-white/30" /> : <ChevronDown size={16} className="text-white/30" />}
                </div>
                {isEditingPlaces && (
                  <div className="mt-2 pt-4 border-t border-white/10 space-y-3 cursor-default" onClick={(e) => e.stopPropagation()}>
                    {((currentUser as Passenger)?.savedPlaces || []).map((p, i) => (
                       <div key={i} className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                         <div>
                           <div className="text-emerald-400 font-bold text-xs uppercase tracking-widest">{p.title}</div>
                           <div className="text-white/50 text-xs truncate max-w-[200px] mt-0.5">{p.address}</div>
                         </div>
                         <button onClick={(e) => {
                             e.stopPropagation();
                             const pass = currentUser as Passenger;
                             const curr = pass.savedPlaces || [];
                             const newPlaces = curr.filter((_, idx) => idx !== i);
                             setCurrentUser({ ...pass, savedPlaces: newPlaces });
                             supabase.from('passengers').update({ saved_places: newPlaces }).eq('id', pass.id).then();
                         }} className="text-red-400 hover:text-red-300 p-2"><X size={16}/></button>
                       </div>
                    ))}
                    <div className="space-y-2 mt-2">
                      <p className="text-[10px] text-white/40 uppercase tracking-widest">Adicionar local</p>
                      <input
                        value={newSavedPlaceTitle}
                        onChange={(e) => setNewSavedPlaceTitle(e.target.value)}
                        placeholder="Nome (ex.: Casa, Trabalho, Academia)"
                        className="w-full text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-3 placeholder:text-white/30 text-white focus:outline-none focus:border-emerald-500/50"
                      />
                      {isLoaded ? (
                        <Autocomplete
                          options={autocompleteOptions}
                          onLoad={(ac) => {
                            savedPlaceAddressAutocompleteRef.current = ac;
                          }}
                          onPlaceChanged={() => {
                            const ac = savedPlaceAddressAutocompleteRef.current;
                            const place = ac?.getPlace();
                            if (!place?.geometry?.location) {
                              triggerError?.('Toque em uma sugestão da lista para fixar o endereço no mapa.');
                              return;
                            }
                            const loc: Location = {
                              lat: place.geometry.location.lat(),
                              lng: place.geometry.location.lng(),
                              address: place.formatted_address || place.name || '',
                            };
                            setNewSavedPlaceObj(loc);
                            setNewSavedPlaceAddress(loc.address);
                          }}
                        >
                          <input
                            value={newSavedPlaceAddress}
                            onChange={(e) => {
                              setNewSavedPlaceAddress(e.target.value);
                              setNewSavedPlaceObj(null);
                            }}
                            onBlur={() => {
                              const addr = newSavedPlaceAddress.trim();
                              if (!addr || !window.google) return;
                              if (newSavedPlaceObj && Number.isFinite(newSavedPlaceObj.lat)) return;
                              const geocoder = new window.google.maps.Geocoder();
                              const query = addr.toLowerCase().includes('manaus') ? addr : `${addr}, Manaus, AM, Brasil`;
                              geocoder.geocode({ address: query, region: 'br' }, (results, status) => {
                                if (status !== 'OK' || !results?.[0]?.geometry?.location) return;
                                const g = results[0].geometry.location;
                                const formatted = results[0].formatted_address || addr;
                                setNewSavedPlaceObj({
                                  lat: g.lat(),
                                  lng: g.lng(),
                                  address: formatted,
                                });
                                setNewSavedPlaceAddress(formatted);
                              });
                            }}
                            placeholder="Busque o endereço e escolha na lista do Google"
                            className="w-full text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-3 placeholder:text-white/30 text-white focus:outline-none focus:border-emerald-500/50"
                          />
                        </Autocomplete>
                      ) : (
                        <input
                          value={newSavedPlaceAddress}
                          onChange={(e) => {
                            setNewSavedPlaceAddress(e.target.value);
                            setNewSavedPlaceObj(null);
                          }}
                          placeholder="Carregando mapa…"
                          disabled
                          className="w-full text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-3 placeholder:text-white/30 text-white/50"
                        />
                      )}
                      <p className="text-[10px] text-white/35 leading-relaxed">
                        O nome é só para você lembrar; o ponto no mapa vem do endereço confirmado nas sugestões.
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          const title = newSavedPlaceTitle.trim();
                          if (!title) {
                            triggerError('Digite um nome para o local.');
                            return;
                          }
                          const pass = currentUser as Passenger;
                          const curr = pass.savedPlaces || [];
                          const applyOne = (lat: number, lng: number, addr: string) => {
                            if (!isInManausMetropolitanArea(lat, lng)) {
                              alert(
                                'O endereço encontrado está fora da região de Manaus. Ajuste o endereço e salve novamente.'
                              );
                              return;
                            }
                            const formatted = addr;
                            if (
                              !formatted.toLowerCase().includes('manaus') &&
                              !window.confirm(
                                `Endereço encontrado:\n${formatted}\n\nConfirma que é o local correto na região de Manaus?`
                              )
                            ) {
                              return;
                            }
                            const newPlaces = [...curr, { title, address: formatted, lat, lng }];
                            setCurrentUser({ ...pass, savedPlaces: newPlaces });
                            setNewSavedPlaceTitle('');
                            setNewSavedPlaceAddress('');
                            setNewSavedPlaceObj(null);
                            savedPlacesGeocodeAttempted.current = '';
                            void supabase.from('passengers').update({ saved_places: newPlaces }).eq('id', pass.id);
                          };

                          if (newSavedPlaceObj && Number.isFinite(newSavedPlaceObj.lat) && Number.isFinite(newSavedPlaceObj.lng)) {
                            applyOne(newSavedPlaceObj.lat, newSavedPlaceObj.lng, newSavedPlaceObj.address || newSavedPlaceAddress.trim());
                            return;
                          }

                          const addrOnly = newSavedPlaceAddress.trim();
                          if (!addrOnly || !window.google) {
                            triggerError('Busque o endereço e escolha uma sugestão na lista (ou aguarde o mapa carregar).');
                            return;
                          }
                          const geocoder = new window.google.maps.Geocoder();
                          const query = addrOnly.toLowerCase().includes('manaus') ? addrOnly : `${addrOnly}, Manaus, AM, Brasil`;
                          geocoder.geocode({ address: query, region: 'br' }, (results, status) => {
                            if (status !== 'OK' || !results?.[0]?.geometry?.location) {
                              alert(
                                'Não foi possível validar o endereço em Manaus. Inclua rua, número e bairro ou escolha uma sugestão na lista.'
                              );
                              return;
                            }
                            const loc = results[0].geometry.location;
                            const formatted = results[0].formatted_address || addrOnly;
                            applyOne(loc.lat(), loc.lng(), formatted);
                          });
                        }}
                        className="w-full bg-emerald-600 hover:bg-emerald-500 transition-colors text-white text-xs font-bold py-3 rounded-xl"
                      >
                        Confirmar e salvar local
                      </button>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="glass-panel p-5 rounded-2xl flex flex-col gap-3 border border-white/5 transition-colors cursor-pointer" onClick={() => setIsEditingEmergencyContacts(!isEditingEmergencyContacts)}>
                <div className="flex items-center justify-between hover:bg-white/5">
                  <div className="flex items-center gap-4">
                    <ShieldAlert size={20} className="text-purple-400" />
                    <div className="flex-1">
                      <p className="font-medium text-sm">Central de Segurança</p>
                      <p className="text-xs text-white/40 mt-1">{((currentUser as Passenger)?.emergencyContacts || []).length > 0 ? ((currentUser as Passenger)?.emergencyContacts || []).map(p => p.name).join(', ') : 'Contatos de emergência'}</p>
                    </div>
                  </div>
                  {isEditingEmergencyContacts ? <ChevronUp size={16} className="text-white/30" /> : <ChevronDown size={16} className="text-white/30" />}
                </div>
                {isEditingEmergencyContacts && (
                  <div className="mt-2 pt-4 border-t border-white/10 space-y-3 cursor-default" onClick={(e) => e.stopPropagation()}>
                    {((currentUser as Passenger)?.emergencyContacts || []).map((contact, i) => (
                       <div key={i} className="flex justify-between items-center bg-black/20 p-3 rounded-xl border border-white/5 text-sm">
                         <div>
                           <div className="text-purple-400 font-bold text-xs uppercase tracking-widest">{contact.name}</div>
                           <div className="text-white/50 text-xs mt-0.5">{contact.phone}</div>
                         </div>
                         <button onClick={(e) => {
                             e.stopPropagation();
                             const pass = currentUser as Passenger;
                             const curr = pass.emergencyContacts || [];
                             const newContacts = curr.filter((_, idx) => idx !== i);
                             setCurrentUser({ ...pass, emergencyContacts: newContacts });
                             supabase.from('passengers').update({ emergency_contacts: newContacts }).eq('id', pass.id).then();
                         }} className="text-red-400 hover:text-red-300 p-2"><X size={16}/></button>
                       </div>
                    ))}
                    <div className="flex flex-col gap-2 mt-2">
                       <input value={newEmergencyContactName} onChange={e=>setNewEmergencyContactName(e.target.value)} placeholder="Nome do Contato" className="w-full text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-3 placeholder:text-white/30 text-white focus:outline-none focus:border-purple-500/50" />
                       <input value={newEmergencyContactPhone} onChange={e=>setNewEmergencyContactPhone(e.target.value)} placeholder="Telefone" className="w-full text-xs bg-white/5 border border-white/10 rounded-xl px-4 py-3 placeholder:text-white/30 text-white focus:outline-none focus:border-purple-500/50" />
                       <button onClick={() => {
                          if (!newEmergencyContactName || !newEmergencyContactPhone) return;
                          const pass = currentUser as Passenger;
                          const curr = pass.emergencyContacts || [];
                          const newContacts = [...curr, { id: Date.now().toString(), name: newEmergencyContactName, phone: newEmergencyContactPhone }];
                          setCurrentUser({ ...pass, emergencyContacts: newContacts });
                          setNewEmergencyContactName('');
                          setNewEmergencyContactPhone('');
                          supabase.from('passengers').update({ emergency_contacts: newContacts }).eq('id', pass.id).then();
                       }} className="w-full bg-purple-600 hover:bg-purple-500 transition-colors text-white text-xs font-bold py-3 mt-1 rounded-xl uppercase tracking-widest">Salvar Contato</button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 shrink-0">
              <button 
                onClick={() => {
                  setCurrentUser(null);
                  router.push('/');
                }}
                className="w-full py-4 border border-red-500/20 text-red-400 font-bold uppercase tracking-widest text-xs rounded-2xl hover:bg-red-500/10 transition-colors"
                >
                Sair da Conta
              </button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Bottom Navigation */}
      {!activeRide && activeTab !== 'ai' && (
        <nav className="absolute bottom-6 inset-x-6 z-20 pointer-events-auto">
          <div className="glass-panel rounded-full flex justify-around p-2 border border-white/10">
            <button onClick={() => setActiveTab('home')} className={`flex flex-col items-center gap-1 p-3 rounded-full transition-colors ${activeTab === 'home' ? 'bg-white/10 text-white' : 'text-white/40 hover:text-white/80'}`}>
              <Search size={20} />
            </button>
            <button onClick={() => setActiveTab('history')} className={`flex flex-col items-center gap-1 p-3 rounded-full transition-colors ${activeTab === 'history' ? 'bg-white/10 text-white' : 'text-white/40 hover:text-white/80'}`}>
              <CheckCircle2 size={20} />
            </button>
            <button onClick={() => setActiveTab('profile')} className={`flex flex-col items-center gap-1 p-3 rounded-full transition-colors ${activeTab === 'profile' ? 'bg-white/10 text-white' : 'text-white/40 hover:text-white/80'}`}>
              <UserIcon size={20} />
            </button>
          </div>
        </nav>
      )}
      {/* Vehicle Options Bottom Sheet */}
      <AnimatePresence>
        {showVehicleOptions && (
          <motion.div
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            className="absolute inset-x-0 bottom-0 z-[22] max-h-[90dvh] flex flex-col bg-[#111] rounded-t-[2rem] shadow-[0_-10px_40px_rgba(0,0,0,0.5)] border-t border-white/10 pointer-events-auto overflow-hidden"
          >
            <div className="shrink-0 flex justify-between items-center px-6 pt-6 pb-4">
              <h2 className="text-xl font-bold">Escolha um veículo</h2>
              <button onClick={() => setShowVehicleOptions(false)} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/70 hover:text-white">
                &times;
              </button>
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto overscroll-y-contain px-6 pb-2 [-webkit-overflow-scrolling:touch]">
            <div className="space-y-3 mb-6 pr-1 custom-scrollbar">
              {(
                [
                  { label: 'Carro', cats: ['X', 'Comfort', 'Black', 'Carro Entrega'] as const },
                  { label: 'Moto', cats: ['Corrida Moto', 'Moto Entrega'] as const },
                ] as const
              ).map((group) => (
                <div key={group.label} className="space-y-2">
                  <div className="text-[10px] text-white/40 uppercase tracking-widest font-bold px-1">{group.label}</div>
                  {group.cats.map((cat) => {
                    const displayName = cat === 'Corrida Moto' ? 'Corrida com Moto' : cat;
                    const bPrice = getEstimatedPrice(cat);
                    const isTerminalOrigin = originObj && terminals.some(t => getDistanceKM(t.lat, t.lng, originObj.lat, originObj.lng) < 0.3);
                    const isTerminalDest = destObj && terminals.some(t => getDistanceKM(t.lat, t.lng, destObj.lat, destObj.lng) < 0.3);
                    const isTerminalRide = !!(isTerminalOrigin || isTerminalDest);

                    const desc = isTerminalRide ? bPrice * 0.15 : 0;
                    const fPrice = bPrice - desc;
                    const isMotoGroup = group.label === 'Moto';

                    return (
                      <div
                        key={cat}
                        onClick={() => {
                          setCategory(cat);
                          setCustomPrice(fPrice);
                        }}
                        className={`flex items-center justify-between p-4 rounded-2xl border cursor-pointer transition-all ${category === cat
                          ? 'bg-blue-600/20 border-blue-500'
                          : 'bg-white/5 border-white/10 hover:bg-white/10'
                          }`}
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                            {isMotoGroup ? (
                              <Navigation size={24} className={category === cat ? 'text-blue-400' : 'text-white/70'} />
                            ) : (
                              <Car size={24} className={category === cat ? 'text-blue-400' : 'text-white/70'} />
                            )}
                          </div>
                          <div>
                            <div className="font-medium text-lg">{displayName}</div>
                            <div className="text-sm text-white/50 flex flex-col">
                              <span>
                                {directionsResponse
                                  ? `${Math.ceil((directionsResponse.routes[0].legs[0].duration?.value || 0) / 60)} min`
                                  : 'Calculando...'}
                              </span>
                              {!isTerminalRide && ['X', 'Comfort', 'Black', 'Corrida Moto'].includes(cat) && (
                                <span className="text-emerald-400 text-xs">+8% Cashback</span>
                              )}
                              {!isTerminalRide && (cat === 'Moto Entrega' || cat === 'Carro Entrega') && (
                                <span className="text-white/35 text-xs">Entrega — sem cashback</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          {isTerminalRide ? (
                            <>
                              <div className="text-xs line-through text-white/40">R$ {bPrice.toFixed(2).replace('.', ',')}</div>
                              <div className="text-xl font-bold text-emerald-400 flex flex-col items-end">
                                R$ {fPrice.toFixed(2).replace('.', ',')}
                                <span className="text-[10px] bg-emerald-500/20 font-medium px-1 py-0.5 rounded mt-0.5 border border-emerald-500/30">-15% Terminal</span>
                              </div>
                            </>
                          ) : (
                            <div className="text-xl font-bold">
                              R$ {fPrice.toFixed(2).replace('.', ',')}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>

            <div className="mb-6 min-w-0">
              <div className="text-xs text-white/40 mb-3 uppercase tracking-widest font-bold">Preferências e Inclusões</div>
              <div className="flex flex-nowrap gap-2 mb-4 w-full max-w-full min-w-0 overflow-x-auto overflow-y-visible overscroll-x-contain touch-pan-x [-webkit-overflow-scrolling:touch] custom-scrollbar pb-2">
                <button
                  onClick={() => setPrefSilent(!prefSilent)}
                  className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-full border transition-colors ${prefSilent ? 'bg-purple-500/20 border-purple-500/50 text-purple-400' : 'bg-white/5 border-white/10 text-white/60'}`}
                >
                  <VolumeX size={14} /> <span className="text-xs font-medium">Viagem Silenciosa</span>
                </button>
                <button
                  onClick={() => setPrefAC(!prefAC)}
                  className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-full border transition-colors ${prefAC ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400' : 'bg-white/5 border-white/10 text-white/60'}`}
                >
                  <Wind size={14} /> <span className="text-xs font-medium">Ar Ligado</span>
                </button>
                {/* Pet Friendly Toggle */}
                <button
                  onClick={() => setRideType(rideType === 'PET' ? 'NORMAL' : 'PET')}
                  className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-full border transition-colors ${rideType === 'PET' ? 'bg-orange-500/20 border-orange-500/50 text-orange-400' : 'bg-white/5 border-white/10 text-white/60'}`}
                >
                  <span className="text-xs font-medium">Pet Friendly 🐕</span>
                </button>
                {/* Women Only — apenas passageira com gênero feminino cadastrado */}
                {(currentUser as Passenger)?.gender === 'FEMALE' && (
                  <button
                    onClick={() => setRideType(rideType === 'WOMEN_ONLY' ? 'NORMAL' : 'WOMEN_ONLY')}
                    className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-full border transition-colors ${rideType === 'WOMEN_ONLY' ? 'bg-pink-500/20 border-pink-500/50 text-pink-400' : 'bg-white/5 border-white/10 text-white/60'}`}
                  >
                    <span className="text-xs font-medium">Só Mulheres 🚺</span>
                  </button>
                )}
              </div>

              <button
                onClick={() => setIsCustomOfferEnabled(!isCustomOfferEnabled)}
                className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-colors mb-4 ${isCustomOfferEnabled ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-white/5 border-white/10 text-white/60 hover:bg-white/10'}`}
              >
                <div className="flex items-center gap-3">
                  <DollarSign size={20} />
                  <span className="font-medium">Fazer uma oferta (Opcional)</span>
                </div>
                <div className={`w-10 h-5 rounded-full relative transition-colors ${isCustomOfferEnabled ? 'bg-emerald-500' : 'bg-white/20'}`}>
                  <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${isCustomOfferEnabled ? 'right-1' : 'left-1'}`} />
                </div>
              </button>

              {isCustomOfferEnabled && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex flex-col gap-4 bg-white/5 p-4 rounded-2xl border border-white/10"
                >
                  <div className="flex justify-between items-center px-1">
                    <div className="text-sm text-white/70 font-medium">Sua oferta</div>
                    <div className="text-xs text-white/40">Base sugerida: R$ {getEstimatedPrice(category).toFixed(2).replace('.', ',')}</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <button onClick={() => setCustomPrice(p => Math.max(p - 5, 5))} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/20 transition-colors text-xs font-medium">-5</button>
                      <button onClick={() => setCustomPrice(p => Math.max(p - 1, 5))} className="w-10 h-10 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center hover:bg-blue-500/30 transition-colors text-xl font-medium">-1</button>
                    </div>
                    <div className="text-3xl font-bold flex-1 text-center text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]">
                      R$ {customPrice.toFixed(2).replace('.', ',')}
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => setCustomPrice(p => p + 1)} className="w-10 h-10 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center hover:bg-blue-500/30 transition-colors text-xl font-medium">+1</button>
                      <button onClick={() => setCustomPrice(p => p + 5)} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/20 transition-colors text-xs font-medium">+5</button>
                    </div>
                  </div>
                  {customPrice < getEstimatedPrice(category) * 0.8 && (
                    <div className="text-[10px] text-red-400 text-center uppercase tracking-wider font-semibold">Oferta baixa. Pode demorar a ser aceita.</div>
                  )}
                  {customPrice >= getEstimatedPrice(category) && (
                    <div className="text-[10px] text-emerald-400 text-center uppercase tracking-wider font-semibold">Oferta excelente! Alta chance de aceite rápido.</div>
                  )}
                </motion.div>
              )}
            </div>
            </div>

            <div className="shrink-0 px-6 pb-6 pt-3 border-t border-white/10 bg-[#111]">
            <button
              onClick={handleRequestRide}
              className="w-full bg-blue-600 text-white py-4 rounded-2xl font-medium hover:bg-blue-500 transition-colors flex items-center justify-center gap-2"
            >
              {isCustomOfferEnabled ? 'Confirmar Oferta' : 'Solicitar Viagem'}
              <ArrowRight size={18} />
            </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Phase 3: Chat Modal */}
      <AnimatePresence>
        {showChat && (
          <motion.div
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            className="absolute inset-x-0 bottom-0 z-50 bg-[#111] rounded-t-[2rem] p-6 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] border-t border-white/10 h-[75vh] flex flex-col pointer-events-auto"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2"><MessageSquare size={20} /> Mensagens</h2>
              <button onClick={() => setShowChat(false)} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/70 hover:text-white">
                <X size={16} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-3 mb-4">
              {activeRide?.messages?.map(msg => (
                <div key={msg.id} className={`max-w-[80%] p-3 rounded-2xl text-sm ${msg.senderId === currentUser?.id ? 'bg-blue-600 self-end rounded-tr-sm' : 'bg-white/10 self-start rounded-tl-sm border border-white/10'}`}>
                  {msg.text}
                </div>
              ))}
              {(!activeRide?.messages || activeRide.messages.length === 0) && (
                <div className="flex-1 flex items-center justify-center text-white/40 text-sm">Nenhuma mensagem ainda.</div>
              )}
            </div>

            <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-2 mb-2 mask-fade-edges shrink-0">
              {['Estou descendo', 'Estou na portaria', 'Aguarde 2 minutinhos', 'Vestindo camiseta preta'].map(msg => (
                <button
                  key={msg}
                  onClick={() => handleSendChat(msg)}
                  className="whitespace-nowrap bg-white/5 border border-white/10 px-3 py-2 rounded-full text-xs font-medium hover:bg-white/10 transition-colors"
                >
                  {msg}
                </button>
              ))}
            </div>

            <div className="flex gap-2 shrink-0">
              <input
                value={chatMessage}
                onChange={e => setChatMessage(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    handleSendChat(chatMessage);
                  }
                }}
                placeholder="Sua mensagem (IA Monitorada)..."
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/50 transition-colors text-sm"
              />
              <button
                onClick={() => handleSendChat(chatMessage)}
                className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center hover:bg-blue-500 transition-colors shrink-0"
              >
                <ArrowRight size={18} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Phase 3: Push / Web notifications (Mock) */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="absolute top-6 left-6 right-6 z-50 bg-[#1a1a1a] border border-white/10 rounded-2xl p-4 shadow-xl flex items-center justify-between pointer-events-auto"
          >
            <div className="flex flex-col">
              <span className="text-sm font-bold text-white mb-1">{notification.title}</span>
              <span className="text-xs text-white/70">{notification.body}</span>
            </div>
            <button onClick={() => setNotification(null)} className="text-white/40 hover:text-white shrink-0 ml-4">
              <X size={16} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}

function AIConciergeContent({ onSelectLocation, userLocation }: { onSelectLocation: (loc: string) => void, userLocation: Location | null }) {
  const { isDemoMode, setDemoMode, createRide, currentUser, sponsoredLocations, sponsors, trackAdEvent } = useStore();
  const [messages, setMessages] = useState<{ role: 'user' | 'model', content: string, locations?: any[], audioData?: string, sponsorId?: string | null }[]>([
    { role: 'model', content: 'Olá! Sou seu assistente Inviagem. Para onde vamos hoje? Posso sugerir restaurantes, parques ou eventos próximos.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(false);

  const playAudio = (base64Data: string) => {
    const audio = new Audio(`data:audio/mp3;base64,${base64Data}`);
    audio.play();
  };

  const startSimulation = () => {
    const dest = "Parque do Ibirapuera, São Paulo";
    onSelectLocation(dest);
    setMessages(prev => [...prev,
    { role: 'user', content: 'Simular uma corrida para o Ibirapuera.' },
    { role: 'model', content: 'Ótima escolha! Defini o destino como Parque do Ibirapuera. Agora, clique em "Solicitar" na tela inicial, confirme sua oferta e depois use o menu lateral para mudar para o modo "Motorista" e aceitar a corrida!' }
    ]);
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg = { role: 'user' as const, content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      let locationContext = "";
      if (userLocation) {
        locationContext = `O usuário está presencialmente em: ${userLocation.address || 'Localização Atual'} (lat: ${userLocation.lat}, lng: ${userLocation.lng}). Concentre-se nas proximidades da cidade/bairro em que ele está e seja assertivo nas buscas de arredores. `;
      } else if (navigator.geolocation) {
        try {
          const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5000 });
          });
          locationContext = `O usuário está em lat: ${pos.coords.latitude}, lng: ${pos.coords.longitude}. Mapeie a localização nas recomendações. `;
        } catch (e) {
          console.warn("Geolocation failed for AI context", e);
        }
      }

      const currentTime = new Date().toLocaleTimeString('pt-BR');
      const mockAgenda = "Voo para Paris às 22:00 saindo de Congonhas. Jantar com investidores às 20:00 no Figueira Rubaiyat.";

      const sponsoredContext = sponsoredLocations.filter(l => l.active).map(l =>
        `ID: ${l.id} | Nome: ${l.name} | Endereço: ${l.address} | Tags: ${l.tags.join(', ')} | Descrição: ${l.description}`
      ).join('\n');

      const systemInstruction = `Você é um concierge de luxo da Inviagem. 
Regra Absoluta Nº 1: É EXPRESSAMENTE PROIBIDO listar, detalhar ou escrever sobre os locais em formato de texto comum.
Sua única fala textual e verbal deve ser "Aqui estão as opções que encontrei próximo a você:".
Todas as informações e nomes de locais reais encontrados pelo Web Search DEVEM ir EXCLUSIVAMENTE dentro do bloco \`\`\`json.
Você DEVE usar a ferramenta de busca do Google para buscar locais reais na web sobre o ambiente do usuário.

Temos os seguintes locais patrocinados (Ads):
${sponsoredContext}
Se a pergunta combinar com as tags de um local patrocinado, recomende-o fortemente e inclua a tag [SPONSORED_LOCATION: ID_DO_LOCAL].

MUITO IMPORTANTE: No final da sua resposta, você DEVE incluir um bloco de código JSON contendo os detalhes exatos dos locais que você encontrou no Google Maps. O bloco JSON deve estar obrigatoriamente entre \`\`\`json e \`\`\`.
Formato do JSON:
[
  {
    "title": "Nome exato do local",
    "rating": "Nota (ex: 4.5)",
    "reviews": "Número de avaliações (ex: 152)",
    "price": "Faixa de preço (ex: $$ ou R$ 20-40)",
    "address": "Endereço curto",
    "isOpen": true,
    "closingTime": "Horário de fechamento (ex: 22:00)",
    "reviewText": "Um trecho de avaliação real ou comentário curto",
    "category": "Categoria (ex: Restaurante brasileiro, Churrascaria)"
  }
]
Não inclua o local patrocinado neste JSON, apenas os locais orgânicos encontrados no Web Search do Google.`;

      const prompt = `${locationContext}Hora atual: ${currentTime}. Agenda do usuário: ${mockAgenda}. O usuário perguntou: ${input}. Sugira locais específicos e interessantes próximos ou comente sobre a agenda se for relevante.`;

      const apiRes = await fetch('/api/gemini-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          systemInstruction,
          model: 'gemini-2.0-flash',
        }),
      });
      const apiJson = (await apiRes.json()) as { text?: string; error?: string; message?: string };

      if (!apiRes.ok) {
        const detail = apiJson.message || apiJson.error || 'Serviço de IA indisponível.';
        setMessages((prev) => [
          ...prev,
          {
            role: 'model',
            content: `Não foi possível usar o assistente: ${detail}`,
          },
        ]);
        return;
      }

      let modelText = apiJson.text || 'Desculpe, não consegui processar sua solicitação.';
      let recommendedSponsorId: string | null = null;

      const sponsorMatch = modelText.match(/\[SPONSORED_LOCATION:\s*([^\]]+)\]/);
      if (sponsorMatch) {
        recommendedSponsorId = sponsorMatch[1].trim();
        modelText = modelText.replace(sponsorMatch[0], '').trim();
      }

      let extractedLocations: any[] = [];
      const jsonMatch = modelText.match(/```json\s*([\s\S]*?)\s*```/);
      if (jsonMatch) {
        try {
          extractedLocations = JSON.parse(jsonMatch[1]);
          modelText = modelText.replace(/```json\s*([\s\S]*?)\s*```/, '').trim();
        } catch (e) {
          console.error('Failed to parse AI JSON', e);
        }
      }

      let audioData = '';

      if (isVoiceEnabled && typeof window !== 'undefined' && 'speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
          const u = new SpeechSynthesisUtterance(modelText.slice(0, 1200));
          u.lang = 'pt-BR';
          window.speechSynthesis.speak(u);
        } catch (e) {
          console.warn('speechSynthesis failed', e);
        }
      }

      setMessages((prev) => [
        ...prev,
        {
          role: 'model',
          content: modelText,
          locations: extractedLocations,
          audioData,
          sponsorId: recommendedSponsorId,
        },
      ]);

      if (recommendedSponsorId) {
        trackAdEvent(recommendedSponsorId, 'impression');
      }
    } catch (error) {
      console.error(error);
      setMessages((prev) => [
        ...prev,
        {
          role: 'model',
          content: 'Houve um erro ao processar sua solicitação. Verifique sua conexão e a chave GEMINI_API_KEY no servidor.',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-transparent">
      <div className="p-4 border-b border-white/10 flex justify-between items-center bg-black/20">
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
            <span className="text-xs font-bold uppercase tracking-widest text-white/70">Concierge Inviagem</span>
          </div>
          <div className="flex items-center gap-1 mt-1">
            <span className="text-[8px] text-white/30 uppercase tracking-tighter">Agenda Ativa: Voo Paris 22:00</span>
          </div>
        </div>
        <button
          onClick={() => setIsVoiceEnabled(!isVoiceEnabled)}
          className={`p-2 rounded-full transition-colors ${isVoiceEnabled ? 'bg-blue-600 text-white' : 'bg-white/5 text-white/40'}`}
        >
          {isVoiceEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-6 custom-scrollbar">
        {isDemoMode && (
          <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-[10px] uppercase tracking-widest font-bold text-emerald-400">Modo Demo Ativo</span>
            </div>
            <button
              onClick={startSimulation}
              className="text-[10px] bg-emerald-500 text-black px-4 py-2 rounded-full font-bold hover:bg-emerald-400 transition-all active:scale-95 shadow-[0_0_15px_rgba(16,185,129,0.4)]"
            >
              INICIAR FLUXO MANUAL
            </button>
          </div>
        )}
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-4 rounded-2xl relative group ${msg.role === 'user' ? 'bg-blue-600' : 'bg-white/5 border border-white/10'}`}>
              <p className="text-sm leading-relaxed">{msg.content}</p>

              {msg.role === 'model' && msg.audioData && (
                <button
                  onClick={() => playAudio(msg.audioData!)}
                  className="absolute -right-10 top-2 p-2 rounded-full bg-white/5 text-white/40 opacity-0 group-hover:opacity-100 transition-opacity hover:text-white"
                >
                  <Play size={12} fill="currentColor" />
                </button>
              )}

              {msg.sponsorId && (
                <div className="mt-3">
                  {(() => {
                    const sponsorLoc = sponsoredLocations.find(l => l.id === msg.sponsorId);
                    const sponsor = sponsors.find(s => s.id === sponsorLoc?.sponsorId);
                    if (!sponsorLoc || !sponsor) return null;

                    return (
                      <div className="bg-white/5 rounded-xl border border-emerald-500/30 overflow-hidden hover:bg-white/10 transition-colors cursor-pointer" onClick={() => {
                        trackAdEvent(sponsorLoc.id, 'click');
                        onSelectLocation(sponsorLoc.address);
                      }}>
                        <div className="p-3 flex gap-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-bold text-white text-base leading-tight">{sponsorLoc.name}</h4>
                              <span className="bg-emerald-500 text-black text-[8px] font-bold uppercase px-1.5 py-0.5 rounded-sm">Patrocinado</span>
                            </div>
                            <div className="flex items-center gap-1 text-xs mb-1">
                              <span className="text-white">{sponsorLoc.rating}</span>
                              <div className="flex text-yellow-400">
                                {[1, 2, 3, 4, 5].map(s => <Star key={s} size={10} fill={s <= Math.floor(sponsorLoc.rating) ? "currentColor" : "none"} />)}
                              </div>
                              <span className="text-white/40">({Math.floor(Math.random() * 500) + 100})</span>
                            </div>
                            <p className="text-xs text-white/60 truncate">{sponsorLoc.tags[0]} • {sponsorLoc.address.split(',')[0]}</p>
                            <p className="text-xs text-emerald-400 mt-0.5">Aberto <span className="text-white/40">• Fecha 23:00</span></p>
                          </div>
                          <div className="w-16 h-16 rounded-lg bg-emerald-500/20 flex-shrink-0 flex items-center justify-center overflow-hidden border border-emerald-500/20">
                            <img src={`https://picsum.photos/seed/${sponsorLoc.id}/100/100`} alt={sponsorLoc.name} className="w-full h-full object-cover opacity-80" />
                          </div>
                        </div>
                        <div className="px-3 pb-3">
                          <button
                            className="w-full bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
                          >
                            <Car size={14} />
                            Solicitar Inviagem
                          </button>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}

              {msg.locations && msg.locations.length > 0 && !msg.sponsorId && (
                <div className="mt-3 grid grid-cols-1 gap-3">
                  {msg.locations.map((loc, idx) => {
                    const isFood = loc.category?.toLowerCase().includes('restaurante') || loc.category?.toLowerCase().includes('churrascaria') || loc.category?.toLowerCase().includes('bar') || loc.category?.toLowerCase().includes('fogão') || loc.category?.toLowerCase().includes('espeto');

                    return (
                      <div
                        key={idx}
                        onClick={() => onSelectLocation(loc.title)}
                        className="flex flex-col gap-2 p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-left cursor-pointer border border-white/10"
                      >
                        <div className="flex justify-between gap-3">
                          <div className="flex-1 overflow-hidden">
                            <h4 className="font-medium text-white text-base leading-tight mb-1">{loc.title}</h4>
                            <div className="flex items-center gap-1 text-xs text-white/60 mb-1">
                              <span className="text-white">{loc.rating}</span>
                              <div className="flex text-yellow-400">
                                {[1, 2, 3, 4, 5].map(s => <Star key={s} size={10} fill={s <= parseFloat(loc.rating || '0') ? "currentColor" : "none"} />)}
                              </div>
                              <span>({loc.reviews})</span>
                              <span>•</span>
                              <span>{loc.price}</span>
                            </div>
                            <p className="text-xs text-white/60 truncate">{loc.category} • {loc.address}</p>
                            <p className="text-xs mt-0.5">
                              <span className={loc.isOpen ? "text-emerald-400" : "text-red-400"}>{loc.isOpen ? 'Aberto' : 'Fechado'}</span>
                              <span className="text-white/60"> • Fecha {loc.closingTime}</span>
                            </p>

                            {isFood && (
                              <div className="flex items-center gap-2 text-[10px] text-white/60 mt-2">
                                <span className="flex items-center gap-1"><Check size={10} className="text-emerald-400" /> Refeição no local</span>
                                <span>•</span>
                                <span className="flex items-center gap-1"><Check size={10} className="text-emerald-400" /> Para viagem</span>
                              </div>
                            )}
                          </div>
                          <div className="w-20 h-20 rounded-lg bg-white/10 flex-shrink-0 overflow-hidden border border-white/10">
                            <img src={`https://picsum.photos/seed/${idx + loc.title}/200/200`} alt={loc.title} className="w-full h-full object-cover opacity-80" />
                          </div>
                        </div>

                        {loc.reviewText && (
                          <div className="flex items-start gap-2 mt-2 pt-2 border-t border-white/10">
                            <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <UserIcon size={10} className="text-blue-400" />
                            </div>
                            <p className="text-xs text-white/60 italic">&quot;{loc.reviewText}&quot;</p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 bg-white/40 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-white/40 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                <div className="w-1.5 h-1.5 bg-white/40 rounded-full animate-bounce [animation-delay:0.4s]"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-5 bg-black/20 border-t border-white/10">
        <div className="flex gap-3 bg-white/5 p-2 rounded-2xl border border-white/10">
          <div className="flex-1 relative flex items-center">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Pergunte algo ao Concierge..."
              className="w-full bg-transparent outline-none px-3 text-sm pr-10"
            />
            {input && (
              <button
                onClick={() => setInput('')}
                className="absolute right-2 text-white/30 hover:text-white transition-colors"
              >
                <X size={14} />
              </button>
            )}
          </div>
          <button
            onClick={handleSend}
            disabled={isLoading}
            className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center hover:bg-blue-500 transition-colors disabled:opacity-50"
          >
            <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
