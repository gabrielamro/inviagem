import fs from 'fs';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.join(__dirname, '.env.local') });

const projectId = 'ewgglooabyzilweudhoo';

async function runMigration() {
  try {
    const sql = fs.readFileSync(path.join(__dirname, 'phase8_migration.sql'), 'utf-8');
    
    console.log('Running Phase 8 Migration...');
    
    if (process.env.SUPABASE_ACCESS_TOKEN) {
        const response = await fetch(`https://api.supabase.com/v1/projects/${projectId}/sql`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${process.env.SUPABASE_ACCESS_TOKEN}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ query: sql })
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('✅ Migração executada com sucesso!');
        } else {
            console.error('❌ Erro na API do Supabase:', result);
        }
    } else {
        console.error('❌ SUPABASE_ACCESS_TOKEN não encontrado no .env.local');
    }
  } catch (e) {
    console.error('Error:', e);
  }
}

runMigration();
