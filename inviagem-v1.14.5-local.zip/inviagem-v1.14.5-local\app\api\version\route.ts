import { readFileSync } from 'fs';
import { join } from 'path';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  let buildId = 'unknown';
  try {
    buildId = readFileSync(join(process.cwd(), '.next', 'BUILD_ID'), 'utf8').trim();
  } catch {
    buildId = 'sem-build';
  }
  return NextResponse.json({
    appVersion: process.env.NEXT_PUBLIC_APP_VERSION ?? null,
    buildId,
    stamp: process.env.NEXT_PUBLIC_BUILD_STAMP ?? null,
    nodeEnv: process.env.NODE_ENV,
    time: new Date().toISOString(),
  });
}
