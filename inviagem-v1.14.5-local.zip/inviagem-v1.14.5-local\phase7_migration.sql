-- Block 1: Scalability, Indexes and Gender Columns
DO $$
BEGIN
    -- MALE, FEMALE, OTHER
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='drivers' AND column_name='gender') THEN
        ALTER TABLE drivers ADD COLUMN "gender" VARCHAR(20);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='passengers' AND column_name='gender') THEN
        ALTER TABLE passengers ADD COLUMN "gender" VARCHAR(20);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='drivers' AND column_name='accepts_pet_rides') THEN
        ALTER TABLE drivers ADD COLUMN "accepts_pet_rides" BOOLEAN DEFAULT FALSE;
    END IF;

    -- Adding critical indexes if they do not exist
    IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'idx_rides_driver_id') THEN
        CREATE INDEX idx_rides_driver_id ON rides(driver_id);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'idx_rides_passenger_id') THEN
        CREATE INDEX idx_rides_passenger_id ON rides(passenger_id);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'idx_rides_status') THEN
        CREATE INDEX idx_rides_status ON rides(status);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'idx_rides_created_at') THEN
        CREATE INDEX idx_rides_created_at ON rides(created_at);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'idx_drivers_cpf') THEN
        CREATE INDEX idx_drivers_cpf ON drivers(cpf);
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_class WHERE relname = 'idx_passengers_cpf') THEN
        CREATE INDEX idx_passengers_cpf ON passengers(cpf);
    END IF;
END $$;
