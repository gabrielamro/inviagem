import type {Metadata} from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import './globals.css'; // Global styles
import { StoreProvider } from '@/lib/store';

const inter = Inter({ subsets: ['latin'], variable: '--font-sans' });
const jetbrainsMono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono' });

export const metadata: Metadata = {
  title: 'Inviagem | Mobilidade Premium',
  description: 'Plataforma de transporte com aplicativos para Passageiro, Motorista e Administrador.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="pt-BR" className={`${inter.variable} ${jetbrainsMono.variable} dark`}>
      <body className="antialiased font-sans selection:bg-white/30" suppressHydrationWarning>
        <StoreProvider>
          {children}
        </StoreProvider>
        {process.env.NEXT_PUBLIC_APP_VERSION ? (
          <div
            className="fixed bottom-1 right-1 z-[9999] max-w-[min(90vw,280px)] truncate text-[10px] text-emerald-500/70 font-mono pointer-events-none select-none text-right leading-tight"
            title="Versão do app e carimbo de build"
          >
            <span className="font-semibold text-emerald-400/90">v{process.env.NEXT_PUBLIC_APP_VERSION}</span>
            {process.env.NEXT_PUBLIC_BUILD_STAMP ? (
              <span className="block text-[9px] text-white/25 mt-0.5">{process.env.NEXT_PUBLIC_BUILD_STAMP}</span>
            ) : null}
          </div>
        ) : null}
      </body>
    </html>
  );
}
