import { NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';

export const runtime = 'nodejs';

/**
 * Chave só no servidor: GEMINI_API_KEY ou GOOGLE_GENERATIVE_AI_API_KEY.
 * Em dev local também aceita NEXT_PUBLIC_GEMINI_API_KEY (menos seguro).
 */
function resolveGeminiKey(): string {
  return (
    process.env.GEMINI_API_KEY?.trim() ||
    process.env.GOOGLE_GENERATIVE_AI_API_KEY?.trim() ||
    process.env.NEXT_PUBLIC_GEMINI_API_KEY?.trim() ||
    ''
  );
}

export async function POST(req: Request) {
  try {
    const key = resolveGeminiKey();
    if (!key) {
      return NextResponse.json(
        {
          error: 'missing_key',
          message:
            'Defina GEMINI_API_KEY (recomendado) ou GOOGLE_GENERATIVE_AI_API_KEY no .env.local e reinicie o servidor.',
        },
        { status: 503 }
      );
    }

    const body = (await req.json()) as { prompt?: string; systemInstruction?: string; model?: string };
    const prompt = String(body.prompt ?? '').trim();
    if (!prompt) {
      return NextResponse.json({ error: 'empty_prompt' }, { status: 400 });
    }

    const model = body.model?.trim() || 'gemini-2.0-flash';
    const ai = new GoogleGenAI({ apiKey: key });

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: body.systemInstruction
        ? { systemInstruction: String(body.systemInstruction) }
        : undefined,
    });

    const text = response.text ?? '';
    return NextResponse.json({ text });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : 'Falha ao chamar o modelo.';
    return NextResponse.json({ error: 'gemini', message }, { status: 502 });
  }
}
