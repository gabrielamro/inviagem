-- INVIAGEM v1.13.0 — colunas opcionais (idempotente no PostgreSQL/Supabase)
-- Execute no SQL Editor do Supabase se quiser persistir e-mail, telefone e frota.

alter table if exists passengers add column if not exists email text;
alter table if exists passengers add column if not exists phone text;

alter table if exists drivers add column if not exists email text;
alter table if exists drivers add column if not exists phone text;
alter table if exists drivers add column if not exists fleet_json jsonb;

-- Exemplo de frota (opcional, para testar UI sem o app):
-- update drivers set fleet_json = '{"list":[{"id":"fv_demo","kind":"MOTO","model":"Biz 125","plate":"NAA-0001"}],"activeId":"fv_demo"}'::jsonb where id = '<uuid do motorista>';
