/**
 * Soma distância/tempo de todas as pernas da rota (origem → paradas → destino).
 */

export type DirectionsLike = {
  routes?: {
    legs?: { distance?: { value?: number }; duration?: { value?: number } }[];
  }[];
} | null;

const DEFAULT_KM = 5;
const DEFAULT_MIN = 12;

export function sumDirectionsLegs(route: DirectionsLike): { distanceKm: number; durationMin: number } {
  const legs = route?.routes?.[0]?.legs;
  if (!legs?.length) {
    return { distanceKm: DEFAULT_KM, durationMin: DEFAULT_MIN };
  }
  let meters = 0;
  let seconds = 0;
  for (const leg of legs) {
    meters += leg.distance?.value ?? 0;
    seconds += leg.duration?.value ?? 0;
  }
  const distanceKm = meters > 0 ? Math.max(0.05, meters / 1000) : DEFAULT_KM;
  const durationMin = seconds > 0 ? Math.max(1, Math.ceil(seconds / 60)) : DEFAULT_MIN;
  return { distanceKm, durationMin };
}
